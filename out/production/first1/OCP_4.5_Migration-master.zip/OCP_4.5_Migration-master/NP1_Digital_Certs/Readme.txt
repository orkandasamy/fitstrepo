Digital team's SSL certs for new 4.5 route hostnames live here.
