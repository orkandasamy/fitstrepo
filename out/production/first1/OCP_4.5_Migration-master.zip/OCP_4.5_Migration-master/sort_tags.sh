oc get sa
DIG=$(grep -B3 "name: latest" Is-$APP_ID.yml|head -1|awk -F ':' '{print $3}')
grep -B4 $DIG Is-$APP_ID.txt|grep -B1 -w tag|tail -2|head -1 > $APP_ID.txt
TG=`cat $APP_ID.txt`
if [ -z "$TG" ]
then
grep -B4 $DIG Is-$APP_ID.txt|grep -B1 -w tagged|tail -2|head -1 > $APP_ID.txt
TG=`cat $APP_ID.txt`
if [ -z "$TG" ]
then
oc get imagestreams $APP_ID -o jsonpath='{range .status.tags[*]}{.tag}{"\n"}'|sort -t "." -n -k1,1 -k2,2 -k3,3 -k4,4|tail -1 > $APP_ID.txt
TG=`cat $APP_ID.txt`
echo "Tag ID Found $TG Rev"
else
echo "Tag ID $TG Found Tagged"
fi
else
echo "Tag ID $TG Found Tag"
fi
grep -A1 "$TG" Is-$APP_ID.txt|grep tagged|awk '{print $3}' > $APP_ID-artrepo.txt
grep -A1 "latest" Is-$APP_ID.txt|grep tagged|awk '{print $3}'|awk -F"." '{print $1}' > $APP_ID-artchk.txt
