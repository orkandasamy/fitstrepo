oc get sa
DIG=$(grep -B3 "name: latest" Is-$APP_ID.yml|head -1|awk -F ':' '{print $3}')
grep -B4 $DIG Is-$APP_ID.txt|grep -B1 -w tag|tail -2|head -1 > $APP_ID.txt
TCHK=`cat $APP_ID.txt`
if [ -z "$TCHK" ]
then
grep -B4 $DIG Is-$APP_ID.txt|grep -B1 -w tagged|tail -2|head -1 > $APP_ID.txt
TCHKS=`cat $APP_ID.txt`
echo "Tag ID Found Tagged Rev"
else
echo "Tag ID Found Tag Rev"
fi
if [ -z "${TCHK}${TCHKS}" ]
then
oc get imagestreams $APP_ID-apiserver -o jsonpath='{range .status.tags[*]}{.tag}{"\n"}'|sort -t "." -n -k1,1 -k2,2 -k3,3 -k4,4|tail -1 > $APP_ID.txt
echo "Tag ID Found Scan"
else
echo "Tag ID Found Tagged Rev"
fi
