#!/bin/bash
echo "oc login"
oc login -u system:admin
login="$(oc login -u system:admin)";
clustername="$(echo $login | awk '{print $3}' | rev | cut -d'/' -f 1 | rev | cut -d':' -f 1)"
echo $clustername
status="$( oc get nodes | awk '{ print $2 }' )"
echo $status
echo 'Checking the nodes status'
if [[ ($status == *"NotReady"*) ]]; then
python /opt/nodestatusAlerts.py "NotReady" $clustername
fi
if [[ ($status == *"SchedulingDisabled"*) ]]; then
python /opt/nodestatusAlerts.py "SchedulingDisabled" $clustername
fi
