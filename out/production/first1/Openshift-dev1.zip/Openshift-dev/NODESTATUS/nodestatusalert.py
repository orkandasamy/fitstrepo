import sys
import smtplib,ssl

port=25
from_mail = 'middlewareengineering@frbnp1.com'
to_mail = 'middlewareengineering@firstrepublic.com'
clustername= sys.argv[2]
if 'ocp' in clustername:
    smtp_server = 'np1mailgw01.corp.frbnp1.com'
else:
    smtp_server = 'np1mailgw01.corp.frbnp1.com'
print(smtp_server)

print(clustername)

mail_body= "Subject: Nodes are in NotReady state or SchedulingDisabled state \n\nFound" + " NotReady/SchedulingDisabled status on " + clustername + "-cluster" 
print('in py script')
server = smtplib.SMTP(smtp_server,port)
server.sendmail(from_mail,to_mail,mail_body)
