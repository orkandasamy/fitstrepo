# Post Installation Validation Steps

#### Using the below steps you can test the following things on a new OpenShift cluster: 
**1. Login to OC cluster with with user who has administrator access.**  
**2. Check if the cluster has desired number of Master and worker nodes.**  
**3. Validate if Kubernetes service is present by default in the new OC Cluster.**  
**4. Check is OpenShift service is present by default in the new OC Cluster.**  
**5. We check if all the nodes are in running of completed status.**  
**6. Create a new application, deploy it and check if the application is correctly deployed.**  
**7. Delete the project.**  

## Getting Started

These instructions will help you to validate the cluster health.

  
### Prerequisites
Access to a server where: 
1. Ansible playbook is installed. 
2. Connectivity to OpenShift cluster via *"oc login"* command. 
3. Check if ssh to localhost is possible without entering password is possible.(Required while running ansible playbook)

### Installing

Clone the Repository and run the playbook using the playbook.  
```
cd ; rm -rf Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git
ansible-playbook ~/Openshift/aws/common/cluster-validation/token_pre_validation.yaml -i localhost, --extra-vars "url=<CLUSTER_URL> token=<USER_TOKEN>"
````

### Check the log file 

Check the result.txt file in the folder /tmp/ to see the status of all the steps:wq.  
Note: If you want to change the path of the result.txt file, follow the following steps:
```
vi ~/Openshift/aws/common/cluster-validation/token_pre_validation.yaml
```

Change the value for output var. 
```
vars:
  output: **NEW_PATH**
```

### Check Router and Registry pod and logs for each of them
```
oc login <CLUSTER_URL>
oc get pods --all-namespaces --no-headers=true | grep router
oc logs <ROUTER_NAME> -n <ROUTER_NAMESPACE>

oc get pods --all-namespaces --no-headers=true | grep registry
oc logs <REGISTRY_NAME> -n <REGISTRY_NAMESPACE> -c <CLUSTER_NAME>
 ```
 
 Please check you are able to see the logs for each of the router and registry pod and not getting any error.
