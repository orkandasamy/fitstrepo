./oc delete sc sc-ebs-gp2-with-kms --ignore-not-found=true
./oc create -f aws/common/create_storageclass/createStorageClass.yaml