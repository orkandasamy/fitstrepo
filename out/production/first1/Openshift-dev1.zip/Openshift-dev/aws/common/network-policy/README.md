# Network policy for Openshift 4.5

## Getting Started

These instructions will help you to define the default network policy for any new project getting created.

### Prerequisites
You must have cluster admin access on the openshift server you are trying to perform this activity. 

### Installing

Clone the Repository
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd  ~/Openshift
```

## Configuring Network policy

Now run the below commands to create new project-request template. 

```
oc login <CLUSTER-API-URL>
```
```
oc create -f ~/Openshift/aws/common/resource-quota/project-request-template.yaml -n openshift-config
```

Now edit the project configuration resource to define projectRequestTemplate.  
  
Update the spec section of the project configuration resource to include the projectRequestTemplate. Below are the steps for doing it. 
```
oc edit project.config.openshift.io/cluster
```
Update the specs section with the below details: 
```
apiVersion: config.openshift.io/v1
kind: Project
metadata:
  ...
spec:
  projectRequestTemplate:
    name: project-request

```

Save and exit the file. Please wait for few minutes for network-operator to re-start  

**Validate and ensure that network policies are correctly implemented**

**Create an new project**
```
oc new-project test-networkpolicy
```  
**Verify the network policies that are enforced**
```
oc get networkpolicy -n test-networkpolicy
```
The result should contain all the 3 network policies. 
```
allow-from-openshift-ingress  
allow-from-same-namespace
allow-from-openshift-monitoring
```
**Delete the project**
```
oc delete project test-networkpolicy
```

## Check if Network policy is already present 
**Validate if project configuration resource includes the projectRequestTemplate**
```
oc edit project.config.openshift.io/cluster
```
**Validate if the specs section contains the below information:**
```
spec:
  projectRequestTemplate:
    name: project-request
```
**Now validate the project template to see which network policies are implemeted**
```
oc edit template project-request -n openshift-config
```
In the config file check if it contains 3 network policies. It should contain the following policies:  
**1. allow-from-openshift-ingress**  
**2. allow-same-namespace**  
**3. allow-from-openshift-monitoring**  

#### Adding one or more network policies to project-request temnplate

**You can add one or more network policies(as required) to the project-request template by following the below steps**
* Copy the network policy needed from the link: https://docs.openshift.com/container-platform/4.5/post_installation_configuration/network-configuration.html#nw-networkpolicy-multitenant-isolation_post-install-network-configuration. 
* Edit the project-request template.
```
oc edit template project-request -n openshift-config
```
**Add the required section to the template.** *Please check the indendation.*

**Example:**
```
- apiVersion: networking.k8s.io/v1
  kind: NetworkPolicy
  metadata:
    name: allow-from-openshift-monitoring
  spec:
    ingress:
    - from:
      - namespaceSelector:
          matchLabels:
            network.openshift.io/policy-group: monitoring
    podSelector: {}
    policyTypes:
    - Ingress
```
Save and exit the file. Please wait for few minutes for network-operator to re-start 

**Validate if the Network policies are correctly implemented**

create an new project
```
oc new-project test-networkpolicy
```  
Validate if Network policy has been enforced by following the steps "**Validate and ensure that network policies are correctly implemented**"

#### Adding one or more network policies to an existing project

1. Identify the netowrk policy which are not enforced yet
**Listing the network policies enforced in an existing namespace**
```
oc get networkpolicy -n <PROJECT_NAME>
```
**Listing the network policies enforced in all namespaces**
```
oc get networkpolicy --all-namespaces
```
2. Create a file with the netork policy you want to enforce. You can get the network policy content from https://docs.openshift.com/container-platform/4.5/post_installation_configuration/network-configuration.html#nw-networkpolicy-multitenant-isolation_post-install-network-configuration.
```
vi <NETWORK_POLICY_FILE_NAME.YAML>
<<<<<<ADD THE NETWORK POLICY HERE AND THEN SAVE & EXIT>>>>>>
```
3. Create the network policy for the Project/NameSpace using the file created above
```
oc create -f <NETWORK_POLICY_FILE_NAME.YAML> -n <PROJECT_NAME>
```
4. Verify and ensure that the network policy has been applied to the project
```
oc get networkpolicy -n <PROJECT_NAME>
```
