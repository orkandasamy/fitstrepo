# project-request-template.yaml (s) in OpenShift 4.x on AWS

#### Using the below steps you can implement: 
**1. Compute Resource Quota**  
**2. Network Policy**  

**project-request-template.yaml** is a template that is used to define resource quota and network policy for new projects.

## Getting Started

These instructions will help you to define the resource quota and network policy for any new project getting created by default

### Prerequisites

You must login to environment specific Middle-ware jump host. For jump host details, please refer to our Wiki Page  
https://team.corp.firstrepublic.com/sites/appsupport/OpenShiftAWS/Pages/AWS%20OpenShift%20Hosts%20List.aspx

### Installing

Clone the Repository

```
cd ; rm -rf Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git
cp ~/Openshift/aws/common/resource-quota/project-request-template.yaml ~/Openshift/aws/common/resource-quota/template.yaml
```

## Configuring explicit resource quotas

Now run the below commands to create new project-request template. 

```
oc login <CLUSTER-URL>
oc create -f ~/Openshift/aws/common/resource-quota/project-request-template.yaml -n openshift-config

Now edit the project configuration resource to define projectRequestTemplate.  
Update the spec section of the project configuration resource to include the projectRequestTemplate and name parameters.

oc edit project.config.openshift.io/cluster

apiVersion: config.openshift.io/v1
kind: Project
metadata:
  ...
spec:
  projectRequestTemplate:
    name: project-request

```

Now the resource quota and network policy are created
Create a new project and test if the resource quota and netowrk policy are correctly defined.

```
oc new-project <project_name>
oc get resourcequotas
oc describe resourcequotas <resource_quota_name>
```
Now check if the resources are as expected.

```
oc project <project_name>
oc get networkpolicy
```
Check if both network policies given below are defined  
allow-from-openshift-ingress  
allow-from-same-namespace  
