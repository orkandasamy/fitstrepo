Configuration files for E-Release Project
