#### **NETWORK POLICY MUST BE CREATED USING ~/Openshift/aws/common/resource-quota/project-request-template.yaml**
# Setup default Network Policy in OpenShift 4.x Platform

These steps will be used to setup the defaulf Network Policy when a new OpenShift environment is created. 

## Getting Started

These steps will help setup the defaulf Network Policy while creating a new project. 

### Prerequisites

You must login to FIRST master server, and follow the below steps: 
**Please ensure that project-request template is already created and available to use.**  
Ref: https://docs.openshift.com/container-platform/4.2/networking/configuring-networkpolicy.html  
1. Enter command : oc edit template project-request -n openshift-config
2. Start editing the script and copy the content from the file default_policy.yaml to the project template under "Object".
3. Create a new project using command "oc new-project validate-project".
4. Confirm that the network policy objects in the new project template exist in the new project using command: oc get networkpolicy
