#!/bin/bash
## Create the LDAP Secret
oc create secret generic ldap-secret --from-literal=bindPassword=<secret> -n openshift-config

## Create a ConfigMap
oc create configmap ca-config-map --from-file=ca.crt=/path/to/ca -n openshift-config

## Create the Custom Resource (CR)
oc apply -f aws/npe/connect-ldap/ldap-cr.yaml
