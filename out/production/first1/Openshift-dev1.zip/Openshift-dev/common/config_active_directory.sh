./oc delete secret ldap-secret -n openshift-config --ignore-not-found=true
./oc create secret generic ldap-secret --from-literal=bindPassword=${AD_PW} -n openshift-config
./oc delete configmap ca-config-map -n openshift-config --ignore-not-found=true
./oc create configmap ca-config-map --from-file=aws/${ENV}/certificates/ca.crt -n openshift-config
./oc apply -f aws/${ENV}/connect-ldap/ldap.cr.yaml