./oc patch apiserver cluster --type=merge -p '{"spec": {"encryption": {"type": "aescbc"}}}'
echo "It takes up to 20 minutes for etcd encryption to complete."
echo "The next 2 status commands show etcd encryption is not enabled (unless it was already encrypted)."
./oc get openshiftapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'
./oc get kubeapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'