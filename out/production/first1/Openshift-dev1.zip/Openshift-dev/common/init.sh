tar -xvf aws/common/oc.tar
./oc logout
./oc login https://${API_URL} --insecure-skip-tls-verify=true -u kubeadmin -p ${TOKEN}