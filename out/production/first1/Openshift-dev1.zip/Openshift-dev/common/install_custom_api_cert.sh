exit
./oc delete secret api-cert -n openshift-config --ignore-not-found=true
./oc create secret tls api-cert --cert=aws/${ENV}/certificates/${API_CERT_FILE} --key=aws/${ENV}/certificates/${API_KEY_FILE} -n openshift-config
./oc patch apiserver cluster --type=merge -p '{"spec":{"servingCerts": {"namedCertificates": [{"names": ["${API_URL}"], "servingCertificate": {"name": "api-cert"}}]}}}'