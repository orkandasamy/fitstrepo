exit
./oc delete configmap custom-ca -n openshift-config --ignore-not-found=true
./oc create configmap custom-ca --from-file=aws/${ENV}/certificates/${INGRESS_ROOT_CA} -n openshift-config
./oc patch proxy/cluster --type=merge --patch='{"spec":{"trustedCA":{"name":"custom-ca"}}}'
./oc delete secret apps-secret -n openshift-ingress --ignore-not-found=true
./oc create secret tls apps-secret --cert=aws/${ENV}/certificates/${INGRESS_CERT_FILE} --key=aws/${ENV}/certificates/${INGRESS_KEY_FILE} -n openshift-ingress
./oc patch ingresscontroller.operator default --type=merge -p '{"spec":{"defaultCertificate": {"name": "apps-secret"}}}' -n openshift-ingress-operator