echo "Install Splunk Connect"
exit
oc new-project splunk-connect
oc project splunk-connect
helm install splunk-connect -f {$site_aws_or_onprem}/{$ENV}common/splunk_values_{site_aws_or_onprem}_{$ENV}.yaml splunk/splunk-connect-for-kubernetes
for sa in $(oc  get sa --no-headers  | grep splunk | awk '{ print $1 }'); do
 oc adm policy add-scc-to-user privileged -z $sa
 done