# Add INFRA nodes to the existing OpenShift cluster 
#### Use case
* You have an exisitng OpenShift cluster which contains master and worker nodes only
* You want to add INFRA nodes to this cluster and move the router, registry, monitoring and logging pods to infra nodes using "node selector" and "taint"

## Getting started

The instructions given below is prepared based on the redhat docs

https://access.redhat.com/solutions/5034771 section "Without MachineSets"

https://docs.openshift.com/container-platform/4.5/machine_management/creating-infrastructure-machinesets.html#binding-infra-node-workloads-using-taints-tolerations_creating-infrastructure-machinesets

You can use the attached yaml files as a ref to make your original/required input files

# Ordering/Preparing Infra Nodes:
* Submit service-now requests to get the 3 new VMs for 3 infra nodes
  * Using the above requests, work with L1 Ops and get the IP and hostname(A-record) reserved
  * **Note:** Actual VM will be provisioned by LE team later. L1 Ops NOT required to provision the VMs.
* Once you get the IP/hostname reserved
  * Add the infra nodes IPs to the APPS LB
  * Submit service-now request to get access to mount the NFS storage on these INFRA nodes
  * Submit firewall request for Infra nodes same as worker nodes
* Once above steps are done, inform LE team to build the INFRA nodes
  * LE Team build the infra nodes and deleiver to us

# Labelling and tainting infra nodes
* Now OpenShift team will 
  * Label the infra nodes
  * Taint the infra nodes
  * Move the below components to infra nodes
    * Router
    * Registry
    * Monitoring
    * Logging
* To do the OpenShift team acitivities, you MUST have OpenShift cluster admin access
## Step-1: Login to OpenShift cluster
```
oc login <CLUSTER-API-URL>
```
## Step-2: Label the Infra nodes and verify the same
```
oc label node <infra-node-name[1-3]> node-role.kubernetes.io/infra=
```
```
oc get nodes
```
## Step-3: Taint the infra node and verify the same
```
oc adm taint nodes -l node-role.kubernetes.io/infra infra=reserved:NoSchedule infra=reserved:NoExecute
```
```
oc describe node <infra-node-name> | grep -iA1 "Taints:"
```
# Moving Components to the Infrastructure Nodes
## Step-5: Move router pods and verify the same
**Backup before make the changes**
```
oc get ingresscontroller/default -n  openshift-ingress-operator -o yaml > ~/ingresscontroller.default.openshift-ingress-operator.yaml
```
**Add node selector and taint to the ingress router using the below patch command**
```
oc patch ingresscontroller/default -n  openshift-ingress-operator  --type=merge -p '{"spec":{"nodePlacement": {"nodeSelector": {"matchLabels": {"node-role.kubernetes.io/infra": ""}},"tolerations": [{"effect":"NoSchedule","key": "infra","value": "reserved"},{"effect":"NoExecute","key": "infra","value": "reserved"}]}}}'
```
**The router is configured by default to have only 2 replicas, but with 3 infrastructure nodes the following patch is required to scale to 3 routers**
```
oc patch ingresscontroller/default -n openshift-ingress-operator --type=merge -p '{"spec":{"replicas": 3}}'
```
```
oc get pod -n openshift-ingress -o wide
```
## Step-6: Move registry pods and verify the same
**Backup before making the changes**
```
oc get configs.imageregistry.operator.openshift.io/cluster -o yaml > ~/configs.imageregistry.operator.openshift.io.cluster.yaml
```
**To move the registry, apply the following patch to the config/cluster object**
```
oc patch configs.imageregistry.operator.openshift.io/cluster --type=merge -p '{"spec":{"nodeSelector": {"node-role.kubernetes.io/infra": ""},"tolerations": [{"effect":"NoSchedule","key": "infra","value": "reserved"},{"effect":"NoExecute","key": "infra","value": "reserved"}]}}'
```
```
oc get pods -o wide -n openshift-image-registry | grep "^image-registry-"
```
## Step-7: Move monitoring pods and verify the same
**Prometheus, Grafana and AlertManager comprise the default monitoring stack. To move these components create/edit a config map with the required Node Selectors and Tolerations**

**Add nodeSelector and tolerations to**
* prometheus
* alertmanager
* grafana
* k8sPrometheusAdapter
* kubeStateMetrics
* telemeterClient
* openshiftStateMetrics

**Backup the existing configmap before proceed**
```
oc get cm cluster-monitoring-config  -n openshift-monitoring -o yaml > ~/cluster-monitoring-config.openshift-monitoring.yaml
```
**Define the ConfigMap as the cluster-monitoring-configmap.yaml file with the following(along with your existing config), refer the attached example file "example-cluster-monitoring-configmap.yaml" and apply the file**
```
apiVersion: v1
kind: ConfigMap
metadata:
  name: cluster-monitoring-config
  namespace: openshift-monitoring
data:
  config.yaml: |+
    alertmanagerMain:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    prometheusK8s:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    prometheusOperator:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    grafana:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    k8sPrometheusAdapter:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    kubeStateMetrics:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    telemeterClient:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
    openshiftStateMetrics:
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
```
```
oc apply -f cluster-monitoring-configmap.yaml
```
```
oc get pod -n openshift-monitoring -o wide
```
**If the pods with this component are not moved/moving, delete the pods and check**
```
 oc delete pod -n openshift-monitoring <pod>
```
## Step-8: Move logging pods and verify the same
**Cluster logging and Elasticsearch must be installed. These features are not installed by default**

**You cannot move the Cluster Logging Operator pod from its installed location**

**You can configure the Cluster Logging Operator to deploy the pods for any or all of the Cluster Logging components given below to different nodes**
* Elasticsearch
* Kibana
* Curator

**Backup the existing data**
```
oc get ClusterLogging instance -o yaml > ~/ClusterLogging.instance.yaml
```
**Edit the "ClusterLogging instance"** using the below command
```
oc edit ClusterLogging instance
```
Add the below to each section mentioned above, refer the attached example file "example-cluster-logging-operator-instance.yaml"
```
      nodeSelector:
        node-role.kubernetes.io/infra: ""
      tolerations:
      - key: infra
        value: reserved
        effect: NoSchedule
      - key: infra
        value: reserved
        effect: NoExecute
```
**This change may take a while to reflect. In NP2, it took FEW HOURS to move the elastic search pods**
```
oc get pods -n openshift-logging -o wide
```
## Step-9: Sample output

TBD
