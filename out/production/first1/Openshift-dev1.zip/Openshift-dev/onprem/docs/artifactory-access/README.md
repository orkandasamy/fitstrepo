# Validate the access to registries  

#### Using the below steps you can validate the access to the registries we have at on-prem and AWS 

## Getting Started

The instructions given below with sample attached yaml files will help you to create pods by pulling the images from the respective registries

**Note:**
* You must have the project called **mware-infra** created in the cluster

### Steps: 
1. Login to respective OpenShift cluster and ensure that you have Cluster Admin access to OpenShift cluster or edit access to mware-infra namespace to create the POD
```
oc login <CLUSTER-API-URL>
```
2. Create POD by pulling the image from on-prem registry
```
oc create -f pod-pulling-image-from-onprem-registry.yaml -n mware-infra
```
3. Create POD by pulling the image from AWS registry
```
oc create -f pod-pulling-image-from-aws-registry.yaml -n mware-infra
```
4. Validate the POD by checking the events, logs etc
```
oc get pods
oc get events --sort-by='.metadata.creationTimestamp' 
```  
## Sample Output for Reference
**Check the POD status:**
```
[adm_sayyadurai@np2ocpadm1v ~]$ oc get pods
NAME                                                 READY   STATUS      RESTARTS   AGE
mware-infra-pod-pulling-image-from-onprem-registry   1/1     Running     0          12s
mware-infra-vsphere-pod                              1/1     Running     246        5d3h
wealth-hello-app-1-deploy                            0/1     Completed   0          29h
wealth-hello-app-1-n45bx                             1/1     Running     0          29h
wealth-test-app-1-deploy                             0/1     Completed   0          29h
wealth-test-app-1-zzclb                              1/1     Running     0          29h
[adm_sayyadurai@np2ocpadm1v ~]$
```

```
[adm_sayyadurai@np2ocpadm1v ~]$ oc get pods
NAME                                                 READY   STATUS      RESTARTS   AGE
mware-infra-pod-pulling-image-from-aws-registry      1/1     Running     0          4s
mware-infra-pod-pulling-image-from-onprem-registry   1/1     Running     0          72s
mware-infra-vsphere-pod                              1/1     Running     246        5d3h
wealth-hello-app-1-deploy                            0/1     Completed   0          29h
wealth-hello-app-1-n45bx                             1/1     Running     0          29h
wealth-test-app-1-deploy                             0/1     Completed   0          29h
wealth-test-app-1-zzclb                              1/1     Running     0          29h
[adm_sayyadurai@np2ocpadm1v ~]$
```

**Check the EVENTS:**
```
[adm_sayyadurai@np2ocpadm1v ~]$ oc get events --sort-by='.metadata.creationTimestamp' 
LAST SEEN   TYPE     REASON           OBJECT                                                   MESSAGE
13m         Normal   Pulled           pod/mware-infra-vsphere-pod                              Container image "artrepo.firstrepublic.com:5101/busybox" already present on machine
13m         Normal   Created          pod/mware-infra-vsphere-pod                              Created container busybox
13m         Normal   Started          pod/mware-infra-vsphere-pod                              Started container busybox
<unknown>   Normal   Scheduled        pod/mware-infra-pod-pulling-image-from-onprem-registry   Successfully assigned mware-infra/mware-infra-pod-pulling-image-from-onprem-registry to np2ocpwkr1v.ocp.corp.frbnp2.com
27s         Normal   AddedInterface   pod/mware-infra-pod-pulling-image-from-onprem-registry   Add eth0 [10.131.0.220/23]
27s         Normal   Pulling          pod/mware-infra-pod-pulling-image-from-onprem-registry   Pulling image "artifactory.corp.firstrepublic.com/index-docker-io-remote/busybox:1.32.0"
18s         Normal   Pulled           pod/mware-infra-pod-pulling-image-from-onprem-registry   Successfully pulled image "artifactory.corp.firstrepublic.com/index-docker-io-remote/busybox:1.32.0"
18s         Normal   Created          pod/mware-infra-pod-pulling-image-from-onprem-registry   Created container mware-infra-container-pulling-image-from-onprem-registry
18s         Normal   Started          pod/mware-infra-pod-pulling-image-from-onprem-registry   Started container mware-infra-container-pulling-image-from-onprem-registry
[adm_sayyadurai@np2ocpadm1v ~]$ 
```

```
[adm_sayyadurai@np2ocpadm1v ~]$ oc get events --sort-by='.metadata.creationTimestamp' 
LAST SEEN   TYPE     REASON           OBJECT                                                   MESSAGE
13m         Normal   Created          pod/mware-infra-vsphere-pod                              Created container busybox
13m         Normal   Pulled           pod/mware-infra-vsphere-pod                              Container image "artrepo.firstrepublic.com:5101/busybox" already present on machine
13m         Normal   Started          pod/mware-infra-vsphere-pod                              Started container busybox
<unknown>   Normal   Scheduled        pod/mware-infra-pod-pulling-image-from-onprem-registry   Successfully assigned mware-infra/mware-infra-pod-pulling-image-from-onprem-registry to np2ocpwkr1v.ocp.corp.frbnp2.com
74s         Normal   Pulling          pod/mware-infra-pod-pulling-image-from-onprem-registry   Pulling image "artifactory.corp.firstrepublic.com/index-docker-io-remote/busybox:1.32.0"
74s         Normal   AddedInterface   pod/mware-infra-pod-pulling-image-from-onprem-registry   Add eth0 [10.131.0.220/23]
65s         Normal   Pulled           pod/mware-infra-pod-pulling-image-from-onprem-registry   Successfully pulled image "artifactory.corp.firstrepublic.com/index-docker-io-remote/busybox:1.32.0"
65s         Normal   Created          pod/mware-infra-pod-pulling-image-from-onprem-registry   Created container mware-infra-container-pulling-image-from-onprem-registry
65s         Normal   Started          pod/mware-infra-pod-pulling-image-from-onprem-registry   Started container mware-infra-container-pulling-image-from-onprem-registry
<unknown>   Normal   Scheduled        pod/mware-infra-pod-pulling-image-from-aws-registry      Successfully assigned mware-infra/mware-infra-pod-pulling-image-from-aws-registry to np2ocpwkr1v.ocp.corp.frbnp2.com
6s          Normal   Started          pod/mware-infra-pod-pulling-image-from-aws-registry      Started container mware-infra-container-pulling-image-from-aws-registry
6s          Normal   Created          pod/mware-infra-pod-pulling-image-from-aws-registry      Created container mware-infra-container-pulling-image-from-aws-registry
6s          Normal   Pulling          pod/mware-infra-pod-pulling-image-from-aws-registry      Pulling image "artifactory.corp.firstrepublic.com/index-docker-io-remote/busybox:1.32.0"
6s          Normal   AddedInterface   pod/mware-infra-pod-pulling-image-from-aws-registry      Add eth0 [10.131.0.221/23]
6s          Normal   Pulled           pod/mware-infra-pod-pulling-image-from-aws-registry      Successfully pulled image "artifactory.corp.firstrepublic.com/index-docker-io-remote/busybox:1.32.0"
[adm_sayyadurai@np2ocpadm1v ~]$
```
