# Instruction for Blackduck Setup 
## Ref: 
https://synopsys.atlassian.net/wiki/spaces/BDLM/pages/65732720/Synopsysctl+Installation
https://synopsys.atlassian.net/wiki/spaces/BDLM/pages/65831179/Installing+Black+Duck+using+Synopsysctl
https://github.com/blackducksoftware/hub  
https://github.com/blackducksoftware/hub/releases

## Pre-Requsites
* request SSL certificate for blackduck application
* create a new namespace called "blackduck" on openshift cluster
* download latest synopsysctl tool (ref: synopsysctl directory)
* Create install synopsysctl cmd file with required parameters (ref: Create the install-cmd-file.txt section below)
* Pull , tag  and push images (ref: pulling-images-from-docker directory)
* Get security context file
* Get proxy  host, user and pwd for environment.
use beow command to get the proxy details of the openshift cluster
```
$ oc describe proxy/cluster
```
* update storgae class name. Use below command to list the storage class available for the cluster.
```
$ oc get sc
```

# Install procedure
## Create the install-cmd-file.txt
use below values to create the file

-> <prefix_for_resource_name> = frb

-> <Version_Number> = version of blackduck software

-> <path_to_blackduck_software> = location where blackduck software download is available

-> <path_to_security_context_file> = path where security context.json file is available

-> <proxy_Host_Name> = vsproxynpgs.frbnpgs.com

-> <proxy_port> = 8080

-> <proxy_user> = z_ocp_proxy

-> <proxy_password> = password available in PUM
  
-> <storage_class_name> = thin01

-> <namespace_name > = blackduck

-> <path_to_internal_image_repository> = artrepo.firstrepublic.com:5101/dct_docker_local/blackducksoftware-2020-10-1

-> <DB_admin_password> = <any password>
  
-> <DB_user_password>> = <any password>
  
-> <alpha_numeric_string> = any alphanumeric string
  
-> <path_to_certificate_file> = public certificate file
  
-> <path_to_certificate_key_file> = certificate key file

Once the below command is updated with rigth values, save it to a file install-cmd-file 
### synopsysctl command:
./synopsysctl create blackduck native <prefix-for-resource-name> --version <Version -Number> --app-resources-path <path to -blackduck software> --security-context-file-path <path-to security-context-file> --environs "HUB_PROXY_SCHEME:http,HUB_PROXY_HOST:<proxy_Host_Name>,HUB_PROXY_PORT:<proxy-port>,HUB_PROXY_USER:<proxy-user>,HUB_PROXY_PASSWORD:<proxy-password>"  --persistent-storage true --pvc-storage-class <storage-class-name> -n <namespace-name> --registry <path-to-internal-registry> --admin-password <DB-admin-password> --user-password <DB-user-password> --expose-ui OPENSHIFT --seal-key <alpha-numeric-string> --certificate-file-path <path-to certificate file> --certificate-key-file-path <path-to certificate-key-file> 

### Example:
```
./synopsysctl create blackduck native frb --version 2020.10.1 --app-resources-path blackduck-2020.10.1.tgz --security-context-file-path security-context.json   --environs "HUB_PROXY_SCHEME:http,HUB_PROXY_HOST:vsproxynpgs.frbnpgs.com,HUB_PROXY_PORT:8080,HUB_PROXY_USER:z_ocp_proxy,HUB_PROXY_PASSWORD:Ready2Come"  --persistent-storage true --pvc-storage-class thin01 -n blackduck --registry artrepo.firstrepublic.com:5101/dct_docker_local/blackducksoftware-2020-10-1 --admin-password admin12345 --user-password user12345 --expose-ui OPENSHIFT --seal-key abcdefghijklmnopqrstuvwxyz123456 --certificate-file-path blackduck.crt --certificate-key-file-path blackduck.key >install.yaml
```
Execute teh above synopsysctl command to generate install.yaml file, this file will have all the required configuration to create all the resource for blackduck install.

## updates the install.yaml
cat the install.yaml file and update the lines given below to increase the storgae size for postgress DB and change teh storgae class with reclaim policy as "retain"
```
$ cat install.yaml
```

-> storage: 150Gi  (change it to 250Gi)
-> storageClassName: thin01 (change it to thin01.retain)
```
# Source: blackduck/templates/onprem-postgres.yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  labels:
    helm.sh/chart: blackduck-2020.10.1
    app: blackduck
    name: frb
    component: pvc
  name: frb-blackduck-postgres
  namespace: blackduck
spec:
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 250Gi
  storageClassName: thin01.retain
  ```
Update the storgae class name from thin01 to "thin01.retain" for Webapp application

```
  name: frb-blackduck-webapp
  namespace: blackduck
spec:
  accessModes:
  - ReadWriteOnce
  resources:
    requests:
      storage: 2Gi
  storageClassName: thin01.retain
  ```
after completing above edits to install.yaml file, save it and run below command to deploy it to "blackduck" namespace.
```
$ oc deploy -f install.yaml -n blackduck
```

# Install validation:

## Validate all resoureces:
```
$ oc get all -n blackduck
```
## Sample O/P:

```
NAME                                                 READY   STATUS      RESTARTS   AGE
pod/frb-blackduck-authentication-75b8f4d674-qgs78    1/1     Running     0          3d18h
pod/frb-blackduck-cfssl-6f6b76964f-gpx9v             1/1     Running     0          3d23h
pod/frb-blackduck-documentation-5859d44fbf-59xtc     1/1     Running     0          3d18h
pod/frb-blackduck-jobrunner-7f568d4d74-shxcg         1/1     Running     0          3d21h
pod/frb-blackduck-postgres-7d8685b65f-2gh62          1/1     Running     0          3d21h
pod/frb-blackduck-postgres-init-676mh                0/1     Completed   0          3d23h
pod/frb-blackduck-redis-6f8f4b6649-mhng5             1/1     Running     0          3d18h
pod/frb-blackduck-registration-7cc68d9c5b-zn2p5      1/1     Running     0          3d18h
pod/frb-blackduck-scan-5c6bfbf5d-8qx5b               1/1     Running     0          3d18h
pod/frb-blackduck-uploadcache-5f7b849987-bb6g6       1/1     Running     0          3d18h
pod/frb-blackduck-webapp-logstash-7bc5c56677-85nb5   2/2     Running     0          3d18h
pod/frb-blackduck-webserver-5dbf759cf8-cw5d5         1/1     Running     0          3d18h

NAME                                   TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)             AGE
service/frb-blackduck-authentication   ClusterIP   172.30.45.149    <none>        8443/TCP            3d23h
service/frb-blackduck-cfssl            ClusterIP   172.30.83.19     <none>        8888/TCP            3d23h
service/frb-blackduck-documentation    ClusterIP   172.30.248.143   <none>        8443/TCP            3d23h
service/frb-blackduck-logstash         ClusterIP   172.30.219.60    <none>        5044/TCP            3d23h
service/frb-blackduck-postgres         ClusterIP   172.30.129.16    <none>        5432/TCP            3d23h
service/frb-blackduck-redis            ClusterIP   172.30.212.97    <none>        8379/TCP            3d23h
service/frb-blackduck-registration     ClusterIP   172.30.97.188    <none>        8443/TCP            3d23h
service/frb-blackduck-scan             ClusterIP   172.30.9.27      <none>        8443/TCP            3d23h
service/frb-blackduck-uploadcache      ClusterIP   172.30.7.87      <none>        9443/TCP,9444/TCP   3d23h
service/frb-blackduck-webapp           ClusterIP   172.30.196.72    <none>        8443/TCP            3d23h
service/frb-blackduck-webserver        ClusterIP   172.30.218.7     <none>        443/TCP             3d23h

NAME                                            READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/frb-blackduck-authentication    1/1     1            1           3d23h
deployment.apps/frb-blackduck-cfssl             1/1     1            1           3d23h
deployment.apps/frb-blackduck-documentation     1/1     1            1           3d23h
deployment.apps/frb-blackduck-jobrunner         1/1     1            1           3d23h
deployment.apps/frb-blackduck-postgres          1/1     1            1           3d23h
deployment.apps/frb-blackduck-redis             1/1     1            1           3d23h
deployment.apps/frb-blackduck-registration      1/1     1            1           3d23h
deployment.apps/frb-blackduck-scan              1/1     1            1           3d23h
deployment.apps/frb-blackduck-uploadcache       1/1     1            1           3d23h
deployment.apps/frb-blackduck-webapp-logstash   1/1     1            1           3d23h
deployment.apps/frb-blackduck-webserver         1/1     1            1           3d23h

NAME                                                       DESIRED   CURRENT   READY   AGE
replicaset.apps/frb-blackduck-authentication-75b8f4d674    1         1         1       3d23h
replicaset.apps/frb-blackduck-cfssl-6f6b76964f             1         1         1       3d23h
replicaset.apps/frb-blackduck-documentation-5859d44fbf     1         1         1       3d23h
replicaset.apps/frb-blackduck-jobrunner-796c566986         0         0         0       3d23h
replicaset.apps/frb-blackduck-jobrunner-7f568d4d74         1         1         1       3d21h
replicaset.apps/frb-blackduck-postgres-7d8685b65f          1         1         1       3d23h
replicaset.apps/frb-blackduck-redis-6f8f4b6649             1         1         1       3d23h
replicaset.apps/frb-blackduck-registration-7cc68d9c5b      1         1         1       3d23h
replicaset.apps/frb-blackduck-scan-5c6bfbf5d               1         1         1       3d23h
replicaset.apps/frb-blackduck-uploadcache-5f7b849987       1         1         1       3d23h
replicaset.apps/frb-blackduck-webapp-logstash-7bc5c56677   1         1         1       3d23h
replicaset.apps/frb-blackduck-webserver-5dbf759cf8         1         1         1       3d23h

NAME                                    COMPLETIONS   DURATION   AGE
job.batch/frb-blackduck-postgres-init   1/1           2m21s      3d23h

NAME                                     HOST/PORT                                      PATH   SERVICES                  PORT       TERMINATION   WILDCARD
route.route.openshift.io/frb-blackduck   frb-blackduck-blackduck.apps.ocp.frbnpgs.com          frb-blackduck-webserver   port-443   passthrough   None

```
## Validate PV and PVC's
```
$ oc get pv | grep -i blackduck
```
## Sample O/P:
```
pvc-2f2e203d-2f62-43dd-9abb-66efffbdfe41   2Gi        RWO            Delete           Bound    blackduc/frb-blackduck-registration                            thin01                   6d23h
pvc-363a9777-3890-4189-81dd-3a9285fad009   250Gi      RWO            Retain           Bound    blackduc/frb-blackduck-postgres                                thin01.retain            6d23h
pvc-834ee1ad-9b08-477e-b8b3-ee6337518896   2Gi        RWO            Delete           Bound    blackduc/frb-blackduck-cfssl                                   thin01                   6d23h
pvc-a97f90f1-3e96-4eb2-a768-e78a9fd2a1fb   100Gi      RWO            Delete           Bound    blackduc/frb-blackduck-uploadcache-data                        thin01                   6d23h
pvc-ab12c6a7-1b7b-4ac6-8d43-748a1529e640   20Gi       RWO            Delete           Bound    blackduc/frb-blackduck-logstash                                thin01                   6d23h
pvc-f2e1ddaa-3881-406d-be4c-a608e78f2328   2Gi        RWO            Retain           Bound    blackduc/frb-blackduck-webapp                                  thin01.retain            6d23h
pvc-ff1d10bf-2072-4aa6-a0cb-f655485ff63b   2Gi        RWO            Delete           Bound    blackduc/frb-blackduck-authentication                    
```
```
$ oc get pvc -n blackduck
```
## Sample O/P:
```
NAME                             STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS    AGE
frb-blackduck-authentication     Bound    pvc-ff1d10bf-2072-4aa6-a0cb-f655485ff63b   2Gi        RWO            thin01          6d23h
frb-blackduck-cfssl              Bound    pvc-834ee1ad-9b08-477e-b8b3-ee6337518896   2Gi        RWO            thin01          6d23h
frb-blackduck-logstash           Bound    pvc-ab12c6a7-1b7b-4ac6-8d43-748a1529e640   20Gi       RWO            thin01          6d23h
frb-blackduck-postgres           Bound    pvc-363a9777-3890-4189-81dd-3a9285fad009   250Gi      RWO            thin01.retain   6d23h
frb-blackduck-registration       Bound    pvc-2f2e203d-2f62-43dd-9abb-66efffbdfe41   2Gi        RWO            thin01          6d23h
frb-blackduck-uploadcache-data   Bound    pvc-a97f90f1-3e96-4eb2-a768-e78a9fd2a1fb   100Gi      RWO            thin01          6d23h
frb-blackduck-webapp             Bound    pvc-f2e1ddaa-3881-406d-be4c-a608e78f2328   2Gi        RWO            thin01.retain   6d23h
```
## Validate web console.
Hit below url from webbrowser an you should be able to launch a blackduck login page
https://frb-blackduck-blackduck.apps.ocp.frbnpgs.com 
