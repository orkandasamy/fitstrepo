Blackduck images are available on Docksr Hub and shoul dbe pulled, Tagged and pushed into our internal repository for deploying the images during the installation of BlackDuck.

Images required for Black Install:
* synopsys-init:1.0.0
* blackduck-authentication:2020.10.1
* blackduck-cfssl:1.0.1
* blackduck-documentation:2020.10.1
* blackduck-jobrunner:2020.10.1
* postgresql-96-centos7:9.6
* blackduck-redis:2020.10.1
* blackduck-registration:2020.10.1
* blackduck-scan:2020.10.1
* blackduck-upload-cache:1.0.15
* blackduck-webapp:2020.10.1
* blackduck-logstash:1.0.6
* blackduck-nginx:1.0.26

# Pre-Requsites
* should have sudo access to run docker commands
* should have docker installed on the server to pull images.
* should have access to internet to pull images from docker HUB.
* should have access to intenal repository from the sevrer running the docker commands

# Commands to pull images from Docker
```
sudo docker pull docker.io/blackducksoftware/<image_name:tag>
```
### Example
sudo docker pull docker.io/blackducksoftware/blackduck-logstash:1.0.6

# Commands to tag images pulled from Docker
```
sudo docker tag <image-ID> <path-to-internal-repository>/<image_name:tag>
```
### Example:
sudo docker tag 3fea250387ce artrepo.firstrepublic.com:5101/dct_docker_local/blackducksoftware-2020-10-1/blackduck-logstash:1.0.6

# Commands to push images to artifactory repository
```
sudo docker push <path-to-internal-repository>/<image_name:tag>
```
### Example:
sudo docker push artrepo.firstrepublic.com:5101/dct_docker_local/blackducksoftware-2020-10-1/blackduck-authentication:2020.10.1
