# Instruction to Download and Install synopsysctl tool

ref: https://synopsys.atlassian.net/wiki/spaces/BDLM/pages/486801484/Prerequisites+for+Synopsysctl 

Use Synopsysctl in your Kubernetes or OpenShift cluster to deploy and manage several Synopsys software offerings, including Black Duck, OpsSight Connector, and Black Duck Alert. 
# Prerequsites
## Cluster requirements
Synopsysctl supports Kubernetes and Red Hat OpenShift. Your cluster must meet the following minimum requirements:

1) Kubernetes versions 1.9.x-1.17, or OpenShift versions 3.8-3.11, 4.1, 4.2, 4.3, 4.4, 4.5
2) Your cluster must have a reasonable level of common functionality that you'd expect in a cluster.
3) You must have a machine with kubectl (Kubernetes) or OC (OpenShift) installed.
4) Synopsysctl does not impose minimum requirements for CPU and memory, but you must note that Additional cluster requirements may be imposed by the software that you deploy with synopsysctl. For example, Black Duck has specific cluster requirements, such as CPU cores and RAM.

# Downloading synopsysctl tool
* The current latest version(2.0.1) of synopsysctl tar file for Linux is available above. (synopsysctl-linux-amd64-2.0.1.tar.gz)
* check and download a new version of the tool by going to the releases page on GitHub. 
(https://github.com/blackducksoftware/synopsysctl/releases)
* Under the releases tab, look for the synopsysctl utility that matches the architecture of the system on which you want to run synopsysctl. 

# Installing synopsysctl tool
* install the synopsysctl utility to a machine that has kubectl or oc installed. 
* Uncompress and un-tar the file that you downloaded:
```
tar -xvzf synopsysctl-linux-amd64-2.0.1.tar.gz
```
* To verify that you downloaded the correct version, run the following command:
```
./synopsysctl --version
```
