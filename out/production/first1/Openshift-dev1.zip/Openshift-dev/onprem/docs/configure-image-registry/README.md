# Creating NFS Persistent Storage for image-registry

#### Using the below steps you can create Persistent Storage using NFS Storage 

## Getting Started

The instructions given below with sample attached yaml files will help you to create persistent storage for image-registry

**Note:**
* You must update **image-registry-pv.yaml** file with environment specific NFS server IP and PATH as per your need before use it. 
  * Refer our SSOT for NFS server IP and filer/mount name we have in the storage server
* When you use these sample files, it will create
  * PV Name: image-registry-pv
  * PVC Name: image-registry-pvc

### Steps: 
1. NFS Storage must be mounted on the OpenShift Admin Host as /var/nfs mount in the respective environment.  
  This must be done by the LE team as part of cluster provisioning  
2. Create a folder in NFS storage to mount the PV. You can do this by SSH to the OCP Admin host on the respective environment  
```
ssh <ENV>ocpadm1v.<CLUSTERNAME>.<DOMAINNAME>
sudo su -
mkdir /var/nfs/image-registry-pv; chmod 777 /var/nfs/image-registry-pv
```
3. Login to respective OpenShift cluster and ensure that you have Cluster Admin access to OpenShift cluster before you proceed further
```
oc login <CLUSTER-API-URL>
```
4. Create the PV using the YAML file  
**IMPORTANT:**
* Before you start using the yaml files ensure that you
  * Update the image-registry-pv.yaml with correct NFS server IP and PATH 
```
oc create -f image-registry-pv.yaml
```
5. Create the PVC using the YAML file
```
oc create -f image-registry-pvc.yaml -n openshift-image-registry  
```
6. Update the config configs.imageregistry.operator.openshift.io as below(all these changes are in the key/value pair in SPEC section only)

* Set managementState as Managed
* Set "pvc" with claim name as "claim: image-registry-pvc" for storage

See below for **example** view

* **Note:**
  * You may see more lines in your live config
  * Here we pasted only for your understanding, you have to add it correctly in your file
  
```
$ oc edit configs.imageregistry.operator.openshift.io -o yaml 
spec:
  managementState: Managed
  storage:
    pvc:
      claim: image-registry-pvc
```
7. Validate the setup

**Check the PODs**
```
ayyadurai@npgsansiblecl2v configure-image-registry]$ oc get pods
NAME                                              READY   STATUS    RESTARTS   AGE
cluster-image-registry-operator-f88854665-vs59m   2/2     Running   0          26h
image-registry-5b755b86c9-jbgsh                   1/1     Running   0          2m5s
node-ca-24kwj                                     1/1     Running   0          4m16s
node-ca-84sv6                                     1/1     Running   0          4m16s
node-ca-b2kc9                                     1/1     Running   0          4m16s
node-ca-cn7pj                                     1/1     Running   0          4m16s
node-ca-dthsb                                     1/1     Running   0          4m16s
node-ca-pwxfk                                     1/1     Running   0          4m16s
node-ca-q5pqc                                     1/1     Running   0          4m16s
node-ca-rplvv                                     1/1     Running   0          4m16s
node-ca-szrhl                                     1/1     Running   0          4m16s
node-ca-tftsn                                     1/1     Running   0          4m16s
node-ca-xmfl8                                     1/1     Running   0          4m16s
[adm_sayyadurai@npgsansiblecl2v configure-image-registry]$ 

```
**Check the events** using the below command for any errors
```
$  oc get events --sort-by='.metadata.creationTimestamp'
```
8. Push the modified PV and PVC yaml files to environment specific folder
After you complete the setup, please push the YAML files you used to create the PV and PVC in to the environment specific folder in this GIT Repo 
