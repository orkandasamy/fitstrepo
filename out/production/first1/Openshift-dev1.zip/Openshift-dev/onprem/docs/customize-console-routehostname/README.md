# Customsing OpenShift Console URL name

#### Using the below steps you can customize the OpenShift Console URL name

## Getting started

The instructions given below will help you to customize the OpenShift Console URL name by patching the existing route **"console"**.

## Pre-requisites:
* Define the new console route hostname based on your environment. Replace everything within **\< \>** with right value
  * Naming standard is: **console.apps.\<CLUSTER-NAME\>.\<CLUSTER-DOMAINNAME\>**
* Ensure that you have the DNS entry already created and resolving to environment specific LB vIP 
  * **Note:**
    * In PROD(DC1) and DR(DC2), the route host name must resolve to environment specific LB vIP and NOT CNAME of the LB to avoid any mess during actual DR scenario
    * In other environments, it's ok to resolve environment specific LB or LB's CNAME

## Step-1: Login to the OpenShift Cluster
```
oc login <CLUSTER-API-URL>
```
## Step-2: Patch the existing route with new hostname. Before you run the below command, ensure that you replace **"\< \>"** with new route hostname
```
oc patch route/console --patch='{"spec": {"host": "<NEW-ROUTEHOSTNAME>"}}' -n openshift-console
```
## Step-3: Verify the changes
Check the route
```
oc describe route console -n openshift-console
```
Check DNS name
```
 nslookup console.apps.<CLUSTER-NAME>.<CLUSTER-DOMAINNAME>
```
## Step-4: Sample output
Patch the route
```
$ oc patch route/console --patch='{"spec": {"host": "console.apps.ocp.frbprod.com"}}' -n openshift-console
route.route.openshift.io/console patched
$
```
Verify the patched route
```
$ oc describe route console -n openshift-console
Name:                   console
Namespace:              openshift-console
Created:                6 weeks ago
Labels:                 app=console
Annotations:            openshift.io/host.generated=true
Requested Host:         console.apps.ocp.frbprod.com
                          exposed on router default (host apps.ocp.frbprod.com) 39 seconds ago
Path:                   <none>
TLS Termination:        reencrypt
Insecure Policy:        Redirect
Endpoint Port:          https

Service:        console
Weight:         100 (100%)
Endpoints:      10.129.0.60:8443, 10.130.0.78:8443
$ 
```
Check DNS name
```
$ nslookup console.apps.ocp.frbprod.com
Server:         10.0.9.81
Address:        10.0.9.81#53

console.apps.ocp.frbprod.com    canonical name = dc1apps.ocp.corp.firstrepublic.com.
Name:   dc1apps.ocp.corp.firstrepublic.com
Address: 10.0.6.214
$
```
