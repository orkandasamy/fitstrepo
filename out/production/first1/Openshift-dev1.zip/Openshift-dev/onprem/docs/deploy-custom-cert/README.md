# Pre-requisites:
* You must have a certificate for the FQDN and its corresponding private key with password
* The certificate must include the subjectAltName extension showing the FQDN.
* You must have cluster admin access to the OpenShift Cluster

# Naming standard
In-order to make the steps generic for all environment, use the below naming standard to name your files and ensure that you have the appropriate contents on it.
* **API Server Certificate**
  * api.cert.pem -> Contains API Server Certificate, intermediate and root CA certificate
  * api.key.pem  -> Contains UNENCRYPTED Private key of the API Server Certificate
* **Ingress router or Wildcard Certificate**
  * intermediate-root-ca.pem -> Contains the Intermediate/Sub-CA first and the root CA certificate
  * apps.cert.pem -> Contains Wild-card Certificate, Intermediate/Sub-CA and root CA certificates
  * apps.key.pem -> Contains UNENCRYPTED Private key of the Wild-card Certificate

# Preparing API Server Certificate
* Assuming that your API Server certificate you received in the below name(but it could be any name based on what you ordered). If not please change that file to the below name
  * api.rapidssl.pem or api.rapidssl.pfx
## Converting API Server Certificate from PFX to PEM format
```
openssl pkcs12 -in api.rapidssl.pfx -out api.rapidssl.pem -nodes -> //this will ask for the key passphrase ie Password
```
## Extracting private key of the API Server Certificate in UNENCRYPTED form
```
openssl rsa -in api.rapidssl.pem  -out api.key.pem -> //this may ask for the key passphrase(ie Password) if the PEM is protected with password
```
## Extracting API Server Certificate with intermediate and root CA from the PEM File
This is a manual process using the **cat** and **vi** command
```
$ cat api.rapidssl.pem
```
From the above output, copy the certificate, intermediate and root CA content and save it another file(**except private key**). Order of the content is must ie certificate, intermediate ca and then ends with root ca
```
$ vi api.cert.pem

<<<<PASTE YOUR CERTIFICATE, INTERMEDIATE AND ROOT CA CONTENT IN THE EDITOR AND THEN SAVE & QUIT>>>>
```
# Add an API Server Named Certificate

Ref: https://docs.openshift.com/container-platform/4.4/security/certificates/api-server.html

You must have 2 files with the name given below before proceed with API server cert install

* **api.cert.pem**
* **api.key.pem**

**Login to OpenShift Cluster**
```
oc login <CLUSTER-URL>
```
**Create a secret that contains the certificate chain and private key in the openshift-config namespace**
```
oc create secret tls api-cert --cert=api.cert.pem --key=api.key.pem -n openshift-config
```
**Check the secret** 
```
oc get secret api-cert -n openshift-config
```
```
oc describe secret api-cert -n openshift-config
```
**Update the API server to reference the created secret** 
* **Note:** Replace the **\<FQDN\>** with environment specific API Server URL(example: api.ocp.corp.frbnp1.com)
```
oc patch apiserver cluster --type=merge -p '{"spec":{"servingCerts": {"namedCertificates": [{"names": ["<FQDN>"], "servingCertificate": {"name": "api-cert"}}]}}}' 
```
**Examine the apiserver/cluster object and confirm the secret is now referenced**
```
oc get apiserver cluster -o yaml
```

# Preparing APPS wildcard certificate
* Assuming that your APPS wildcardr certificate you received in the below name(but it could be any name based on what you ordered). If not please change that file to the below name
  * apps.rapidssl.pem or apps.rapidssl.pfx
## Converting APPS wildcard certificate from PFX to PEM format
```
openssl pkcs12 -in apps.rapidssl.pfx -out apps.rapidssl.pem -nodes -> //this will ask for the key passphrase ie Password
```
## Extracting private key of the APPS wilcard certificate in UNENCRYPTED form
```
openssl rsa -in apps.rapidssl.pem -out apps.key.pem -> //this may ask for the key passphrase(ie Password) if the PEM is protected with password
```
## Extracting APPS wildcard Certificate and certificate chain from the PEM File
This is a manual process using the **cat** and **vi** command
```
$ cat apps.rapidssl.pem
```
From the above output, copy the certificate, intermediate and root CA content and save it another file(**except private key**). Order of the content is must ie certificate, intermediate ca and then ends with root ca
```
$ vi apps.cert.pem

<<<<PASTE YOUR CERTIFICATE, INTERMEDIATE AND ROOT CA CONTENT IN THE EDITOR AND THEN SAVE & QUIT>>>>
```
## Extracting intermediate and root CA from the PEM File
This is a manual process using the **cat** and **vi** command
```
$ cat apps.rapidssl.pem
```
From the above output, intermediate and root CA content and save it another file(**except certificate and private key**)
```
$ vi intermediate-root-ca.pem

<<<<PASTE YOUR INTERMEDIATE AND ROOT CA CONTENT IN THE EDITOR AND THEN SAVE & QUIT>>>>
```
# Deploying WILD CARD cert / Replacing default ingress certificate
Ref: https://docs.openshift.com/container-platform/4.4/security/certificates/replacing-default-ingress-certificate.html 

You must have the 4 files like below before proceed with replacing default ingress certificate

* **intermediate-root-ca.pem**
* **apps.cert.pem**
* **apps.key.pem**

**Important Note:** You must have your wild card cert with keychain in the order given below and without Private key
  * The wildcard certificate must be the first certificate in the file
  * One or more internediate certs
  * Finally the ROOT CA
  
**Login to OpenShift Cluster**
```
oc login <CLUSTER-URL>
```
**Create a ConfigMap that includes only the intermediate & root CA certificate used to sign the wildcard certificate**
```
oc create configmap custom-ca --from-file=ca-bundle.crt=intermediate-root-ca.pem -n openshift-config
```
**Update the cluster-wide proxy configuration with the newly created ConfigMap**
```
oc patch proxy/cluster --type=merge --patch='{"spec":{"trustedCA":{"name":"custom-ca"}}}'
```
**Create a secret that contains the wildcard certificate chain and key**
```
oc create secret tls apps-secret --cert=apps.cert.pem --key=apps.key.pem -n openshift-ingress
```
**Update the Ingress Controller configuration with the newly created secret**
```
oc patch ingresscontroller.operator default --type=merge -p '{"spec":{"defaultCertificate": {"name": "apps-secret"}}}' -n openshift-ingress-operator
```

