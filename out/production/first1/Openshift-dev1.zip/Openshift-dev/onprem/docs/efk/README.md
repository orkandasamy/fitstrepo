# Setup Elasticsearch, Fluentd and Kibana(EFK) stack

#### Using the below steps you setup EFK stack using CLI

## Getting started

The instructions given below with attached yaml files will help you to setup the EFK stack

Refer: 

Redhat doc: https://docs.openshift.com/container-platform/4.4/logging/cluster-logging-deploying.html

Example CRD: https://docs.openshift.com/container-platform/4.4/logging/cluster-logging-deploying-about.html

Example: Updating curator configmap: https://access.redhat.com/solutions/3496301

## Pre-requisites:
* You MUST have OpenShift cluster admin access

## Step-1: Download the YAML files 
Clone this repo and switch to this folder

**If your OpenShift version is 4.4** then no changes required to these files 
## Step-2: Login to the OpenShift cluster where you want to setup the EFK stack
```
oc login <CLUSTER-API-URL>
```
## Step-3: Create the required namespaces, objects for operators and instance using the YAML files
```
oc create -f elasticsearch-operator-namespace.yaml 
```
```
oc create -f cluster-logging-operator-namespace.yaml
```
```
oc create -f elasticsearch-operator-group-object.yaml
```
```
oc create -f elasticsearch-operator-subscription-object.yaml
```
```
oc create -f cluster-logging-operator-group-object.yaml
```
Verify the Operator installation: There should be an Elasticsearch Operator in each Namespace.
```
oc get csv --all-namespaces
```
```
oc create -f cluster-logging-operator-subscription-object.yaml
```
Verify the Operator installation: There should be a Cluster Logging Operator in the openshift-logging Namespace.
```
oc get csv -n openshift-logging
```
Create a Cluster Logging instance
```
oc create -f cluster-logging-operator-instance.yaml 
```
Modify **curator configmap** with custom retention period in **config.yaml** section
```
oc edit cm curator -n openshift-logging
```
Uncomment the existing lines and update the retention time as given below
```
  config.yaml: |
    # Logging example curator config file

    # uncomment and use this to override the defaults from env vars
      .defaults:
        delete:
          days: 7

    # to keep ops logs for a different duration:
      .operations:
        delete:
          weeks: 1
```
## Step-4: Validate the setup
**Check for the dpeloyment**
```
oc get deployment -n openshift-logging
```
**Check the PODs**
```
oc get pods -n openshift-logging
```
**Check the PVCs**
```
oc get pvc -n openshift-logging
```
**Check the PVs**
```
oc get pv | grep -i elastic
```
**Check the Events**
```
oc get events --sort-by='.metadata.creationTimestamp' -n openshift-logging
```
## Step-5: Setup log forwarding to Splunk
* Follow the steps documented at **https://github.firstrepublic.com/Middleware-Infra/Openshift/blob/dev/onprem/docs/efk/openshift-logforwarding-splunk/README.md**

## Step-6: Sample output for EFK Setup
```
$ oc get deployment -n  openshift-logging
NAME                           READY   UP-TO-DATE   AVAILABLE   AGE
cluster-logging-operator       1/1     1            1           5m43s
elasticsearch-cdm-f3r6yxqd-1   1/1     1            1           4m56s
elasticsearch-cdm-f3r6yxqd-2   1/1     1            1           4m52s
elasticsearch-cdm-f3r6yxqd-3   1/1     1            1           4m49s
kibana                         1/1     1            1           5m31s
$ 

$ oc get pods -n openshift-logging
NAME                                            READY   STATUS      RESTARTS   AGE
cluster-logging-operator-545cd49ccb-qqmld       1/1     Running     0          29m
curator-1602030600-5zwgl                        0/1     Completed   0          2m27s
elasticsearch-cdm-ubc4uvis-1-8475b8ffb6-r6n5h   2/2     Running     0          4m23s
elasticsearch-cdm-ubc4uvis-2-594db96868-j4msn   2/2     Running     0          4m20s
elasticsearch-cdm-ubc4uvis-3-84589775ff-hcwhc   2/2     Running     0          4m17s
fluentd-4h46n                                   1/1     Running     0          4m51s
fluentd-65rzm                                   1/1     Running     0          4m51s
fluentd-9wrc2                                   1/1     Running     0          4m51s
fluentd-nmvg2                                   1/1     Running     0          4m51s
fluentd-r5sjl                                   1/1     Running     0          4m51s
fluentd-xzmjs                                   1/1     Running     0          4m51s
kibana-6dbdcc584-zfzxx                          2/2     Running     0          4m53s
$

$ oc get pvc  -n openshift-logging
NAME                                         STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
elasticsearch-elasticsearch-cdm-ubc4uvis-1   Bound    pvc-1fe6998d-7b25-46e0-8ef2-e8f5db9b96b5   190735Mi   RWO            thin           4m58s
elasticsearch-elasticsearch-cdm-ubc4uvis-2   Bound    pvc-a198241b-4d33-4f66-9644-5d9d0f7469a3   190735Mi   RWO            thin           4m58s
elasticsearch-elasticsearch-cdm-ubc4uvis-3   Bound    pvc-f0c291d7-bf1f-498f-aa42-125666957ce1   190735Mi   RWO            thin           4m58s
$

$ oc get pv | grep -i elastic
pvc-1fe6998d-7b25-46e0-8ef2-e8f5db9b96b5   190735Mi   RWO            Delete           Bound         openshift-logging/elasticsearch-elasticsearch-cdm-ubc4uvis-1    thin                    4m58s
pvc-a198241b-4d33-4f66-9644-5d9d0f7469a3   190735Mi   RWO            Delete           Bound         openshift-logging/elasticsearch-elasticsearch-cdm-ubc4uvis-2    thin                    4m58s
pvc-f0c291d7-bf1f-498f-aa42-125666957ce1   190735Mi   RWO            Delete           Bound         openshift-logging/elasticsearch-elasticsearch-cdm-ubc4uvis-3    thin                    4m58s
$
```

