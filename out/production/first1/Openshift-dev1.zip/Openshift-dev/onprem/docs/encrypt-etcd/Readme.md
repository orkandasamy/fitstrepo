# Encrypting etcd data
By default, etcd data is not encrypted in OpenShift Container Platform. You can enable etcd encryption for your cluster to provide an additional layer of data security. For example, it can help protect the loss of sensitive data if an etcd backup is exposed to the incorrect parties.

When you enable etcd encryption, the following OpenShift API server and Kubernetes API server resources are encrypted:

- Secrets
- Config maps
- Routes
- OAuth access tokens
- OAuth authorize tokens

When you enable etcd encryption, encryption keys are created. These keys are rotated on a weekly basis. You must have these keys in order to restore from an etcd backup.

Refre: 
Redhat doc: https://docs.openshift.com/container-platform/4.5/security/encrypting-etcd.html 

## Pre-requisites: ##
You must have cluster admin access to the OpenShift Cluster.

**Login to OpenShift Cluster**
```
oc login <CLUSTER-URL>
```
# Enabling etcd encryption
You can enable etcd encryption to encrypt sensitive resources in your cluster.

**Procedure**
1. Modify the APIServer object and Set the encryption field type to aescbc :
```
$ oc patch apiserver cluster --type=merge -p '{"spec": {"encryption": {"type": "aescbc"}}}'
```
**Note:** 
* The aescbc type means that AES-CBC with PKCS#7 padding and a 32 byte key is used to perform the encryption.
* It can take 20 minutes or longer for this process to complete, depending on the size of your cluster.

2. Verify and ensure that **"spec"** section of the apiserver is as shown below.
```
$ oc describe apiserver
````
```
Spec:
  Encryption:
    Type:  aescbc
```
3. Verify that etcd encryption was successful.

Review the Encrypted status condition for the OpenShift API server to verify that its resources were successfully encrypted:
```
$ oc get openshiftapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'
```
 The output shows EncryptionCompleted upon successful encryption:
```
EncryptionCompleted
All resources encrypted: routes.route.openshift.io, oauthaccesstokens.oauth.openshift.io, oauthauthorizetokens.oauth.openshift.io
```
 If the output shows EncryptionInProgress, this means that encryption is still in progress. Wait a few minutes and try again.
 
 # Disabling etcd encryption
 You can disable encryption of etcd data in your cluster following below steps.

**Procedure**
 1. Modify the APIServer object and Set the encryption field type to identity:
```
$ oc patch apiserver cluster --type=merge -p '{"spec": {"encryption": {"type": "identity"}}}'
```
**Note:** The identity type is the default value and means that no encryption is performed.

2. Save the file to apply the changes.
The decryption process starts. It can take 20 minutes or longer for this process to complete, depending on the size of your cluster.
3. Verify that etcd decryption was successful.

Review the Encrypted status condition for the OpenShift API server to verify that its resources were successfully decrypted:
```
$ oc get openshiftapiserver -o=jsonpath='{range .items[0].status.conditions[?(@.type=="Encrypted")]}{.reason}{"\n"}{.message}{"\n"}'
```
The output shows DecryptionCompleted upon successful decryption:
```
DecryptionCompleted
Encryption mode set to identity and everything is decrypted
```
If the output shows DecryptionInProgress, this means that decryption is still in progress. Wait a few minutes and try again.
