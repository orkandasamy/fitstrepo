
# Pre-requisites:
* **LDAPS Server URL** for the environment you want to setup
  * You can retrieve the same from OpenShift Platform Admin Guide
* **Password for the service account z_ocpdomain** for the environment you want to bind to LDAPS server
  * You can retrieve the service account password from PUM  
* **kubeadmin** user password to get admin access to the OpenShift cluster
  * Password is available in PUM 
* Files required
  * **ocp4-ldap-customresource.yaml** - Custom Resource file for an LDAP identity Provider for your specific environment
  * **ocp4-ldap-sync.yaml** - Ldap server and query information to sync
  * **ocp4-ldap-whitelist.yaml** - List of AD Groups you want to whitelist (must with complete directory path)
  * **CA certificate** of the respective environment
    * You can download the CA cert from **\\\sfstore\IS-Installs\Certs** and save it in the name called **ca.crt**      
* Make the changes in the file
  * **Download the attached files and make the changes as required**
  * Replace the content we have in **\<\>** with correct value 
  * **ocp4-ldap-customresource.yaml** - Update the below with proper values
    * z_ocpdomain@\<DOMAIN-NAME\> 
      * Example: z_ocpdomain@corp.frbnp3.com
    * url: "\<GET THE LDAPS URL FROM PLATFORM ADMIN GUIDE\>"
      * Example: url: ldaps://vsaddsnp3.corp.frbnp3.com:636/DC=corp,dc=frbnp3,dc=com?sAMAccountName
  * **ocp4-ldap-sync.yaml**
    * url: ldaps://\<LDAPS-LB-FQDN:PORT\>
      * Example: url: ldaps://vsaddsnp3.corp.frbnp3.com:636
    * bindDN: z_ocpdomain@\<DOMAIN-NAME\>
      * Example: bindDN: z_ocpdomain@corp.frbnp3.com
    * bindPassword: '\<PASSWORD\>'
      * Example: bindPassword: 'ThisIsMyPasswordForMyServiceAccount:-)'
    * baseDN: "DC=\<SUB-DOMAIN\>,DC=\<DOMAIN\>,DC=com"
      * Example: baseDN: "DC=corp,DC=frbnp3,DC=com"
    * baseDN: "DC=\<SUB-DOMAIN\>,DC=\<DOMAIN\>,DC=com"
      * Example: baseDN: "DC=corp,DC=frbnp3,DC=com"
  * **ocp4-ldap-whitelist.yaml**
    * CHECK THE COMMENTED LINE IN THIS FILE AND TAKE ACTION ACCORDINGLY
 
**Ref:**
* https://docs.openshift.com/container-platform/4.5/authentication/identity_providers/configuring-ldap-identity-provider.html 
* https://docs.openshift.com/container-platform/4.5/authentication/ldap-syncing.html

## Step-1: Create LDAP Secret
Using the below command, create the LDAP secret 
```
oc login <CLUSTER-API-URL>
oc create secret generic ldap-secret --from-literal=bindPassword=<SERVICE-ACCOUNT-PASSWORD> -n openshift-config
```
## Step-2: Create a ConfigMap
The certificate authority must be stored in the ca.crt key of the ConfigMap. 
```
oc create configmap ca-config-map --from-file=ca.crt=</PATH/TO/ca.crt> -n openshift-config
```
## Step-3: Adding an identity provider to your clusters
Use the below command to add the identity provider
```
oc apply -f ocp4-ldap-customresource.yaml
```
## Step-4: Sync a subset of LDAP groups with OpenShift Container Platform
**Important Note:** 
* File named as **ca.crt** which contains environment specific CA certs **must exists in the current working directory**, otherwise sync will fail reporting ca.crt file does not exists

**Dry run**
```
oc adm groups sync --whitelist=<WHITELIST-FILE> --sync-config=<SYNC-CONFIG-FILE>
```
**Final run**
```
oc adm groups sync --whitelist=<WHITELIST-FILE> --sync-config=<SYNC-CONFIG-FILE> --confirm
```
## Step-5: Granting access to AD Groups
Once the sync is success, grant the access to the following groups
```
oc adm policy add-cluster-role-to-group cluster-admin gg_priv_ocp_clusteradmin
oc adm policy add-cluster-role-to-group view gg_priv_ocp_clusterview
oc adm policy add-cluster-role-to-group edit gg_priv_ocp_clusteredit
```
