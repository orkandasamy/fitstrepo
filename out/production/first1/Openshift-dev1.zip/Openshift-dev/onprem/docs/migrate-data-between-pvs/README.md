# Migrating data from one PV to another

The steps to migrate the data from one PV to another PV is clearly documented in RedHat website https://access.redhat.com/solutions/3181101

**Concept:** 
* Create a NEW PVC(and PV if its not getting dynamically created)
* Stop writing the data to the existing PV/PVC(you have to scaledown the PODs using this PV/PVC)
* Bring up a new container for this storage maitenance 
* Mount the existing and new PVC to this new container
* Login to this new container
* Migrate the data from existing PVC to new PVC using RSYNC command
* Exit from the container
* switch to the new PV/PVC in your application(in your application dc)
* Scale up your application PODs and verify that your application is using new PV/PVC
* Remove the maintenance POD
* Remove the old PVC( and PV if its not deleted dynamically)

## Migrating Prometheus and Alertmanager data from one PV to another
As Prometheus and Alertmanager expects predefined PVC names, you have to ensure that the new PVC name remain same as you have it right now. In order to acheive this, you have to migrate the data from existing PVC to temporary PVC and then migrate again to the new PVC created with default PVC names.

You can find the exact steps to migrate the data from one PV to another at https://github.firstrepublic.com/Middleware-Infra/Openshift/tree/dev/onprem/docs/migrate-data-between-pvs/openshift-monitoring
