# Migrating Prometheus and Alertmanager data from one PV to another

## Getting started

Ref: https://access.redhat.com/solutions/3181101

These steps will be used to migrate Prometheus and alertmanager data from one PV to another 

## Prerequisites
* Cluster admin access in the OpenShift Cluster

**Important Note:**

Attached **"cluster-monitoring-config.yaml"** will be used to restore the persistent storage for Prometheus & Alertmanager. Please review the file and ensure that you have the right information in it. 

## Migrating Prometheus and Alertmanager data
Clone this repo
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd ~/OpenShift/onprem/docs/migrate-data-between-pvs/openshift-monitoring/
```
Login to OpenShift Cluster and switch to openshift-monitoring project
```
oc login <CLUSTER-API-URL>
```
### Copy the data to temporary PVCs
Create the temporary PVCs using the attached YAML files
```
oc apply -f ~/OpenShift/onprem/docs/migrate-data-between-pvs/openshift-monitoring/alertmanager-temporary-pvc.yaml -n openshift-monitoring
```
```
oc apply -f ~/OpenShift/onprem/docs/migrate-data-between-pvs/openshift-monitoring/prometheus-temporary-pvc.yaml -n openshift-monitoring
```
Verify and ensure that PVCs "alertmanager-0, alertmanager-1, alertmanager-,2 prometheus-0 and prometheus-1" are created
```
oc get pvc -n openshift-monitoring
```
Start the sleep POD to migrate the data from existing PVC to TEMP PVC
```
oc -n openshift-monitoring run sleep --image=registry.access.redhat.com/rhel7/rhel-tools -- tail -f /dev/null 
```
Add Prometheus's and Alertmanager's existing volumes to the **Sleep** container
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-main-db-alertmanager-main-0 --claim-name=alertmanager-main-db-alertmanager-main-0 --mount-path=/old-alertmanager-main-db-alertmanager-main-0
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-main-db-alertmanager-main-1 --claim-name=alertmanager-main-db-alertmanager-main-1 --mount-path=/old-alertmanager-main-db-alertmanager-main-1
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-main-db-alertmanager-main-2 --claim-name=alertmanager-main-db-alertmanager-main-2 --mount-path=/old-alertmanager-main-db-alertmanager-main-2
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-k8s-db-prometheus-k8s-0 --claim-name=prometheus-k8s-db-prometheus-k8s-0  --mount-path=/old-prometheus-k8s-db-prometheus-k8s-0 
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-k8s-db-prometheus-k8s-1 --claim-name=prometheus-k8s-db-prometheus-k8s-1  --mount-path=/old-prometheus-k8s-db-prometheus-k8s-1
```
Add the temporary volumes to the **Sleep** container
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-0 --claim-name=alertmanager-0 --mount-path=/alertmanager-0
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-1 --claim-name=alertmanager-1 --mount-path=/alertmanager-1
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-2 --claim-name=alertmanager-2 --mount-path=/alertmanager-2
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-0 --claim-name=prometheus-0 --mount-path=/prometheus-0
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-1 --claim-name=prometheus-1 --mount-path=/prometheus-1
```
Login to the sleep pod to verify the mounts
```
oc -n openshift-monitoring rsh <CHOOSE_THE_LATEST_SLEEP_POD>
```
Run the "df -h" command on the container you logged in and verify that all mounts(refer value of the argument **--mount-path** in the above commands) are exists
```
df -h 
```
If you have the all PVCs mounted, go ahead with RSYNC(still you are in sleep pod)

**Note:** You may get rsync error while trying to sync **lost+found** directory which you can ignore
```
rsync -avxHAX --progress /old-alertmanager-main-db-alertmanager-main-0/* /alertmanager-0
```
```
rsync -avxHAX --progress /old-alertmanager-main-db-alertmanager-main-1/* /alertmanager-1
```
```
rsync -avxHAX --progress /old-alertmanager-main-db-alertmanager-main-2/* /alertmanager-2
```
```
rsync -avxHAX --progress /old-prometheus-k8s-db-prometheus-k8s-0/* /prometheus-0
```
```
rsync -avxHAX --progress /old-prometheus-k8s-db-prometheus-k8s-1/* /prometheus-1
```
Once the RSYNC is complete
* Come out of the sleep POD as we have done all what we need
* Delete the sleep dc so that it will release the PVCs we mounted there 
  * If you are not deleting the sleep pod, PVCs can't be released and you can't proceed further
```
oc delete dc sleep -n openshift-monitoring
```
### Restore the data from temporary PVCs to default PVCs name

Ensure that you dont have any sleep pods running, if exists delete sleep dc using the below command
```
oc delete dc sleep -n openshift-monitoring
```
Delete the default pvc names which has the data. **DO NOT delete the TEMP PVC** we created which has the data now.
```
oc delete pvc alertmanager-main-db-alertmanager-main-0 alertmanager-main-db-alertmanager-main-1 alertmanager-main-db-alertmanager-main-2 prometheus-k8s-db-prometheus-k8s-0 prometheus-k8s-db-prometheus-k8s-1 -n openshift-monitoring
```
Create the PVCs with same default name using the yaml files
```
oc apply -f alertmanager-default-pvc.yaml -n openshift-monitoring
```
```
oc apply -f prometheus-default-pvc.yaml -n openshift-monitoring
```
Verify and ensure that PVCs are ready
```
oc get pvc alertmanager-main-db-alertmanager-main-0 alertmanager-main-db-alertmanager-main-1 alertmanager-main-db-alertmanager-main-2 prometheus-k8s-db-prometheus-k8s-0 prometheus-k8s-db-prometheus-k8s-1 -n openshift-monitoring
```
Once the PVCs are ready, start the sleep POD to migrate the data from temporary PVC to newly created default PVC names
```
oc -n openshift-monitoring run sleep --image=registry.access.redhat.com/rhel7/rhel-tools -- tail -f /dev/null 
```
Add Prometheus's and Alertmanager's new volumes to the **Sleep** container
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-main-db-alertmanager-main-0 --claim-name=alertmanager-main-db-alertmanager-main-0 --mount-path=/new-alertmanager-main-db-alertmanager-main-0
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-main-db-alertmanager-main-1 --claim-name=alertmanager-main-db-alertmanager-main-1 --mount-path=/new-alertmanager-main-db-alertmanager-main-1
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-main-db-alertmanager-main-2 --claim-name=alertmanager-main-db-alertmanager-main-2 --mount-path=/new-alertmanager-main-db-alertmanager-main-2
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-k8s-db-prometheus-k8s-0 --claim-name=prometheus-k8s-db-prometheus-k8s-0  --mount-path=/new-prometheus-k8s-db-prometheus-k8s-0 
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-k8s-db-prometheus-k8s-1 --claim-name=prometheus-k8s-db-prometheus-k8s-1  --mount-path=/new-prometheus-k8s-db-prometheus-k8s-1
```
Add the temporary volumes to the **Sleep** container
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-0 --claim-name=alertmanager-0 --mount-path=/alertmanager-0
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-1 --claim-name=alertmanager-1 --mount-path=/alertmanager-1
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=alertmanager-2 --claim-name=alertmanager-2 --mount-path=/alertmanager-2
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-0 --claim-name=prometheus-0 --mount-path=/prometheus-0
```
```
oc -n openshift-monitoring set volume dc/sleep --add -t pvc --name=prometheus-1 --claim-name=prometheus-1 --mount-path=/prometheus-1
```
Login to the sleep pod to verify the mounts
```
oc -n openshift-monitoring rsh <CHOOSE_THE_LATEST_SLEEP_POD>
```
Run the "df -h" command on the container you logged in and verify that all mounts(refer value of the argument **--mount-path** in the above commands) are exists
```
df -h 
```
If you have the all PVCs mounted, go ahead with RSYNC(still you are in sleep pod)

**Note:** You may get rsync error while trying to sync **lost+found** directory which you can ignore
```
rsync -avxHAX --progress /alertmanager-0/* /new-alertmanager-main-db-alertmanager-main-0/
```
```
rsync -avxHAX --progress /alertmanager-1/* /new-alertmanager-main-db-alertmanager-main-1/
```
```
rsync -avxHAX --progress /alertmanager-2/* /new-alertmanager-main-db-alertmanager-main-2/
```
```
rsync -avxHAX --progress /prometheus-0/* /new-prometheus-k8s-db-prometheus-k8s-0/
```
```
rsync -avxHAX --progress /prometheus-1/* /new-prometheus-k8s-db-prometheus-k8s-1/
```
Once RSYNC is complete
* Come out of the sleep POD as we have done all what we need
* Delete the sleep dc so that it will release the PVCs we mounted there 
  * If you are not deleting the sleep pod, PVCs can't be released and you can't proceed further
```
oc delete dc sleep -n openshift-monitoring
```
Configure Prometheus and Alertmanager to use the persistent storage using the file **"cluster-monitoring-config.yaml"**
```
oc apply -f ~/OpenShift/onprem/docs/migrate-data-between-pvs/openshift-monitoring/cluster-monitoring-config.yaml -n openshift-monitoring
```
Verify and ensure that you see the old data in the Grafana
* Open the Grafana UI 
* Verify and ensure that you have the old data
Finally delete the temporary PVCs that we created
```
oc delete pvc alertmanager-0 alertmanager-1 alertmanager-2 prometheus-0 prometheus-1 -n openshift-monitoring
```
### Sample output
TBD
