# Setup monitoring stack ie Prometheus, Alertmanager and Grafana with Persistent Storage

#### Using the below steps you can setup Monitoring stack using CLI

## Getting started

Prometheus, Alertmanager and Grafana are default installed in OpenShift 4x. We need to configure the perssitent storage for Prometheus and Alertmanager components
The instructions given below with attached yaml files will help you to setup the persistentn storage for this monitoring stack

**Note:** This YAML file will help you setup
* Persistent Storage using "thin" storage class which is vSphere Volume in our platform
* Create PVCs for Prometheus and Alertmanager
  * Prometheus with 100Gi
  * Alertmanager with 20Gi
* Set the retention period as 15d
* If you want to make any changes to the storage size and/or retention period, please make the changes after you download the file and before apply this file

Refer: 

Redhat doc: https://docs.openshift.com/container-platform/4.5/monitoring/cluster_monitoring/configuring-the-monitoring-stack.html#prerequisites

## Pre-requisites:
* You MUST have OpenShift cluster admin access

## Step-1: Download the YAML files 
Clone this repo and switch to this folder
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd ~/Openshift/onprem/docs/monitoring-stack-setup/
```
## Step-2: Login to the OpenShift cluster where you want to setup the EFK stack
```
oc login <CLUSTER-API-URL>
```
## Step-3: Create the configmap and persistent storage using the YAML file
```
oc apply -f cluster-monitoring-config.yaml -n openshift-monitoring
```
## Step-4: Validate the setup

**Check the PVCs**
```
oc get pvc  -n openshift-monitoring
```
**Check the PVs**
```
oc get pv | egrep -i "prometh|alertman"
```
**Check the PODs**
```
oc get pods -n openshift-monitoring
```
**Check the Events**
```
oc get events --sort-by='.metadata.creationTimestamp' -n openshift-monitoring
```
## Step-5: Configure the alertmanager configuration:
**Print the currently active Alertmanager configuration into file alertmanager.yaml:**
```
oc -n openshift-monitoring get secret alertmanager-main --template='{{ index .data "alertmanager.yaml" }}' |base64 -d > alertmanager.yaml
```
**Make the necessary configuration changes in the above alertmanager.yaml to matfch to your env/cluster:**

**Refer to below for the SMTP details:**
* **AWS:**
  * **Non-prod SMTP:** 10.6.224.111:25
  * **Prod SMTP:** 10.0.8.85:25

* **On-Prem:**
  * **NP1:** np1mailgw01.corp.frbnp1.com:25
  * **NP2:** np2mailgw01.corp.frbnp2.com:25
  * **NP3:** np3mailgw01.corp.frbnp3.com:25
  * **DC1:** Vssmtp.corp.firstrepublic.com:25
  * **DC2:** Vssmtp.corp.firstrepublic.com:25

**Example alertmanager.yaml file we used for DC1 cluster is given below**
```
global:
  resolve_timeout: 5m
receivers:
  - name: Default
    email_configs:
      - to: OCP_Support@firstrepublic.com
        from: onprem-dc1-ocp-alert_manager@frbprod.com
        smarthost: 'Vssmtp.corp.firstrepublic.com:25'
        require_tls: false
  - name: Critical
    email_configs:
      - to: OCP_Support@firstrepublic.com
        from: onprem-dc1-ocp-alert_manager@frbprod.com
        smarthost: 'Vssmtp.corp.firstrepublic.com:25'
        require_tls: false
route:
  group_by:
    - namespace
  group_interval: 5m
  group_wait: 30s
  receiver: Default
  repeat_interval: 12h
  routes:
    - receiver: Default
      match:
        alertname: Watchdog
    - receiver: Critical
      match:
        severity: Critical
```        
**Apply the new configuration in the file:**
```
oc -n openshift-monitoring create secret generic alertmanager-main --from-file=alertmanager.yaml --dry-run -o=yaml |  oc -n openshift-monitoring replace secret --filename=-
```
**Note:**
Above steps can be completed manually through Openshift Console: https://team.corp.firstrepublic.com/sites/appsupport/OpenShiftAWS/_layouts/15/WopiFrame.aspx?sourcedoc=/sites/appsupport/OpenShiftAWS/Documents/Alert_Manager_Setup.docx&action=default

## Step-6: Remove the MachineWithNoRunningPhase (reference to Red Hat Case # 02786052)

**Find out the machine which not used with below command**
```
oc get machine -n openshift-machine-api     
```
**Sample output**
```
NAME                 PHASE          TYPE   REGION   ZONE   AGE
ocp-5tbmn-master-0   Provisioning                          34d
ocp-5tbmn-master-1   Provisioning                          34d
ocp-5tbmn-master-2   Provisioning                          34d
```
**Switch to the openshift-machine-api project**
```
oc project openshift-machine-api
```
**Remove the machine not used (TYPE: Provisioning) with “oc delete”**
```
oc delete machine/<MACHINE-NAME>
```
**Verify the following command doesn't return anything after machine are removed**
```
oc get machine -n openshift-machine-api
```
## Step-7: Sample output
```
$ oc get pvc  -n openshift-monitoring
NAME                                       STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
alertmanager-main-db-alertmanager-main-0   Bound    pvc-11f36dc4-2a9e-4bdf-abeb-8bf2531da344   20Gi       RWO            thin         21m
alertmanager-main-db-alertmanager-main-1   Bound    pvc-19dc2138-1613-416d-ac3a-39fa883a4dc0   20Gi       RWO            thin         21m
alertmanager-main-db-alertmanager-main-2   Bound    pvc-616f12c4-b4ee-4357-b196-c63fd8bfffd9   20Gi       RWO            thin         21m
prometheus-k8s-db-prometheus-k8s-0         Bound    pvc-882441ed-4c36-436e-9091-f496871a45c8   100Gi      RWO            thin         21m
prometheus-k8s-db-prometheus-k8s-1         Bound    pvc-f61fb21b-71c1-470e-a9a9-dca7c9071153   100Gi      RWO            thin         21m
$
```
```
$ oc get pv | egrep -i "prometh|alertman"
pvc-11f36dc4-2a9e-4bdf-abeb-8bf2531da344   20Gi       RWO            Delete           Bound    openshift-monitoring/alertmanager-main-db-alertmanager-main-0   thin                  41s
pvc-19dc2138-1613-416d-ac3a-39fa883a4dc0   20Gi       RWO            Delete           Bound    openshift-monitoring/alertmanager-main-db-alertmanager-main-1   thin                  40s
pvc-616f12c4-b4ee-4357-b196-c63fd8bfffd9   20Gi       RWO            Delete           Bound    openshift-monitoring/alertmanager-main-db-alertmanager-main-2   thin                  40s
pvc-882441ed-4c36-436e-9091-f496871a45c8   100Gi      RWO            Delete           Bound    openshift-monitoring/prometheus-k8s-db-prometheus-k8s-0         thin                  31s
pvc-f61fb21b-71c1-470e-a9a9-dca7c9071153   100Gi      RWO            Delete           Bound    openshift-monitoring/prometheus-k8s-db-prometheus-k8s-1         thin                  31s
$
```
```
$ oc get pods -n openshift-monitoring
NAME                                           READY   STATUS    RESTARTS   AGE
alertmanager-main-0                            5/5     Running   0          2m1s
alertmanager-main-1                            5/5     Running   0          2m1s
alertmanager-main-2                            5/5     Running   0          2m1s
cluster-monitoring-operator-5d47ccbbcf-cx2k9   2/2     Running   0          166m
grafana-57d6984dd-9q5t8                        2/2     Running   0          163m
kube-state-metrics-cf7bc857f-mgpkp             3/3     Running   0          167m
node-exporter-h27c2                            2/2     Running   0          28d
node-exporter-mc9rd                            2/2     Running   0          28d
node-exporter-rmz4h                            2/2     Running   0          28d
node-exporter-rv7fx                            2/2     Running   0          28d
node-exporter-xbn48                            2/2     Running   0          28d
node-exporter-xk2d6                            2/2     Running   0          28d
openshift-state-metrics-85b46b6f6c-rqmff       3/3     Running   0          163m
prometheus-adapter-dd8b664fc-bp55v             1/1     Running   0          167m
prometheus-adapter-dd8b664fc-xkb7r             1/1     Running   0          163m
prometheus-k8s-0                               7/7     Running   1          112s
prometheus-k8s-1                               7/7     Running   1          111s
prometheus-operator-fcb684866-m28lr            2/2     Running   2          166m
telemeter-client-fc6667c75-rxzrm               3/3     Running   0          163m
thanos-querier-66d54d4f6-sfhj5                 4/4     Running   0          167m
thanos-querier-66d54d4f6-t5snk                 4/4     Running   0          163m
$
```
