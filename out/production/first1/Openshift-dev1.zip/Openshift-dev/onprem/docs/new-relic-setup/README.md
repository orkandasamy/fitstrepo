# Pre-requisites:
* You must have
  * **Cluster Admin access** in OpenShift Cluster
  * **New Relic Account** to access the dashboard. New-Relic site can be accessed 
    * Go to FRB Apps Website https://frbapps.firstrepublic.com/index.html
    * Search for New-Relic and click on it and sign in using SSO    

# Preparing the YAML files 

* Required definitions are avialable in the attached files
    * If you don't find the yaml file for the environment you want to setup, please contact Matt Stump and get it from him
* Use the yaml file for the cluster you need

# Login to OpenShift Cluster and create the namespace "mware-new-relic"

```
oc login <CLUSTER-API-URL>
```
```
oc new-project newrelic
```
# Add Service Accounts to privileged Security Context Constraints
```
oc adm policy add-scc-to-user privileged system:serviceaccount:newrelic:nri-kube-state-metrics
oc adm policy add-scc-to-user privileged system:serviceaccount:newrelic:nri-newrelic-infrastructure
oc adm policy add-scc-to-user privileged system:serviceaccount:newrelic:nri-nri-kube-events
oc adm policy add-scc-to-user privileged system:serviceaccount:newrelic:nri-prometheus
```
# Verify that Service Accounts are added to privileged SCC
```
oc describe scc privileged | grep "Users:"
```

# Apply correct YAML file required for your cluster
```
oc -n newrelic apply -f <YAML-FILE-NAME>
```
# Verify the setup
* No errors reported for any depolyment config or pods or repliacset etc
```
oc get all -n newrelic
```
* Verify the events
```
oc get events --sort-by='.metadata.creationTimestamp' -n newrelic
```
* Important step to be verified: 
  * Ensure that there is no newrelic webhook deployed 
```
oc get MutatingWebhookConfiguration
```
  * If any newrelic webhook exists, please delete them
```
oc delete MutatingWebhookConfiguration <NEWRELIC-WEBHOOK-NAME>
```
# Sample output is given below
```
TBD
```
# Troubleshooting
* If you get the below error, edit the YAML file you applied and change the runasuser value to something valid and within the range mentioned in the error message
```
$ oc describe replicaset.apps/nri-nri-kube-events-776cbc66d | egrep -A7 "Events:"
Events:
  Type     Reason        Age                 From                   Message
  ----     ------        ----                ----                   -------
  Warning  FailedCreate  22s (x14 over 63s)  replicaset-controller  Error creating: pods "nri-nri-kube-events-776cbc66d-" is forbidden: unable to validate against any security context constraint: [spec.containers[0].securityContext.securityContext.runAsUser: Invalid value: 1001310001: must be in the ranges: [1001350000, 1001359999] spec.containers[1].securityContext.securityContext.runAsUser: Invalid value: 1001310001: must be in the ranges: [1001350000, 1001359999]]
$
```
* If you get the below error, ensure that the service accounts are added to the scc privileged groups
```
$ oc describe daemonset.apps/nri-newrelic-infrastructure | egrep -A7 "Events:"
Events:
  Type     Reason        Age                  From                  Message
  ----     ------        ----                 ----                  -------
  Warning  FailedCreate  3m16s (x17 over 6m)  daemonset-controller  Error creating: pods "nri-newrelic-infrastructure-" is forbidden: unable to validate against any security context constraint: [provider restricted: .spec.securityContext.hostNetwork: Invalid value: true: Host network is not allowed to be used spec.volumes[0]: Invalid value: "hostPath": hostPath volumes are not allowed to be used spec.volumes[1]: Invalid value: "hostPath": hostPath volumes are not allowed to be used spec.volumes[2]: Invalid value: "hostPath": hostPath volumes are not allowed to be used spec.volumes[3]: Invalid value: "hostPath": hostPath volumes are not allowed to be used spec.containers[0].securityContext.privileged: Invalid value: true: Privileged containers are not allowed spec.containers[0].securityContext.hostNetwork: Invalid value: true: Host network is not allowed to be used]
$
```
# Steps to remove Newrelic setup
* Login to OCP Cluster
```
oc login <CLUSTER-API-URL>
```
* Ensure that there is no newrelic webhook exists, if exists, remove it
```
oc get MutatingWebhookConfiguration
```
```
oc delete MutatingWebhookConfiguration <NEWRELIC-WEBHOOK-NAME>
```
* Run the below command with the YAML file used to setup the cluster
```
oc delete -f <YAML-FILE-NAME>
```
* Remove the service account(s) from the scc privileged group
```
oc adm policy remove-scc-from-user privileged system:serviceaccount:newrelic:nri-kube-state-metrics
```
```
oc adm policy remove-scc-from-user privileged system:serviceaccount:newrelic:nri-newrelic-infrastructure
```
```
oc adm policy remove-scc-from-user privileged system:serviceaccount:newrelic:nri-nri-kube-events
```
```
oc adm policy remove-scc-from-user privileged system:serviceaccount:newrelic:nri-prometheus
```
* Delete the project newrelic
```
oc delete project newrelic
```

