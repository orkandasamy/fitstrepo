# Creating and Testing Persistent Volume using NFS Storage 

#### Using the below steps you can Create and Test Persistent Volume using NFS Storage 

## Getting Started

The instructions given below with sample attached yaml files will help you to create and test persistent volume using NFS storage.
**Note:**
* You must have the project called **mware-infra** created in the cluster
* You must update the **mware-infra-pv.yaml** file with environment specific NFS server IP and PATH as per your need before use it. Refer our SSOT for NFS server IP and filer/mount name we have in the storage server
* When you use these sample files, it will create
  * PV Name: mware-infra-pv
  * PVC Name: mware-infra-pvc
  * POD Name: mware-infra-test-pod

### Steps: 
1. NFS Storage must be mounted on the OpenShift Admin Host as /var/nfs mount in the respective environment.  
  This must be done by the LE team as part of cluster provisioning  
2. Create a folder in NFS storage to mount the PV. You can do this by SSH to the OCP Admin host on the respective environment  
```
ssh <ENV>ocpadm1v.<CLUSTERNAME>.<DOMAINNAME>
sudo su -
mkdir /var/nfs/mware-infra-pv; chmod 777 /var/nfs/mware-infra-pv
```
3. Login to respective OpenShift cluster and ensure that you have Cluster Admin access to OpenShift cluster before you proceed further
```
oc login <CLUSTER-API-URL>
```
4. Create the PV using the YAML file. **Before you start using the yaml files ensure that you update the mware-infra-pv.yaml with correct NFS server IP and PATH**
```
oc create -f mware-infra-pv.yaml
```
5. Create the PVC using the YAML file
```
oc create -f mware-infra-pvc.yaml -n mware-infra
```
6. Create the POD using the file
```
oc create -f mware-infra-pod.yaml -n mware-infra
```
7. Validate the POD by checking the events, logs etc
```
oc get pods
oc get events
oc logs <POD-NAME>
```  
## Sample Output for Reference
**Create a folder on the NFS storage, change the permission to 777:**
```
[adm_sayyadurai@np3ocpadm1v ~]$ mkdir /var/nfs/mware-infra-pv; chmod 777 /var/nfs/mware-infra-pv;
[adm_sayyadurai@np3ocpadm1v ~]$ ls -ltr /var/nfs/
total 65276
drwxrwxrwx. 2 nfsnobody      nfsnobody      4096 Sep  4 11:46 mware-infra-pv
[adm_sayyadurai@np3ocpadm1v ~]$ 
```
**Create PV:**
```
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc create -f mware-infra-pv.yaml  
persistentvolume/mware-infra-pv created
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc get pv
NAME             CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM                         STORAGECLASS   REASON   AGE
mware-infra-pv   1Gi        RWO            Retain           Available   mware-infra/mware-infra-pvc                           4s
[adm_sayyadurai@npgsansiblecl2v PVTest]$
```
**Create PVC:**
```
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc create -f mware-infra-pvc.yaml 
persistentvolumeclaim/mware-infra-pvc created
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc get pvc
NAME              STATUS   VOLUME           CAPACITY   ACCESS MODES   STORAGECLASS   AGE
mware-infra-pvc   Bound    mware-infra-pv   1Gi        RWO            thin           5s
[adm_sayyadurai@npgsansiblecl2v PVTest]$
```
**Create POD:**
```
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc create -f mware-infra-pod.yaml   
pod/mware-infra-test-pod created
[adm_sayyadurai@npgsansiblecl2v PVTest]$ 
```
**Check the POD status:**
```
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc get pods
NAME                   READY   STATUS    RESTARTS   AGE
mware-infra-test-pod   1/1     Running   0          118s
[adm_sayyadurai@npgsansiblecl2v PVTest]$ 

```
**Check the EVENTS:**
```
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc get events
LAST SEEN   TYPE      REASON                         OBJECT                      MESSAGE
<unknown>   Normal    Scheduled                      pod/mware-infra-test-pod    Successfully assigned mware-infra/mware-infra-test-pod to np3ocpwkr7v.ocp.corp.frbnp3.com
13s         Normal    Pulling                        pod/mware-infra-test-pod    Pulling image "artrepo.firstrepublic.com:5101/busybox"
10s         Normal    Pulled                         pod/mware-infra-test-pod    Successfully pulled image "artrepo.firstrepublic.com:5101/busybox"
10s         Normal    Created                        pod/mware-infra-test-pod    Created container mware-infra-test-container
10s         Normal    Started                        pod/mware-infra-test-pod    Started container mware-infra-test-container
[adm_sayyadurai@npgsansiblecl2v PVTest]$ 
```
**Check the LOGS:**
```
[adm_sayyadurai@npgsansiblecl2v PVTest]$ oc logs mware-infra-test-pod
<<<< SANKARA:: There is no log yet, so its empty return >>>
[adm_sayyadurai@npgsansiblecl2v PVTest]$
```
**SSH to POD and check for the data:**
```
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc rsh mware-infra-test-pod
/ # hostname 
mware-infra-test-pod
/ # pwd
/
/ # ls -ltr /mware-infra-pv/mware-infra-test-pod.log 
-rw-r--r--    1 nobody   nobody          18 Sep 17 21:57 /mware-infra-pv/mware-infra-test-pod.log
/ # cat /mware-infra-pv/mware-infra-test-pod.log 
1600379813: START
/ # 
[adm_sayyadurai@npgsansiblecl2v pvtest]$
```
