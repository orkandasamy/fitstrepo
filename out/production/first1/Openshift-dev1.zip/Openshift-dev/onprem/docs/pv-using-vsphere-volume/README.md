# Creating and Testing Persistent Volume using vSphere Volume Storage 

#### Using the below steps you can Create and Test Persistent Volume using vSphere Volume Storage 

## Getting Started

The instructions given below with sample attached yaml files will help you to create and test persistent volume using vSphere Volume storage.

**Note:**
* You must have the project called **mware-infra** created in the cluster
* Use the below files to create the PVC and POD. **FYI:** PV would be created dynamically
  * PVC: pvc-using-vsphere-storage.yaml
  * POD: pod-using-vsphere-storage.yaml
* No changes required in the YAML files

### Steps: 
1. vSphere Volume must be setup by Linux Engineering Team an ready to use by us
2. Login to respective OpenShift cluster and ensure that you have Cluster Admin access to OpenShift cluster before you proceed further
```
oc login <CLUSTER-API-URL>
```
3. Create PVC using the YAML file
```
oc create -f pvc-using-vsphere-storage.yaml -n mware-infra
```
4. Create the POD using the file
```
oc create -f pod-using-vsphere-storage.yaml -n mware-infra
```
5. Validate the POD by checking the events, logs etc
```
oc get pods
```
```
oc get events --sort-by='.metadata.creationTimestamp'
```
```
oc logs <POD-NAME>
```  
6. Login to the POD and ensure that data is persistent and then exit from the POD
```
oc rsh mware-infra-vsphere-pod 
```
```
/ # cat /data/log
```
```
/ # exit
```
7. Delete and recreate teh POD alone again and ensure that data is exists
```
oc delete -f pod-using-vsphere-storage.yaml -n mware-infra
```
```
oc create -f pod-using-vsphere-storage.yaml -n mware-infra
```
```
oc get pods
```
```
oc get events --sort-by='.metadata.creationTimestamp'
```
```
oc logs <POD-NAME>
```  
```
oc rsh mware-infra-vsphere-pod 
```
```
/ # cat /data/log
```
```
/ # exit
```
## Sample Output for Reference

```
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc project mware-infra
Now using project "mware-infra" on server "https://api.ocp.corp.frbnp1.com:6443".
[adm_sayyadurai@npgsansiblecl2v pvtest]$
```

```
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc create -f pvc-using-vsphere-storage.yaml
persistentvolumeclaim/mware-infra-vsphere-pvc created
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pvc
NAME                      STATUS    VOLUME           CAPACITY   ACCESS MODES   STORAGECLASS   AGE
mware-infra-pvc           Bound     mware-infra-pv   1Gi        RWO            thin           43h
mware-infra-vsphere-pvc   Pending                                              thin           31s
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pvc
NAME                      STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
mware-infra-pvc           Bound    mware-infra-pv                             1Gi        RWO            thin           43h
mware-infra-vsphere-pvc   Bound    pvc-069e895d-6d12-4e2c-af36-1ccf177cf70d   1Gi        RWO            thin           42s
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pv | egrep "NAME|mware-infra-vsphere-pvc"
NAME                                       CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM                                                           STORAGECLASS         REASON   AGE
pvc-069e895d-6d12-4e2c-af36-1ccf177cf70d   1Gi        RWO            Delete           Bound       mware-infra/mware-infra-vsphere-pvc                             thin                          59s
[adm_sayyadurai@npgsansiblecl2v pvtest]$

[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc create -f pod-using-vsphere-storage.yaml 
pod/mware-infra-vsphere-pod created
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pods
NAME                       READY   STATUS              RESTARTS   AGE
mware-infra-test-pod       0/1     ContainerCreating   0          43h
mware-infra-vsphere-pod    1/1     Running             0          31s
wealth-test-app-1-deploy   0/1     Completed           0          16h
wealth-test-app-1-f4tt7    1/1     Running             0          16h
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc rsh mware-infra-vsphere-pod 
/ # ls -ltr /data/
total 20
drwx------    2 root     root         16384 Oct  1 17:51 lost+found
-rw-r--r--    1 root     root            18 Oct  1 17:51 log
/ # cat /data/log
1601574663: START
/ # 
command terminated with exit code 130
[adm_sayyadurai@npgsansiblecl2v pvtest]$

[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get events --sort-by='.metadata.creationTimestamp'
LAST SEEN   TYPE      REASON                   OBJECT                                          MESSAGE
9m12s       Normal    Started                  pod/vsphere-pod                                 Started container busybox
9m12s       Normal    Created                  pod/vsphere-pod                                 Created container busybox
9m13s       Normal    Pulled                   pod/vsphere-pod                                 Container image "artrepo.firstrepublic.com:5101/busybox" already present on machine
102s        Warning   FailedMount              pod/mware-infra-test-pod                        Unable to attach or mount volumes: unmounted volumes=[mware-infra-pv], unattached volumes=[mware-infra-pv default-token-7hslj]: timed out waiting for the condition
71m         Warning   FailedMount              pod/mware-infra-test-pod                        Unable to attach or mount volumes: unmounted volumes=[mware-infra-pv], unattached volumes=[default-token-7hslj mware-infra-pv]: timed out waiting for the condition
33m         Warning   FailedMount              pod/mware-infra-test-pod                        (combined from similar events): Unable to attach or mount volumes: unmounted volumes=[mware-infra-pv], unattached volumes=[mware-infra-pv default-token-7hslj]: timed out waiting for the condition
7m43s       Normal    Killing                  pod/vsphere-pod                                 Stopping container busybox
6m43s       Normal    ProvisioningSucceeded    persistentvolumeclaim/mware-infra-vsphere-pvc   Successfully provisioned volume pvc-069e895d-6d12-4e2c-af36-1ccf177cf70d using kubernetes.io/vsphere-volume
5m34s       Normal    Scheduled                pod/mware-infra-vsphere-pod                     Successfully assigned mware-infra/mware-infra-vsphere-pod to ocp-rv6lj-worker-p86s7
5m31s       Normal    SuccessfulAttachVolume   pod/mware-infra-vsphere-pod                     AttachVolume.Attach succeeded for volume "pvc-069e895d-6d12-4e2c-af36-1ccf177cf70d"
4m32s       Normal    AddedInterface           pod/mware-infra-vsphere-pod                     Add eth0 [10.131.0.48/23]
4m32s       Normal    Pulled                   pod/mware-infra-vsphere-pod                     Container image "artrepo.firstrepublic.com:5101/busybox" already present on machine
4m32s       Normal    Started                  pod/mware-infra-vsphere-pod                     Started container busybox
4m32s       Normal    Created                  pod/mware-infra-vsphere-pod                     Created container busybox
[adm_sayyadurai@npgsansiblecl2v pvtest]$
```

```
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc delete pod mware-infra-vsphere-pod 
pod "mware-infra-vsphere-pod" deleted
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pods
NAME                       READY   STATUS              RESTARTS   AGE
mware-infra-test-pod       0/1     ContainerCreating   0          43h
wealth-test-app-1-deploy   0/1     Completed           0          16h
wealth-test-app-1-f4tt7    1/1     Running             0          16h
[adm_sayyadurai@npgsansiblecl2v pvtest]$ 


[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc create -f pod-using-vsphere-storage.yaml         
pod/mware-infra-vsphere-pod created
[adm_sayyadurai@npgsansiblecl2v pvtest]$

[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pods
NAME                       READY   STATUS              RESTARTS   AGE
mware-infra-test-pod       0/1     ContainerCreating   0          43h
mware-infra-vsphere-pod    1/1     Running             0          23s
wealth-test-app-1-deploy   0/1     Completed           0          16h
wealth-test-app-1-f4tt7    1/1     Running             0          16h
[adm_sayyadurai@npgsansiblecl2v pvtest]$ 


[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc rsh mware-infra-vsphere-pod                                
/ # cat /data/log
1601574663: START
1601575140: START
/ # 
command terminated with exit code 130
[adm_sayyadurai@npgsansiblecl2v pvtest]$ 

[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pvc
NAME                      STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
mware-infra-pvc           Bound    mware-infra-pv                             1Gi        RWO            thin           43h
mware-infra-vsphere-pvc   Bound    pvc-069e895d-6d12-4e2c-af36-1ccf177cf70d   1Gi        RWO            thin           10m
[adm_sayyadurai@npgsansiblecl2v pvtest]$ oc get pv | egrep "NAME|mware-infra-vsphere-pvc"
NAME                                       CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS      CLAIM                                                           STORAGECLASS         REASON   AGE
pvc-069e895d-6d12-4e2c-af36-1ccf177cf70d   1Gi        RWO            Delete           Bound       mware-infra/mware-infra-vsphere-pvc                             thin                          11m
[adm_sayyadurai@npgsansiblecl2v pvtest]$ 
```
