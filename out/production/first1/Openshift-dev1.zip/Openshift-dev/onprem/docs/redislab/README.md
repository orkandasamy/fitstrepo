# Setup or remove Redis Cluster

*Pre-requisites:*
* You must have oc version 4.4 or above
* You must have cluster admin access in the OpenShift Cluster

*Ref:* 

**Redis Cluster Setup:** https://github.com/RedisLabs/redis-enterprise-k8s-docs/tree/v6.0.12-5

**Configure LDAP Authentication:** https://docs.redislabs.com/latest/platforms/kubernetes/tasks/ldap-on-k8s/

**Updating SSL/TLS Certificates for Redis Console UI:** https://docs.redislabs.com/latest/rs/administering/cluster-operations/updating-certificates/

**Base Location for Redis Documentation:** https://docs.redislabs.com/latest/platforms/kubernetes

**Redis Support Portal:** https://app.redislabs.com/#/login

## Setting up Redis Cluster

**Clone this repo**
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd ~/Openshift/onprem/docs/redislab/
```
**Login to the OCP cluster**
```
oc login <CLUSTER-API-URL>
```
**Create a new project**
```
oc new-project <PROJECT-NAME>
```
**Create new scc group "redis-enterprise-scc"**
```
oc apply -f ~/Openshift/onprem/docs/redislab/scc.yaml
```
**Add the PROJECT-NAME to the scc group created above**
```
oc adm policy add-scc-to-group redis-enterprise-scc system:serviceaccounts:<PROJECT-NAME>
```
**Deploy the OpenShift operator bundle**
* *Important:* Your OC client version must be 4.4 and above, otherwise it will fail
```
oc apply -f ~/Openshift/onprem/docs/redislab/openshift.bundle.yaml
```
##Verify and ensure that **redis-enterprise-operator** deployment, replicaset and pod in running state before you proceed further
```
oc get all -n <PROJECT-NAME>
```
**Apply the RedisEnterpriseCluster resource with RHEL7 based images**
```
oc apply -f ~/Openshift/onprem/docs/redislab/rec_rhel.yaml
```
**Validate and ensure that everything is up**
```
oc get all -n <PROJECT-NAME>
```
**Validate and ensure that PVCs got created. It may take a while, please wait for 5 mins**
```
oc get pvc -n <PROJECT-NAME>
```
**Check the events for any errors**
```
oc get events --sort-by='.metadata.creationTimestamp' -n <PROJECT-NAME>
```
**Create the route to access the redis cluster**
```
oc create route passthrough --service=rec-ui --hostname=<PROJECT-NAME>.<DOMAIN-NAME> -n <PROJECT-NAME> 
```
**Ensure that route got created**
```
oc get routes -n <PROJECT-NAME>
```
**Ensure that your route hostname is resolving the respective OpenShift Cluster LB CNAME**
```
nslookup <PROJECT-NAME>.<DOMAIN-NAME>
```
**Retrieve the admin user password stored in the secret**
```
oc get secrets rec --template={{.data.password}} | base64 -d
```
## Deploy the license key
* Ensure that you got the license key from vendor(RedisLabs)
* License key must be matching with redis service name(not the route hostname you created)
* Open redis cluster console UI using the route hostname you created above with admin credentials
  * Go to **"Settings"** => **"general"** tab 
  * Paste the license key in **"Cluster key"** text box
  * Come to bottom of the page and click on **"Save"**
* Verify and ensure that you dont see the messge "trial version" anywhere on the screen

## Setup LDAP auth for redis cluster login

**Below steps must be complete in all Redis PODs**
* SSH to redis pod ie rec-\[0|1|2\] one by one
```
oc rsh pod/rec-0 
```
* Create the folder **"/opt/persistent/ldap"**
```
mkdir /opt/persistent/ldap
```
* Create the file **"/opt/persistent/ldap/saslauthd.conf"** with right LDAP setting information for your environment
```
vi /opt/persistent/ldap/saslauthd.conf

ldap_servers: ldaps://vsaddsnp2.corp.frbnp2.com:636
ldap_search_base: DC=corp,DC=frbnp2,DC=com
ldap_filter: (sAMAccountName=%u)
ldap_bind_dn: CN=z_ocpdomain,OU=Service Accounts,OU=Management,DC=corp,DC=frbnp2,DC=com
ldap_password: MYPASSWORD
ldap_tls_cacert_file: /opt/persistent/ldap/ca.pem
```
* **Note:** If you want to enable debug mode to troubleshoot the LDAP connectivity, append **ldap_debug: 7** to the above file
* Create the file **"/opt/persistent/ldap/ca.pem"** which should contain the CA cert of the LDAP Server certificate
```
vi /opt/persistent/ldap/ca.pem
<Copy and paste the content of the LDAP Server's CA Cert>
```
* Apply the ldap config
```
rladmin cluster config saslauthd_ldap_conf /opt/persistent/ldap/saslauthd.conf
```
* Restart ldap authd service
```
supervisorctl restart saslauthd
```
* Verify LDAP auth setup
  * Login to redis cluster console with default admin credentials
  * Go to **"access control"** => **"users"** tab and add your adm account and set the **authentication as LDAP** & save it. Without this, you can't use your id to login after setting up the LDAP auth
  * Logout from your default admin session and then login back with your adm credential, it should work
* Verify the log for any issues(enable debug as required)
```
tail -f /var/opt/redislabs/log/saslauthd_stderr.log
```
**Updating SSL/TLS Certificates for Redis Console UI**
* To update TLS certificate for the Redis Console UI, you have follow the below steps. **Do not apply the cert in the OpenShift route**
  * Get TLS certificate for your route hostname
  * Extract the PRIVATE KEY in UNENCRYPTED format and save it PEM format
  * Extract the cert chain in the order of CERTIFICATE, INTERMEDIATE CA and finally ROOT CA and save it PEM format
  * You need to copy these two files to redis pod after you login to that pod
* Login to one of the redis POD and runt the below command
```
oc rsh rec-0
```
```
rladmin cluster certificate set cm certificate_file <CERT-CHAIN.PEM> key_file <PRIVATE-KEY.PEM>
```
**Create DB via Redis Console UI**
* Login to Redis console UI
  * If there is no DB already created then you will get window to create by default
  * If there is at least one DB already created then click on menu "databases"
  * You should have decided db name, configuration you need before you come here
  * Start entering the DB details 
    * DB Name
    * Replication
    * Persistence if required
    * DB password 
    * etc etc

**Sample Output**
```
TBD
```
## Removing Redis Cluster
**Clone this repo**
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd ~/Openshift/onprem/docs/redislab/
```
**Login to the OCP cluster**
```
oc login <CLUSTER-API-URL>
```
**Delete the route**
```
oc delete route rec-ui -n <PROJECT-NAME>
```
**Delete the RedisEnterpriseCluster resources**
```
oc delete -f ~/Openshift/onprem/docs/redislab/rec_rhel.yaml
```
**Delete the OpenShift operator bundle**
```
oc delete -f ~/Openshift/onprem/docs/redislab/openshift.bundle.yaml
```
**Delete the project**
```
oc delete project <PROJECT-NAME>
```
**Sample output**
```
TBD
```
# POC Findings for Redis Cluster:

## Installation Details (tasks performed by Infra team)
* Installed Redis (v6.0.8-28) on namespace (dct-nextgen-services), POC is done on OCP 4.5 NP3 environment
* Created a multi node Redis cluster (3-nodes)
* Created two test databases 
* Setup local test user for console access, Created a test user to provide access to application team to view the console.( LDAP was not tested as part of POC)
* Ran the infrastructure benchmark script provided by Redis support team to verify the database and cluster setup for response time.
* Modify database configuration:

	a. Set memory limits for database
	
	b. Setup password for DB access
	
	c. Enable HA (replication) for database
	
* Perform failover test for Redis Database.

	a. Installed a fast failover script provided by Redis support , which continuously perform ~10 ops/sec.
	
	b. Kill the Redis pod holding the master shard to simulate the cluster failover for the master node.
	
	c. verified it took 2.82 seconds for the cluster to failover.
	
	d. Verified the cluster status during and after failover using “rladmin” commands from pod terminal.



Need more application specific details from application team 
## Tasks Performed by application team:
We have provided admin access to application team on Redis Console, where they can manage the DB setting and other configuration on Redis Cluster.

1) Application team has deployed a test application that uses Redis and perform required tests on the Redis cluster.
	
2) Stress test was performed by application team after completing the application deployment to verify the supported limits.

# Redis Cluster Requirements:

## Things to consider for Redis Database setup:

* Number of databases
* Operation per second on each database – will help to decide the number of shared
* Memory per database
* Replications – this doubles the memory and shards

### Based on the above requirement, we can calculate

  * Total memory we need to assign to Redis Clsuter
  * Number of shards we need per database – This would directly impact the Redis license
  * Number of redis cluster pods/nodes we need
  * To get best performance, application must focus and get best schema design

 ## Minimum requirements for Redis Cluster.

* CPU: Minimum recommendation is 4000mi(4cpus)  - This would directly impact our OpenShift license
* Memory: Minimum recommendation is 4Gi - This is OK for as we can increase the memory as much we want and would not impact OpenShift license
* Number of redis cluster pods/nodes/replicas
	Minimum – 3 
* Incremental can happen but the total count must be an odd number
* Based on the database(s) requirements, we can decide the redis cluster config


## Things to be done by infra team:(Not is scope of POC timelines)
We have requested for the documentation on below topics from Redis support team.
1) We need to enable SSL for the Redis cluster and Database.
2) Enable LDAP to provide user access to Redis Console.



