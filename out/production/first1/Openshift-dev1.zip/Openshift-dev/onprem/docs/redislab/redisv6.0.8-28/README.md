The steps documented here are no more valid as the file names and steps got changed to setup the latest enterprise redis version 
