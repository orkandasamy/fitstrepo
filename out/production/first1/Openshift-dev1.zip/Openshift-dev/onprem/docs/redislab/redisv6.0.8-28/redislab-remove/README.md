# Remove Redis-cluster

## Getting started
Below steps will help you remove the redis cluster from an OpenShift Project

## Remove Redis Cluster
### Step-1: Clone this repo
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git;
```
### Step-2: In a file, keep your input to remove the redis cluster ready
```
~/OpenShift/onprem/docs/redislab/redislab-remove/remove-redis-cluster.sh
```
### Step-3: Sample output
```
********************************************************************************
Here is the values would be used to setup the Redis Enterprise Cluster
OCP_API_URL: https://api.ocp.frbprod.com:443
PROJECT_NAME: mware-infra

********************************************************************************
Logging out from previous session to avoid any issues
INFO: Successfully logged out from the cluster
********************************************************************************

Logging into the OCP Cluster [https://api.ocp.frbprod.com:443], please ensure that you use your adm account

Authentication required for https://api.ocp.frbprod.com:443 (openshift)
Username: adm_sayyadurai
Password: 
Login successful.

You have access to 88 projects, the list has been suppressed. You can list all projects with 'oc projects'

Using project "mware-infra".
********************************************************************************
Checking whenther project mware-infra is exists or not

Already on project "mware-infra" on server "https://api.ocp.frbprod.com:443".
Found the project[mware-infra], will proceed further
********************************************************************************
********************************************************************************
                       Starting Redis Cluster Removal
********************************************************************************
NAME                  HOST/PORT                            PATH   SERVICES              PORT   TERMINATION   WILDCARD
redis-enterprise-ui   redis-cluster.apps.ocp.frbprod.com          redis-enterprise-ui   ui     passthrough   None

Removing Redis Cluster UI route[redis-enterprise-ui] by running[/usr/bin/oc delete route redis-enterprise-ui -n mware-infra]
route.route.openshift.io "redis-enterprise-ui" deleted
********************************************************************************
NAME               AGE
redis-enterprise   6m7s

Deleting RedisEnterpriseCluster[redis-enterprise] by running[/usr/bin/oc delete RedisEnterpriseCluster redis-enterprise -n mware-infra]
redisenterprisecluster.app.redislabs.com "redis-enterprise" deleted
********************************************************************************
NAME                        READY   UP-TO-DATE   AVAILABLE   AGE
redis-enterprise-operator   1/1     1            1           6m9s

Deleting Redis deployment[redis-enterprise-operator] by running[/usr/bin/oc delete Deployment redis-enterprise-operator]
deployment.apps "redis-enterprise-operator" deleted
********************************************************************************
NAME                                         CREATED AT
redisenterprisedatabases.app.redislabs.com   2020-12-19T09:45:31Z

Deleting Redis Database CRD[redisenterprisedatabases.app.redislabs.com] by running[/usr/bin/oc delete crd redisenterprisedatabases.app.redislabs.com]
customresourcedefinition.apiextensions.k8s.io "redisenterprisedatabases.app.redislabs.com" deleted
********************************************************************************
NAME                                        CREATED AT
redisenterpriseclusters.app.redislabs.com   2020-12-19T09:45:30Z

Deleting Redis Cluster CRD[redisenterpriseclusters.app.redislabs.com] by running[/usr/bin/oc delete crd redisenterpriseclusters.app.redislabs.com]
customresourcedefinition.apiextensions.k8s.io "redisenterpriseclusters.app.redislabs.com" deleted
********************************************************************************
NAME                        ROLE                             AGE
redis-enterprise-operator   Role/redis-enterprise-operator   6m12s

Deleting Redis rolebinding[redis-enterprise-operator] by running[/usr/bin/oc delete rolebinding redis-enterprise-operator]
rolebinding.rbac.authorization.k8s.io "redis-enterprise-operator" deleted
********************************************************************************
NAME                        SECRETS   AGE
redis-enterprise-operator   2         6m12s

Deleting Redis Service Account[redis-enterprise-operator] by running [/usr/bin/oc delete sa redis-enterprise-operator]
serviceaccount "redis-enterprise-operator" deleted
********************************************************************************
NAME                        CREATED AT
redis-enterprise-operator   2020-12-19T09:45:29Z

Deleting Redis Role[redis-enterprise-operator] by running[/usr/bin/oc delete role redis-enterprise-operator]
role.rbac.authorization.k8s.io "redis-enterprise-operator" deleted
********************************************************************************
  Groups:                                       system:serviceaccounts:mware-infra

Removing Redis scc[redis-enterprise-scc] from group[system:serviceaccounts:mware-infra] by running[/usr/bin/oc adm policy remove-scc-from-group redis-enterprise-scc system:serviceaccounts:mware-infra]
securitycontextconstraints.security.openshift.io/redis-enterprise-scc removed from groups: ["system:serviceaccounts:mware-infra"]
********************************************************************************
NAME                   PRIV    CAPS             SELINUX    RUNASUSER   FSGROUP    SUPGROUP   PRIORITY     READONLYROOTFS   VOLUMES
redis-enterprise-scc   false   [SYS_RESOURCE]   RunAsAny   MustRunAs   RunAsAny   RunAsAny   <no value>   false            [awsElasticBlockStore azureDisk azureFile cephFS cinder configMap csi downwardAPI emptyDir fc flexVolume flocker gcePersistentDisk gitRepo glusterfs iscsi nfs persistentVolumeClaim photonPersistentDisk portworxVolume projected quobyte rbd scaleIO secret storageOS vsphere]

Deleting scc[redis-enterprise-scc] by running[/usr/bin/oc delete scc redis-enterprise-scc]
securitycontextconstraints.security.openshift.io "redis-enterprise-scc" deleted
********************************************************************************
Deleting Redis PODs

Deleting Redis POD[redis-enterprise-0] by running[/usr/bin/oc delete pod redis-enterprise-0 --force=true --grace-period=0]
warning: Immediate deletion does not wait for confirmation that the running resource has been terminated. The resource may continue to run on the cluster indefinitely.
pod "redis-enterprise-0" force deleted

Deleted Redis POD[redis-enterprise-0]

Deleting Redis POD[redis-enterprise-1] by running[/usr/bin/oc delete pod redis-enterprise-1 --force=true --grace-period=0]
warning: Immediate deletion does not wait for confirmation that the running resource has been terminated. The resource may continue to run on the cluster indefinitely.
pod "redis-enterprise-1" force deleted

Deleted Redis POD[redis-enterprise-1]

Deleting Redis POD[redis-enterprise-2] by running[/usr/bin/oc delete pod redis-enterprise-2 --force=true --grace-period=0]
warning: Immediate deletion does not wait for confirmation that the running resource has been terminated. The resource may continue to run on the cluster indefinitely.
pod "redis-enterprise-2" force deleted

Deleted Redis POD[redis-enterprise-2]
********************************************************************************
Deleting Redis PVCs
Deleting Redis PVC[redis-enterprise-storage-redis-enterprise-0] by running[/usr/bin/oc delete pvc redis-enterprise-storage-redis-enterprise-0]

persistentvolumeclaim "redis-enterprise-storage-redis-enterprise-0" deleted

Deleted Redis PVC[redis-enterprise-storage-redis-enterprise-0]
Deleting Redis PVC[redis-enterprise-storage-redis-enterprise-1] by running[/usr/bin/oc delete pvc redis-enterprise-storage-redis-enterprise-1]

persistentvolumeclaim "redis-enterprise-storage-redis-enterprise-1" deleted

Deleted Redis PVC[redis-enterprise-storage-redis-enterprise-1]
Deleting Redis PVC[redis-enterprise-storage-redis-enterprise-2] by running[/usr/bin/oc delete pvc redis-enterprise-storage-redis-enterprise-2]

persistentvolumeclaim "redis-enterprise-storage-redis-enterprise-2" deleted

Deleted Redis PVC[redis-enterprise-storage-redis-enterprise-2]
********************************************************************************
$
```
