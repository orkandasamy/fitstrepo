#!/bin/bash
## Script to remove the redis cluster
##
OCP_API_URL=""
PROJECT_NAME=""
REDIS_POD0="redis-enterprise-0"
REDIS_POD1="redis-enterprise-1"
REDIS_POD2="redis-enterprise-2"
REDIS_PVC0="redis-enterprise-storage-redis-enterprise-0"
REDIS_PVC1="redis-enterprise-storage-redis-enterprise-1"
REDIS_PVC2="redis-enterprise-storage-redis-enterprise-2"
REDIS_UI_ROUTE_NAME="redis-enterprise-ui"
OC_CMD=`which oc`
INPUT_TEMPLATE="input-template-to-remove-redis-cluster.txt"
####
## Function to display usage
usage()
{
  echo -e "Usage:\n\t$0 <InputFileWithValuesToSetupRedisCluster>"
  echo -e "Example:\n\t$0 /tmp/redis-cluster-removal-detail.txt"
  echo -e "\nThe file must contain the following variable and values\n"

  echo -e "***************************************************************************"
  echo -e "OCP_API_URL=\"<OCP_CLUSTER_API_URL>\""
  echo -e "PROJECT_NAME=\"<PROJECT_NAME_WHERE_YOUR_WANT_TO_CREATE_THE_REDIS_CLUSTER>\""
  echo -e "***************************************************************************\n"

  exit
} ## End of function

## Function to check Argument
checkarg()
{
  if [ ${ARGCOUNT} -ne 1 ]
  then
    usage
  fi
} ## End of function

## Function to delete POD
function delete_pod()
{
  REDIS_POD="${1}"
  echo -e "Deleting Redis POD[${REDIS_POD}] by running[${OC_CMD} delete pod ${REDIS_POD} --force=true --grace-period=0]"
  ${OC_CMD} delete pod ${REDIS_POD} --force=true --grace-period=0 
  CMD_EXIT_CODE=$?
  if [[ ${CMD_EXIT_CODE} -eq 0 ]]
  then
    echo -e "\nDeleted Redis POD[${REDIS_POD}]\n"
  else
    echo -e "ERROR: Could not delete Redis POD[${REDIS_POD}], please check manually\n"
  fi
} ## End of function 

## Function to delete PVC
function delete_pvc()
{
  REDIS_PVC="${1}"
  echo -e "Deleting Redis PVC[${REDIS_PVC}] by running[${OC_CMD} delete pvc ${REDIS_PVC}]\n"
  ${OC_CMD} delete pvc ${REDIS_PVC}
  CMD_EXIT_CODE=$?
  if [[ ${CMD_EXIT_CODE} -eq 0 ]]
  then
    echo -e "\nDeleted Redis PVC[${REDIS_PVC}]"
  else
    echo -e "ERROR: Could not delete Redis PVC[${REDIS_PVC}], please check manually\n"
  fi
} ## End of function 

## Check the argument
ARGCOUNT=$#
checkarg

## Check the input file and parse the input data
INPUT_FILE="${1}"
if [ ! -s ${INPUT_FILE} ]
then
  ## File is empty, can't proceed
  echo -e "The input file is empty or not exists, can't proceed further(exiting now)"
  exit 1
else
  ## Input file is exists, parse the input
  OCP_API_URL=`cat ${INPUT_FILE} | grep -i ^OCP_API_URL | awk -F'=' '{print $2}'`
  OCP_API_URL=`echo ${OCP_API_URL} | xargs`
  OCP_API_URL=`echo ${OCP_API_URL//[[:blank:]]/}`
  # echo -e "OCP_API_URL: ${OCP_API_URL}"
  PROJECT_NAME=`cat ${INPUT_FILE} | grep -i ^PROJECT_NAME | awk -F'=' '{print $2}'`
  PROJECT_NAME=`echo ${PROJECT_NAME} | xargs`
  PROJECT_NAME=`echo ${PROJECT_NAME//[[:blank:]]/}`
fi

## Validate the given input and make changes if required
## Validate the OCP_API_URL
if [ "${OCP_API_URL}" == "" ]
then
  echo -e "API URL[${OCP_API_URL}] is blank, can't proceed further. Exiting now."
  exit 1
else
  # echo -e "API URL[${OCP_API_URL}] is NOT blank"
  OCP_CLUSTER_NAME=`echo ${OCP_API_URL} | awk -F'.' '{print $2}'`
  OCP_DOMAIN=`echo ${OCP_API_URL} | rev | cut -d'.' -f -2 | rev`
fi

## Validate PROJECT_NAME
if [ "${PROJECT_NAME}" == "" ]
then
  echo -e "Project Name[${PROJECT_NAME}] is blank. Exiting now."
  exit 1
# else
#   echo -e "Project Name[${PROJECT_NAME}] is NOT blank"
fi

## Print all the values
echo -e "\n\n********************************************************************************\n"
echo -e "Here is the values would be used to setup the Redis Enterprise Cluster"
echo -e "OCP_API_URL: ${OCP_API_URL}"
echo -e "PROJECT_NAME: ${PROJECT_NAME}"
echo -e "\n********************************************************************************\n"

## Logout from any OCP cluster currently logged in
echo -e "\nLogging out from previous session to avoid any issues\n"
${OC_CMD} logout > /dev/null 2>&1
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "INFO: You have not logged in to the cluster to logout"
else
  echo -e "INFO: Successfully logged out from the cluster"
fi
echo -e "\n********************************************************************************\n"

## Login to OCP_API_URL with your adm user account credentials(interactive mode)
echo -e "Logging into the OCP Cluster [${OCP_API_URL}], please ensure that you use your adm account\n"
${OC_CMD} login ${OCP_API_URL}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "Failed to login to the cluster[${OCP_API_URL}]"
  exit 1
fi
echo -e "\n********************************************************************************\n"

## Check if the PROJECT_NAME is already exists or not. If not, exit
echo -e "\nChecking whenther project ${PROJECT_NAME} is exists or not\n"
${OC_CMD} project ${PROJECT_NAME}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "ERROR: Could not find the project[${PROJECT_NAME}], exiting now."
  exit 1
else
  echo -e "Found the project[${PROJECT_NAME}], will proceed further"
fi
echo -e "\n********************************************************************************\n"

## When you are here that means we have logged into the cluster and found the project as well
echo -e "\n********************************************************************************\n"
echo -e "\n                       Starting Redis Cluster Removal\n"
echo -e "\n********************************************************************************\n"

## Remove the REDIS_UI_ROUTE_NAME
${OC_CMD} get route ${REDIS_UI_ROUTE_NAME} -n ${PROJECT_NAME}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nRemoving Redis Cluster UI route[${REDIS_UI_ROUTE_NAME}] by running[${OC_CMD} delete route ${REDIS_UI_ROUTE_NAME} -n ${PROJECT_NAME}]"
  ${OC_CMD} delete route ${REDIS_UI_ROUTE_NAME} -n ${PROJECT_NAME}
else
  echo -e "INFO: Route[${REDIS_UI_ROUTE_NAME}] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove RedisEnterpriseCluster
${OC_CMD} get RedisEnterpriseCluster redis-enterprise -n ${PROJECT_NAME}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting RedisEnterpriseCluster[redis-enterprise] by running[${OC_CMD} delete RedisEnterpriseCluster redis-enterprise -n ${PROJECT_NAME}]"
  ${OC_CMD} delete RedisEnterpriseCluster redis-enterprise -n ${PROJECT_NAME}
else
  echo -e "INFO: RedisEnterpriseCluster[redis-enterprise] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove Redis Deployment
${OC_CMD} get Deployment redis-enterprise-operator
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting Redis deployment[redis-enterprise-operator] by running[${OC_CMD} delete Deployment redis-enterprise-operator]"
  ${OC_CMD} delete Deployment redis-enterprise-operator 
else
  echo -e "INFO: Redis deployment[redis-enterprise-operator] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove Redis Database CRD
${OC_CMD} get crd redisenterprisedatabases.app.redislabs.com
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting Redis Database CRD[redisenterprisedatabases.app.redislabs.com] by running[${OC_CMD} delete crd redisenterprisedatabases.app.redislabs.com]"
  ${OC_CMD} delete crd redisenterprisedatabases.app.redislabs.com
else
  echo -e "INFO: Redis Database CRD[redisenterprisedatabases.app.redislabs.com] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove Redis Cluster CRD
${OC_CMD} get crd redisenterpriseclusters.app.redislabs.com
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting Redis Cluster CRD[redisenterpriseclusters.app.redislabs.com] by running[${OC_CMD} delete crd redisenterpriseclusters.app.redislabs.com]"
  ${OC_CMD} delete crd redisenterpriseclusters.app.redislabs.com
else
  echo -e "INFO: Redis Cluster CRD[redisenterpriseclusters.app.redislabs.com] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove role binding redis-enterprise-operator
${OC_CMD} get rolebinding redis-enterprise-operator
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting Redis rolebinding[redis-enterprise-operator] by running[${OC_CMD} delete rolebinding redis-enterprise-operator]"
  ${OC_CMD} delete rolebinding redis-enterprise-operator
else
  echo -e "INFO: Redis rolebinding[redis-enterprise-operator] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove Redis Service Account
${OC_CMD} get sa redis-enterprise-operator
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting Redis Service Account[redis-enterprise-operator] by running [${OC_CMD} delete sa redis-enterprise-operator]"
  ${OC_CMD} delete sa redis-enterprise-operator
else
  echo -e "INFO: Redis Service Account[redis-enterprise-operator] not found"
fi
echo -e "\n********************************************************************************\n"

## Remvoe Redis Role redis-enterprise-operator
${OC_CMD} get role redis-enterprise-operator
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting Redis Role[redis-enterprise-operator] by running[${OC_CMD} delete role redis-enterprise-operator]"
  ${OC_CMD} delete role redis-enterprise-operator
else
  echo -e "INFO: Redis Role[redis-enterprise-operator] not found"
fi
echo -e "\n********************************************************************************\n"

## Remove Redis scc redis-enterprise-scc from group system:serviceaccounts:${PROJECT_NAME}
${OC_CMD} describe scc redis-enterprise-scc | grep system:serviceaccounts:${PROJECT_NAME}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nRemoving Redis scc[redis-enterprise-scc] from group[system:serviceaccounts:${PROJECT_NAME}] by running[${OC_CMD} adm policy remove-scc-from-group redis-enterprise-scc system:serviceaccounts:${PROJECT_NAME}]"
  ${OC_CMD} adm policy remove-scc-from-group redis-enterprise-scc system:serviceaccounts:${PROJECT_NAME}
else
  echo -e "INFO: Redis scc[redis-enterprise-scc] not found in the group[system:serviceaccounts:${PROJECT_NAME}]"
fi
echo -e "\n********************************************************************************\n"

## Remove Redis scc redis-enterprise-scc
${OC_CMD} get scc redis-enterprise-scc
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -eq 0 ]]
then
  echo -e "\nDeleting scc[redis-enterprise-scc] by running[${OC_CMD} delete scc redis-enterprise-scc]"
  ${OC_CMD} delete scc redis-enterprise-scc
else
  echo -e "INFO: Redis scc[redis-enterprise-scc] not found"
fi
echo -e "\n********************************************************************************\n"

## Deleting Redis PODs
echo -e "Deleting Redis PODs"
delete_pod "${REDIS_POD0}"
delete_pod "${REDIS_POD1}"
delete_pod "${REDIS_POD2}"
echo -e "\n********************************************************************************\n"

## Deleting Redis PVCs
echo -e "Deleting Redis PVCs"
delete_pvc "${REDIS_PVC0}"
delete_pvc "${REDIS_PVC1}"
delete_pvc "${REDIS_PVC2}"
echo -e "\n********************************************************************************\n"

