# Setup redislab cluster

## Getting started

Ref: https://docs.redislabs.com/latest/platforms/openshift/getting-started-cli/

These steps will be used to setup the redis cluster in an OpenShift Cluster. 

You can build the redis cluster manually or using the script

## Prerequisites
* Cluster admin access in the OpenShift Cluster
* Internet access to download the redislab files from https://github.com/RedisLabs/redis-enterprise-k8s-docs

## Setting up the redis cluster using script
### Step-1: Clone this repo
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd ~/Openshift/onprem/docs/redislab/redislab-setup/
```
### Step-2: In a file, keep your input to build the redis cluster ready
### Step-3: Run the script and follow the instruction
```
~/Openshift/onprem/docs/redislab/redislab-setup/setup-redis-cluster.sh
```
## Setting up the redis cluster manually

### Step-1: Download the redislabs file from their git repo. Ensure that you have access to download from internet
```
cd ; rm -rf ~/redis-enterprise-k8s-docs; git clone https://github.com/RedisLabs/redis-enterprise-k8s-docs.git; cd ~/redis-enterprise-k8s-docs
```
### Step-2: Login to OpenShift Cluster
```
oc login <CLUSTER-API-URL>
```
### Step-3: Create the namespace(if you dont have one) where you want to create the redis cluster and follow FRB specific process to grant access to respective AD Groups
```
oc new-project <PROJECT-NAME>
```
### Step-4: Create SecurityContextConstraints
```
oc apply -f openshift/scc.yaml
```
### Step-5: Provide the operator permissions for pods (substitute your project for "my-project")
```
oc adm policy add-scc-to-group redis-enterprise-scc system:serviceaccounts:<PROJECT-NAME>
```
### Step-6: Create required roles
```
oc apply -f openshift/role.yaml -n <PROJECT-NAME>
```
### Step-7: Create required service accounts
```
oc apply -f openshift/service_account.yaml -n <PROJECT-NAME>
```
### Step-8: Create required role bindings
```
oc apply -f openshift/role_binding.yaml -n <PROJECT-NAME>
```
### Step-9: Create the Cluster CRD
```
oc apply -f crds/app_v1_redisenterprisecluster_crd.yaml -n <PROJECT-NAME>
```
### Step-10: Create Database CRD
```
oc apply -f crds/app_v1alpha1_redisenterprisedatabase_crd.yaml -n <PROJECT-NAME>
```
### Step-11: Deploy the operator
```
oc apply -f openshift/operator_rhel.yaml -n <PROJECT-NAME>
```
### Step-12: Validate and ensure that operator is up
```
oc get all -n <PROJECT-NAME>
```
### Step-13: Edit Redis Enterprise Cluster file and update with correct values
* Ensure that you have updated the storage information by editing the file before you deploy the cluster
  * **Number of Replicas:** ie nodes in the spec section
  * **Storage size:** ie volumeSize in the spec section
  * **storageClassName** as "thin01" in the spec section
  * **uiServiceType** as ClusterIP in the spec section
  * **username** as "admin@<domain_name>" in the spec section
  * **CPU and Memory limits & requests** as required. Below is default value in the sample file you downloaded
      limits:
      cpu: "4000m"
      memory: 4Gi
    requests:
      cpu: "4000m"
      memory: 4Gi
```
vi openshift/redis-enterprise-cluster_rhel.yaml >>>>> Update the details as mentioned above
```
### Step-14: Deploy Redis Enterprise Cluster
```
oc apply -f openshift/redis-enterprise-cluster_rhel.yaml -n <PROJECT-NAME>
```
### Step-15: Validate and ensure that everything is up
```
oc get all -n <PROJECT-NAME>
```
### Step-16: Validate and ensure that PVCs got created. It may take a while, please wait for 5 mins
```
oc get pvc -n <PROJECT-NAME>
```
### Step-17: Check the events for any errors
```
oc get events --sort-by='.metadata.creationTimestamp'-n <PROJECT-NAME>
```
### Step-18: Create the route to access the redis cluster
```
oc create route passthrough --service=redis-enterprise-ui --hostname=<ROUTE-HOSTNAME-FOR-REDIS-CLUSTER-UI> -n <PROJECT-NAME>
```
### Step-19: Ensure that route got created 
```
oc get routes -n <PROJECT-NAME>
```
### Step-20: Ensure that your route hostname is resolving the respective OpenShift Cluster LB CNAME
```
nslookup <ROUTE-HOSTNAME-FOR-REDIS-CLUSTER-UI>
```
### Step-21: Retrieve the admin user password stored in the secret
```
oc get secret redis-enterprise --template={{.data.password}} -n <PROJECT-NAME> | base64 -d
```
### Step-22: Sample Output
**Download the redislabs file from their git repo**
```
$ cd ; rm -rf ~/redis-enterprise-k8s-docs; git clone https://github.com/RedisLabs/redis-enterprise-k8s-docs.git; cd ~/redis-enterprise-k8s-docs
Cloning into 'redis-enterprise-k8s-docs'...
remote: Enumerating objects: 172, done.
remote: Counting objects: 100% (172/172), done.
remote: Compressing objects: 100% (131/131), done.
remote: Total 710 (delta 98), reused 77 (delta 40), pack-reused 538
Receiving objects: 100% (710/710), 206.68 KiB | 0 bytes/s, done.
Resolving deltas: 100% (430/430), done.
$
```
**Login to OpenShift Cluster**
```
$ oc login https://api.ocp.corp.frbnp2.com                                            
Authentication required for https://api.ocp.corp.frbnp2.com:443 (openshift)
Username: adm_sayyadurai
Password: 
Login successful.

You have access to 88 projects, the list has been suppressed. You can list all projects with 'oc projects'

Using project "default".
$
```
**Create the namespace(if you dont have one) where you want to create the redis cluster**
```
$ oc new-project redis-poc
Now using project "redis-poc" on server "https://api.ocp.corp.frbnp2.com:443".

You can add applications to this project with the 'new-app' command. For example, try:

    oc new-app ruby~https://github.com/sclorg/ruby-ex.git

to build a new example application in Python. Or use kubectl to deploy a simple Kubernetes application:

    kubectl create deployment hello-node --image=gcr.io/hello-minikube-zero-install/hello-node
$ 
```
**Create SecurityContextConstraints**
```
$ oc apply -f openshift/scc.yaml
securitycontextconstraints.security.openshift.io/redis-enterprise-scc created
$
```
**Provide the operator permissions for pods (substitute your project for "my-project")**
```
$ oc adm policy add-scc-to-group redis-enterprise-scc system:serviceaccounts:redis-poc
securitycontextconstraints.security.openshift.io/redis-enterprise-scc added to groups: ["system:serviceaccounts:redis-poc"]
$
```
**Create required roles**
```
$ oc apply -f openshift/role.yaml -n redis-poc
role.rbac.authorization.k8s.io/redis-enterprise-operator created
$
```
**Create required service accounts**
```
$ oc apply -f openshift/service_account.yaml -n redis-poc
serviceaccount/redis-enterprise-operator created
$
```
**Create required role bindings**
```
$ oc apply -f openshift/role_binding.yaml -n redis-poc
rolebinding.rbac.authorization.k8s.io/redis-enterprise-operator created
$
```
**Create the Cluster CRD**
```
$ oc apply -f crds/app_v1_redisenterprisecluster_crd.yaml -n redis-poc
customresourcedefinition.apiextensions.k8s.io/redisenterpriseclusters.app.redislabs.com created
$
```
**Create Database CRD**
```
$ oc apply -f crds/app_v1alpha1_redisenterprisedatabase_crd.yaml -n redis-poc
customresourcedefinition.apiextensions.k8s.io/redisenterprisedatabases.app.redislabs.com created
$
```
**Deploy the operator**
```
$ oc apply -f openshift/operator_rhel.yaml -n redis-poc
deployment.apps/redis-enterprise-operator created
$
```
**Validate and ensure that operator is up**
```
$ oc get all
NAME                                             READY   STATUS    RESTARTS   AGE
pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j   1/1     Running   0          11s

NAME                                        READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/redis-enterprise-operator   1/1     1            1           11s

NAME                                                   DESIRED   CURRENT   READY   AGE
replicaset.apps/redis-enterprise-operator-5d4dcf5dfc   1         1         1       11s
[adm_sayyadurai@npgsansiblecl2v redis-enterprise-k8s-docs-master]$ oc get all
NAME                                             READY   STATUS    RESTARTS   AGE
pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j   1/1     Running   0          15s

NAME                                        READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/redis-enterprise-operator   1/1     1            1           15s

NAME                                                   DESIRED   CURRENT   READY   AGE
replicaset.apps/redis-enterprise-operator-5d4dcf5dfc   1         1         1       15s
$
```
**Edit Redis Enterprise Cluster file and update with correct values**
```
vi openshift/redis-enterprise-cluster_rhel.yaml
     <<<<<Make the changes>>>>>>
$
```
**Deploy Redis Enterprise Cluster**
```
$ oc apply -f openshift/redis-enterprise-cluster_rhel.yaml -n redis-poc
redisenterprisecluster.app.redislabs.com/redis-enterprise created
$
```
**Validate and ensure that everything is up**
```
$ oc get all -n redis-poc
NAME                                                    READY   STATUS    RESTARTS   AGE
pod/redis-enterprise-0                                  2/2     Running   0          4m44s
pod/redis-enterprise-1                                  2/2     Running   0          3m11s
pod/redis-enterprise-2                                  1/2     Running   0          89s
pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j          1/1     Running   0          9m15s
pod/redis-enterprise-services-rigger-69bf6b964f-47ctc   1/1     Running   0          4m44s

NAME                          TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)                      AGE
service/redis-enterprise      ClusterIP   None             <none>        9443/TCP,8001/TCP,8070/TCP   4m44s
service/redis-enterprise-ui   ClusterIP   172.30.245.253   <none>        8443/TCP                     4m44s

NAME                                               READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/redis-enterprise-operator          1/1     1            1           9m15s
deployment.apps/redis-enterprise-services-rigger   1/1     1            1           4m44s

NAME                                                          DESIRED   CURRENT   READY   AGE
replicaset.apps/redis-enterprise-operator-5d4dcf5dfc          1         1         1       9m15s
replicaset.apps/redis-enterprise-services-rigger-69bf6b964f   1         1         1       4m44s

NAME                                READY   AGE
statefulset.apps/redis-enterprise   2/3     4m44s
$
```
**Validate and ensure that PVCs got created. It may take a while, please wait for 5 mins**
```
$ oc get pvc -n redis-poc
NAME                                          STATUS   VOLUME                                     CAPACITY   ACCESS MODES   STORAGECLASS   AGE
redis-enterprise-storage-redis-enterprise-0   Bound    pvc-7b39863c-3f40-4db6-9869-8e82a119dbbc   20Gi       RWO            thin01         4m37s
redis-enterprise-storage-redis-enterprise-1   Bound    pvc-00e684d4-cb03-40c3-a984-e97d99ce07c0   20Gi       RWO            thin01         3m4s
redis-enterprise-storage-redis-enterprise-2   Bound    pvc-bc60a5c0-e010-4ddc-b5be-735cf7058e6a   20Gi       RWO            thin01         82s
$
```
**Check the events for any errors**
```
$ oc get events --sort-by='.metadata.creationTimestamp'  -n redis-poc
LAST SEEN   TYPE      REASON                   OBJECT                                                              MESSAGE
<unknown>   Normal    Scheduled                pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j                      Successfully assigned redis-poc/redis-enterprise-operator-5d4dcf5dfc-fdk5j to np2ocpwkr1v.ocp.corp.frbnp2.com
52m         Normal    SuccessfulCreate         replicaset/redis-enterprise-operator-5d4dcf5dfc                     Created pod: redis-enterprise-operator-5d4dcf5dfc-fdk5j
52m         Normal    ScalingReplicaSet        deployment/redis-enterprise-operator                                Scaled up replica set redis-enterprise-operator-5d4dcf5dfc to 1
52m         Normal    AddedInterface           pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j                      Add eth0 [10.131.1.39/23]
52m         Normal    Pulling                  pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j                      Pulling image "redislabs/operator:6.0.8-1"
52m         Normal    Pulled                   pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j                      Successfully pulled image "redislabs/operator:6.0.8-1"
52m         Normal    Created                  pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j                      Created container redis-enterprise-operator
52m         Normal    Started                  pod/redis-enterprise-operator-5d4dcf5dfc-fdk5j                      Started container redis-enterprise-operator
47m         Normal    SuccessfulCreate         replicaset/redis-enterprise-services-rigger-69bf6b964f              Created pod: redis-enterprise-services-rigger-69bf6b964f-47ctc
<unknown>   Warning   FailedScheduling         pod/redis-enterprise-0                                              running "VolumeBinding" filter plugin for pod "redis-enterprise-0": pod has unbound immediate PersistentVolumeClaims
<unknown>   Warning   FailedScheduling         pod/redis-enterprise-0                                              running "VolumeBinding" filter plugin for pod "redis-enterprise-0": pod has unbound immediate PersistentVolumeClaims
<unknown>   Normal    Scheduled                pod/redis-enterprise-services-rigger-69bf6b964f-47ctc               Successfully assigned redis-poc/redis-enterprise-services-rigger-69bf6b964f-47ctc to np2ocpwkr2v.ocp.corp.frbnp2.com
47m         Normal    SuccessfulCreate         statefulset/redis-enterprise                                        create Pod redis-enterprise-0 in StatefulSet redis-enterprise successful
47m         Normal    SuccessfulCreate         statefulset/redis-enterprise                                        create Claim redis-enterprise-storage-redis-enterprise-0 Pod redis-enterprise-0 in StatefulSet redis-enterprise success
.
.
.
<<<<<<OUTPUT-TRUNCATED>>>>>
.
.
.
43m         Normal    AddedInterface           pod/redis-enterprise-2                                              Add eth0 [10.129.3.76/23]
43m         Normal    Pulled                   pod/redis-enterprise-2                                              Container image "redislabs/redis:6.0.8-28.rhel7-openshift" already present on machine
43m         Normal    Started                  pod/redis-enterprise-2                                              Started container redis-enterprise-node
43m         Normal    Pulled                   pod/redis-enterprise-2                                              Container image "redislabs/operator:6.0.8-1" already present on machine
43m         Normal    Created                  pod/redis-enterprise-2                                              Created container bootstrapper
43m         Normal    Started                  pod/redis-enterprise-2                                              Started container bootstrapper
43m         Normal    Created                  pod/redis-enterprise-2                                              Created container redis-enterprise-node
$
```
**Create the route to access the redis cluster**
```
$ oc create route passthrough --service=redis-enterprise-ui --hostname=redis-poc.apps.ocp.corp.frbnp2.com -n redis-poc  
route.route.openshift.io/redis-enterprise-ui created
$
```
**Ensure that route got created**
```
$ oc get routes -n redis-poc
NAME                  HOST/PORT                            PATH   SERVICES              PORT   TERMINATION   WILDCARD
redis-enterprise-ui   redis-poc.apps.ocp.corp.frbnp2.com          redis-enterprise-ui   ui     passthrough   None
$
```
**Ensure that your route hostname is resolving the respective OpenShift Cluster LB CNAME**
```
$ nslookup redis-poc.apps.ocp.corp.frbnp2.com
Server:         127.0.0.1
Address:        127.0.0.1#53

redis-poc.apps.ocp.corp.frbnp2.com      canonical name = apps.ocp.corp.frbnp2.com.
apps.ocp.corp.frbnp2.com        canonical name = np2apps.ocp.corp.frbnp2.com.
Name:   np2apps.ocp.corp.frbnp2.com
Address: 10.7.135.30
$
```
**Retrieve the admin user password stored in the secret**
```
$ oc get secret redis-enterprise --template={{.data.password}} -n redis-poc | base64 -d              
WUsZcJ23
$
```

