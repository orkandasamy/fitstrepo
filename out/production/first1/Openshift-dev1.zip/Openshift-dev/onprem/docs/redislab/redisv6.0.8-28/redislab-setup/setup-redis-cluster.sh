#!/bin/bash
## Script to setup the redis cluster
##
## Input we need to setup the redis cluster
DEFAULT_OCP_API_URL=""
DEFAULT_PROJECT_NAME="mware-infra"
DEFAULT_REDIS_REPLICA_COUNT="3"
DEFAULT_REDIS_PV_SIZE="20Gi"
DEFAULT_STORAGE_CLASS_NAME="thin01"
DEFAULT_REDIS_UISERVICE_TYPE="ClusterIP"
DEFAULT_REDIS_ADMIN_USER="admin@frb.com"
DEFAULT_REDIS_CPU_LIMIT="4000m"
DEFAULT_REDIS_CPU_REQUESTS="4000m"
DEFAULT_REDIS_MEMORY_LIMIT="4Gi"
DEFAULT_REDIS_MEMORY_REQUESTS="4Gi"
DEFAULT_REDIS_CLUSTER_UI_ROUTE_HOSTNAME=""

## Variables that we used 
DATE=`date "+%Y-%m-%d-%H-%M-%S"`
REDIS_SETUP_DIR="/tmp/redis-lab-poc"
REDIS_GIT_DIR="${REDIS_SETUP_DIR}/redis-enterprise-k8s-docs-master"
REDISLAB_GIT_REPO="https://github.com/RedisLabs/redis-enterprise-k8s-docs-master.git"
INPUT_TEMPLATE="input-to-setup-redis-cluster.txt"
OC_CMD=`which oc`
REDIS_PVC0="redis-enterprise-storage-redis-enterprise-0"
REDIS_PVC1="redis-enterprise-storage-redis-enterprise-1"
REDIS_PVC2="redis-enterprise-storage-redis-enterprise-2"
REDIS_UI_ROUTE_NAME="redis-enterprise-ui"

#####
## 1. Login to the OpenShift Cluster using OCP_API_URL
## 2. Verify and ensure that PROJECT_NAME is already created
## 3. Clone the RedisLabs repo
## 4. Update the following in the file openshift/redis-enterprise-cluster_rhel.yaml
##    4.1 Number of Replicas: Default is 3
##    4.2 PV size: Default is 20Gi
##    4.3 storageClassName: Default is thin01
##    4.4 uiServiceType: Will be set to "ClusterIP"
##    4.5 Admin username: Default is "admin@frb.com"
##    4.6 CPU limit: Default is 4000m
##    4.7 CPU requests: Default is 4000m
##    4.8 Memory limit: Default is 4Gi
##    4.9 Memory requests: Default is 4Gi
## 5. Apply RedisLabs YAML files
## 6. Create the route REDIS_CLUSTER_UI_ROUTE_HOSTNAME
## 7. Verify DNS name for REDIS_CLUSTER_UI_ROUTE_HOSTNAME
## 8. Retrieve the Admin user password
#####

## Function to display usage
usage()
{
  echo -e "Usage:\n\t$0 <InputFileWithValuesToSetupRedisCluster>"
  echo -e "Example:\n\t$0 /tmp/redis-cluster-setup-detail.txt"
  echo -e "\nThe file must contain the following variable and values\n"

  echo -e "***************************************************************************"
  echo -e "OCP_API_URL=\"<OCP_CLUSTER_API_URL>\""
  echo -e "PROJECT_NAME=\"<PROJECT_NAME_WHERE_YOUR_WANT_TO_CREATE_THE_REDIS_CLUSTER>\""
  echo -e "REDIS_REPLICA_COUNT=\"<NUMERIC_VALUE_LESS_THAN_3>\""
  echo -e "REDIS_PV_SIZE=\"<NUMERIC_VALUE>20Gi\""
  echo -e "STORAGE_CLASS_NAME=\"thin01\""
  echo -e "REDIS_UISERVICE_TYPE=\"ClusterIP\""
  echo -e "REDIS_ADMIN_USER=\"admin@<DOMAIN_NAME>\""
  echo -e "REDIS_CPU_LIMIT=\"<NUMERIC_VALUE>m\""
  echo -e "REDIS_CPU_REQUESTS=\"<NUMERIC_VALUE>m\""
  echo -e "REDIS_MEMORY_LIMIT=\"<NUMERIC_VALUE>Gi\""
  echo -e "REDIS_MEMORY_REQUESTS=\"<NUMERIC_VALUE>Gi\""
  echo -e "REDIS_CLUSTER_UI_ROUTE_HOSTNAME=\"<FQDN_FOR_ROUTE_HOST_NAME>\""
  echo -e "***************************************************************************"
  exit
} ## End of function

## Function to check Argument
checkarg()
{
  if [ ${ARGCOUNT} -ne 1 ]
  then
    usage
  fi
} ## End of function

## Function to create the yaml file with custom value
function generate_redis_enterprise_cluster_rhel_yaml()
{
  TMP_REDIS_ENTRPRS_CLUSTER_RHEL="/tmp/redis-enterprise-cluster_rhel.yaml"
  echo "apiVersion: \"app.redislabs.com/v1\"" > ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "kind: \"RedisEnterpriseCluster\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "metadata:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  name: \"redis-enterprise\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "spec:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  nodes: ${REDIS_REPLICA_COUNT}" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  persistentSpec:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    enabled: true" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    volumeSize: \"${REDIS_PV_SIZE}\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    storageClassName: \"${STORAGE_CLASS_NAME}\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  uiServiceType: ${REDIS_UISERVICE_TYPE}" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  username: \"${REDIS_ADMIN_USER}\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  redisEnterpriseNodeResources:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    limits:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "      cpu: \"${REDIS_CPU_LIMIT}\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "      memory: ${REDIS_MEMORY_LIMIT}" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    requests:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "      cpu: \"${REDIS_CPU_REQUESTS}\"" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "      memory: ${REDIS_MEMORY_REQUESTS}" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "  redisEnterpriseImageSpec:" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    imagePullPolicy:  IfNotPresent" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    repository:       redislabs/redis" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
  echo "    versionTag:       6.0.8-28.rhel7-openshift" >> ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL}
}  ## End of function

## Function to apply the YAML files
function apply_yaml()
{
  YAML_FILE_NAME="${1}"
  PRJ_NAME="${2}"
  if [ ! -f "${YAML_FILE_NAME}" ]
  then
    echo -e "Could not find the yaml file[${YAML_FILE_NAME}], please check and invoke the script again, exiting now"
    exit 1
  else
    echo -e "In function[apply_yaml]: Now running[${OC_CMD} apply -f ${YAML_FILE_NAME} -n ${PRJ_NAME}]"
    ${OC_CMD} apply -f "${YAML_FILE_NAME}" -n "${PRJ_NAME}"
    CMD_EXIT_CODE=$?
    if [[ ${CMD_EXIT_CODE} -ne 0 ]]
    then
      echo -e "ERROR: Failed to apply the yaml file[${YAML_FILE_NAME}] in the project[${PRJ_NAME}]"
      exit 1
    else
      echo -e "INFO: Succesfully applied the yaml file[${YAML_FILE_NAME}] in the project[${PRJ_NAME}]"
    fi
  fi
  echo -e "********************************************************************************"
}  ## End of function 

## Function to check pvc
function check_pvc_status()
{
  PVC_NAME="${1}"
  PRJ_NAME="${2}"
  IS_PV_EXISTS=false
  echo -e "Checking whether PVC[${PVC_NAME}] got created/ready or not"
  while [ ${IS_PV_EXISTS} = false ]
  do
  {
    ${OC_CMD} get pvc "${PVC_NAME}" -n "${PRJ_NAME}" > /dev/null 2>&1
    CMD_EXIT_CODE=$?
    if [[ ${CMD_EXIT_CODE} -ne 0 ]]
    then
      ## PVC not exists, continue to wait
      echo -e "PVC[${PVC_NAME}] is NOT ready yet in Project[${PRJ_NAME}], please continue to wait ..."
      sleep 10s
      continue
    else
      ## PVC ready
      echo -e "INFO: PVC[${PVC_NAME}] is ready in Project[${PRJ_NAME}]\n"
      break
    fi
  }
  done
} ## End of function 

## Function to display Redis UI URL, admin username and password
function final_summary()
{
  echo -e "\n\n********************************************************************************"
  echo -e "                                     Summary"
  echo -e "Redis Cluster URL: https://${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}/"
  echo -e "Admin User Name: ${REDIS_ADMIN_USER}"
  echo -e "Admin Password: ${REDIS_ADMIN_PASSWORD}"
  if [ ${DNS_EXISTS} = false ]
  then
    echo -e "Note: DNS entry is not ready for your route hostname, you can't access the URL"
  fi
  if [ -f "${CONSOLIDATED_ERRORS}" ]
  then
    echo -e "Please check the file[${CONSOLIDATED_ERRORS}] for any warnings/errors occured during the setup and take action accordingly"
  fi
  echo -e "\n********************************************************************************\n"
}  ## End of function

## Check the argument
ARGCOUNT=$#
checkarg

## Check the input file and parse the input data
INPUT_FILE="${1}"
if [ ! -s ${INPUT_FILE} ]
then
  ## File is empty, can't proceed
  echo -e "The input file is empty or not exists, can't proceed further(exiting now)"
  exit 1
else
  ## Input file is exists, parse the input
  OCP_API_URL=`cat ${INPUT_FILE} | grep -i ^OCP_API_URL | awk -F'=' '{print $2}'`
  OCP_API_URL=`echo ${OCP_API_URL} | xargs`
  OCP_API_URL=`echo ${OCP_API_URL//[[:blank:]]/}`
  # echo -e "OCP_API_URL: ${OCP_API_URL}"
  PROJECT_NAME=`cat ${INPUT_FILE} | grep -i ^PROJECT_NAME | awk -F'=' '{print $2}'`
  PROJECT_NAME=`echo ${PROJECT_NAME} | xargs`
  PROJECT_NAME=`echo ${PROJECT_NAME//[[:blank:]]/}`
  # echo -e "PROJECT_NAME: ${PROJECT_NAME}"
  REDIS_REPLICA_COUNT=`cat ${INPUT_FILE} | grep -i ^REDIS_REPLICA_COUNT | awk -F'=' '{print $2}'`
  REDIS_REPLICA_COUNT=`echo ${REDIS_REPLICA_COUNT} | xargs`
  REDIS_REPLICA_COUNT=`echo ${REDIS_REPLICA_COUNT//[[:blank:]]/}`
  # echo -e "REDIS_REPLICA_COUNT: ${REDIS_REPLICA_COUNT}"
  REDIS_PV_SIZE=`cat ${INPUT_FILE} | grep -i ^REDIS_PV_SIZE | awk -F'=' '{print $2}'`
  REDIS_PV_SIZE=`echo ${REDIS_PV_SIZE} | xargs`
  REDIS_PV_SIZE=`echo ${REDIS_PV_SIZE//[[:blank:]]/}`
  # echo -e "REDIS_PV_SIZE: ${REDIS_PV_SIZE}"
  STORAGE_CLASS_NAME=`cat ${INPUT_FILE} | grep -i ^STORAGE_CLASS_NAME | awk -F'=' '{print $2}'`
  STORAGE_CLASS_NAME=`echo ${STORAGE_CLASS_NAME} | xargs`
  STORAGE_CLASS_NAME=`echo ${STORAGE_CLASS_NAME//[[:blank:]]/}`
  # echo -e "STORAGE_CLASS_NAME: ${STORAGE_CLASS_NAME}"
  REDIS_UISERVICE_TYPE=`cat ${INPUT_FILE} | grep -i ^REDIS_UISERVICE_TYPE | awk -F'=' '{print $2}'`
  REDIS_UISERVICE_TYPE=`echo ${REDIS_UISERVICE_TYPE} | xargs`
  REDIS_UISERVICE_TYPE=`echo ${REDIS_UISERVICE_TYPE//[[:blank:]]/}`
  # echo -e "REDIS_UISERVICE_TYPE: ${REDIS_UISERVICE_TYPE}"
  REDIS_ADMIN_USER=`cat ${INPUT_FILE} | grep -i ^REDIS_ADMIN_USER | awk -F'=' '{print $2}'`
  REDIS_ADMIN_USER=`echo ${REDIS_ADMIN_USER} | xargs`
  REDIS_ADMIN_USER=`echo ${REDIS_ADMIN_USER//[[:blank:]]/}`
  # echo -e "REDIS_ADMIN_USER: ${REDIS_ADMIN_USER}"
  REDIS_CPU_LIMIT=`cat ${INPUT_FILE} | grep -i ^REDIS_CPU_LIMIT | awk -F'=' '{print $2}'`
  REDIS_CPU_LIMIT=`echo ${REDIS_CPU_LIMIT} | xargs`
  REDIS_CPU_LIMIT=`echo ${REDIS_CPU_LIMIT//[[:blank:]]/}`
  # echo -e "REDIS_CPU_LIMIT: ${REDIS_CPU_LIMIT}"
  REDIS_CPU_REQUESTS=`cat ${INPUT_FILE} | grep -i ^REDIS_CPU_REQUESTS | awk -F'=' '{print $2}'`
  REDIS_CPU_REQUESTS=`echo ${REDIS_CPU_REQUESTS} | xargs`
  REDIS_CPU_REQUESTS=`echo ${REDIS_CPU_REQUESTS//[[:blank:]]/}`
  # echo -e "REDIS_CPU_REQUESTS: ${REDIS_CPU_REQUESTS}"
  REDIS_MEMORY_LIMIT=`cat ${INPUT_FILE} | grep -i ^REDIS_MEMORY_LIMIT | awk -F'=' '{print $2}'`
  REDIS_MEMORY_LIMIT=`echo ${REDIS_MEMORY_LIMIT} | xargs`
  REDIS_MEMORY_LIMIT=`echo ${REDIS_MEMORY_LIMIT//[[:blank:]]/}`
  # echo -e "REDIS_MEMORY_LIMIT: ${REDIS_MEMORY_LIMIT}"
  REDIS_MEMORY_REQUESTS=`cat ${INPUT_FILE} | grep -i ^REDIS_MEMORY_REQUESTS | awk -F'=' '{print $2}'`
  REDIS_MEMORY_REQUESTS=`echo ${REDIS_MEMORY_REQUESTS} | xargs`
  REDIS_MEMORY_REQUESTS=`echo ${REDIS_MEMORY_REQUESTS//[[:blank:]]/}`
  # echo -e "REDIS_MEMORY_REQUESTS: ${REDIS_MEMORY_REQUESTS}"
  REDIS_CLUSTER_UI_ROUTE_HOSTNAME=`cat ${INPUT_FILE} | grep -i ^REDIS_CLUSTER_UI_ROUTE_HOSTNAME | awk -F'=' '{print $2}'`
  REDIS_CLUSTER_UI_ROUTE_HOSTNAME=`echo ${REDIS_CLUSTER_UI_ROUTE_HOSTNAME} | xargs`
  REDIS_CLUSTER_UI_ROUTE_HOSTNAME=`echo ${REDIS_CLUSTER_UI_ROUTE_HOSTNAME//[[:blank:]]/}`
  # echo -e "REDIS_CLUSTER_UI_ROUTE_HOSTNAME: ${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}"
fi

## Validate the given input and make changes if required
## Validate the OCP_API_URL
if [ "${OCP_API_URL}" == "" ]
then
  echo -e "API URL[${OCP_API_URL}] is blank, can't proceed further. Exiting now."
  exit 1
else
  # echo -e "API URL[${OCP_API_URL}] is NOT blank"
  OCP_CLUSTER_NAME=`echo ${OCP_API_URL} | awk -F'.' '{print $2}'`
  OCP_DOMAIN=`echo ${OCP_API_URL} | rev | cut -d'.' -f -2 | rev`
  FRB_ENV=`echo ${OCP_DOMAIN} | awk -F'.' '{print $1}'`
  ROUTE_SUFFIX=`echo ${OCP_API_URL} | cut -d'.' -f 2-`
  CONSOLIDATED_ERRORS="/tmp/redis-cluster-setup-${OCP_CLUSTER_NAME}-${FRB_ENV}.${DATE}.errors"
fi

## Validate PROJECT_NAME
if [ "${PROJECT_NAME}" == "" ]
then
  echo -e "Project Name[${PROJECT_NAME}] is blank. Exiting now."
  exit 1
# else
#   echo -e "Project Name[${PROJECT_NAME}] is NOT blank"
fi

## Validate REDIS_REPLICA_COUNT
if [ "${REDIS_REPLICA_COUNT}" == "" ]
then
  # echo -e "REDIS_REPLICA_COUNT[${REDIS_REPLICA_COUNT}] is blank"
  REDIS_REPLICA_COUNT="${DEFAULT_REDIS_REPLICA_COUNT}"
else
  if [ ${REDIS_REPLICA_COUNT} -gt 3 ]
  then 
    REDIS_REPLICA_COUNT=${DEFAULT_REDIS_REPLICA_COUNT}
  fi
  # echo -e "REDIS_REPLICA_COUNT[${REDIS_REPLICA_COUNT}] is NOT blank"
fi

## Validate REDIS_PV_SIZE
if [ "${REDIS_PV_SIZE}" == "" ]
then
  # echo -e "REDIS_PV_SIZE[${REDIS_PV_SIZE}] is blank"
  REDIS_PV_SIZE="${REDIS_PV_SIZE}"
# else
#   echo -e "REDIS_PV_SIZE[${REDIS_PV_SIZE}] is NOT blank"
fi

## Validate STORAGE_CLASS_NAME
if [ "${STORAGE_CLASS_NAME}" == "" ]
then
  # echo -e "STORAGE_CLASS_NAME[${STORAGE_CLASS_NAME}] is blank"
  STORAGE_CLASS_NAME="${DEFAULT_STORAGE_CLASS_NAME}"
else
  # echo -e "STORAGE_CLASS_NAME[${STORAGE_CLASS_NAME}] is NOT blank"
  if [ "${STORAGE_CLASS_NAME}" != "thin01" ]
  then
    STORAGE_CLASS_NAME="${DEFAULT_STORAGE_CLASS_NAME}"
  fi
fi

## Validate REDIS_UISERVICE_TYPE
REDIS_UISERVICE_TYPE="${DEFAULT_REDIS_UISERVICE_TYPE}"
# if [ "${REDIS_UISERVICE_TYPE}" == "" ]
# then
  # echo -e "REDIS_UISERVICE_TYPE[${REDIS_UISERVICE_TYPE}] is blank"
  # REDIS_UISERVICE_TYPE="${DEFAULT_REDIS_UISERVICE_TYPE}"
# else
   # echo -e "REDIS_UISERVICE_TYPE[${REDIS_UISERVICE_TYPE}] is NOT blank"
   if [ "${REDIS_UISERVICE_TYPE}" != "${DEFAULT_REDIS_UISERVICE_TYPE}" ]
   then
     REDIS_UISERVICE_TYPE="${DEFAULT_REDIS_UISERVICE_TYPE}"
   fi
# fi

## Validate REDIS_ADMIN_USER
if [ "${REDIS_ADMIN_USER}" == "" ]
then
  # echo -e "REDIS_ADMIN_USER[${REDIS_ADMIN_USER}] is blank"
  # REDIS_ADMIN_USER="${DEFAULT_REDIS_ADMIN_USER}"
  REDIS_ADMIN_USER="admin@${OCP_DOMAIN}"
# else
  #   echo -e "REDIS_ADMIN_USER[${REDIS_ADMIN_USER}] is NOT blank"
fi

## Validate REDIS_CPU_LIMIT
if [ "${REDIS_CPU_LIMIT}" == "" ]
then
  # echo -e "REDIS_CPU_LIMIT[${REDIS_CPU_LIMIT}] is blank"
  REDIS_CPU_LIMIT="${DEFAULT_REDIS_CPU_LIMIT}"
# else
  # echo -e "REDIS_CPU_LIMIT[${REDIS_CPU_LIMIT}] is NOT blank"
fi

## Validate REDIS_CPU_REQUESTS
if [ "${REDIS_CPU_REQUESTS}" == "" ]
then
  # echo -e "REDIS_CPU_REQUESTS[${REDIS_CPU_REQUESTS}] is blank"
  REDIS_CPU_REQUESTS="${DEFAULT_REDIS_CPU_REQUESTS}"
# else
  # echo -e "REDIS_CPU_REQUESTS[${REDIS_CPU_REQUESTS}] is NOT blank"
fi

## Validate REDIS_MEMORY_LIMIT
if [ "${REDIS_MEMORY_LIMIT}" == "" ]
then
  # echo -e "REDIS_MEMORY_LIMIT[${REDIS_MEMORY_LIMIT}] is blank"
  REDIS_MEMORY_LIMIT="${DEFAULT_REDIS_MEMORY_LIMIT}"
# else
  # echo -e "REDIS_MEMORY_LIMIT[${REDIS_MEMORY_LIMIT}] is NOT blank"
fi

## Validate REDIS_MEMORY_REQUESTS
if [ "${REDIS_MEMORY_REQUESTS}" == "" ]
then
  # echo -e "REDIS_MEMORY_REQUESTS[${REDIS_MEMORY_REQUESTS}] is blank"
  REDIS_MEMORY_REQUESTS="${DEFAULT_REDIS_MEMORY_REQUESTS}"
# else
  # echo -e "REDIS_MEMORY_REQUESTS[${REDIS_MEMORY_REQUESTS}] is NOT blank"
fi

## Validate REDIS_CLUSTER_UI_ROUTE_HOSTNAME 
if [ "${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}" == "" ]
then
  # echo -e "REDIS_CLUSTER_UI_ROUTE_HOSTNAME[${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}] is blank"
  # REDIS_CLUSTER_UI_ROUTE_HOSTNAME="redis-cluster.apps.${OCP_CLUSTER_NAME}.${OCP_DOMAIN}"
  REDIS_CLUSTER_UI_ROUTE_HOSTNAME="redis-cluster.apps.${ROUTE_SUFFIX}"
# else
  # echo -e "REDIS_CLUSTER_UI_ROUTE_HOSTNAME[${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}] is NOT blank"
fi

## Print all the values
echo -e ""
echo -e "Here is the values would be used to setup the Redis Enterprise Cluster"
echo -e "********************************************************************************"
echo -e "OCP_API_URL: ${OCP_API_URL}"
echo -e "PROJECT_NAME: ${PROJECT_NAME}"
echo -e "REDIS_REPLICA_COUNT: ${REDIS_REPLICA_COUNT}"
echo -e "REDIS_PV_SIZE[${REDIS_PV_SIZE}]"
echo -e "STORAGE_CLASS_NAME="${DEFAULT_STORAGE_CLASS_NAME}"
echo -e "REDIS_UISERVICE_TYPE="${DEFAULT_REDIS_UISERVICE_TYPE}"
echo -e "REDIS_ADMIN_USER[${REDIS_ADMIN_USER}]"
echo -e "REDIS_CPU_LIMIT[${REDIS_CPU_LIMIT}]"
echo -e "REDIS_CPU_REQUESTS[${REDIS_CPU_REQUESTS}]"
echo -e "REDIS_MEMORY_LIMIT[${REDIS_MEMORY_LIMIT}]"
echo -e "REDIS_MEMORY_REQUESTS[${REDIS_MEMORY_REQUESTS}]"
echo -e "REDIS_CLUSTER_UI_ROUTE_HOSTNAME[${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}]"
echo -e "********************************************************************************"

## Logout from any OCP cluster currently logged in
echo -e "Logging out from previous session to avoid any issues\n"
${OC_CMD} logout > /dev/null 2>&1
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "INFO: You have not logged in to the cluster to logout"
else
  echo -e "INFO: Successfully logged out from the cluster"
fi
echo -e "********************************************************************************"

## Login to OCP_API_URL with your adm user account credentials(interactive mode)
echo -e "Logging into the OCP Cluster [${OCP_API_URL}], please ensure that you use your adm account\n"
echo -e "Running[${OC_CMD} login ${OCP_API_URL}]\n"
${OC_CMD} login ${OCP_API_URL}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "Failed to login to the cluster[${OCP_API_URL}]"
  exit 1
fi
echo -e "********************************************************************************"

## Check if the PROJECT_NAME is already exists or not. If not, exit
echo -e "Checking whether project ${PROJECT_NAME} is exists or not\n"
${OC_CMD} project ${PROJECT_NAME}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "\nERROR: Could not find the project[${PROJECT_NAME}], exiting now."
  exit 1
else
  echo -e "\nFound the project[${PROJECT_NAME}], will proceed further"
fi
echo -e "********************************************************************************"

## When you are here that means we have logged into the cluster and found the project as well

## Preparing required directories

## Delete if the cloned dir is already exists
echo -e "Delete the directory[${REDIS_GIT_DIR}] if found"
if [ -d ${REDIS_GIT_DIR} ]
then
  rm -rf "${REDIS_GIT_DIR}"
  CMD_EXIT_CODE=$?
  if [[ ${CMD_EXIT_CODE} -ne 0 ]]
  then
    echo -e "\tFailed to remove the existing dir[${REDIS_GIT_DIR}], to clone RedisLabs repo"
    exit 1
  else
    echo -e "\tFound existing folder[${REDIS_GIT_DIR}] and deleted it. We are good to proceed with cloning RedisLab repo"
  fi
else
  echo -e "INFO: Could not find the directory[${REDIS_GIT_DIR}] to delete"
fi
echo -e "********************************************************************************"

## Create the REDIS_SETUP_DIR if does not exists
echo -e "Create the directory[${REDIS_SETUP_DIR}] if not exists"
if [ ! -d ${REDIS_SETUP_DIR} ]
then
  mkdir ${REDIS_SETUP_DIR}
  CMD_EXIT_CODE=$?
  if [[ ${CMD_EXIT_CODE} -ne 0 ]]
  then
    echo -e "\tFailed to create the dir[${REDIS_SETUP_DIR}], which we need to clone RedisLabs repo\n"
    exit 1
  else
    echo -e "\tSuccess, created the dir[${REDIS_SETUP_DIR}], which we need to clone RedisLabs repo"
  fi
else
  echo -e "\tINFO: Directory[${REDIS_SETUP_DIR}] already exists"
fi
echo -e "********************************************************************************\n"
 
## Clone the RedisLabs Git
# git clone ${REDISLAB_GIT_REPO} ${REDIS_SETUP_DIR}/
echo -e "Cloning RedisLab Git Repo\n"
echo -e "Running [git clone ${REDISLAB_GIT_REPO} ${REDIS_GIT_DIR}/]\n"
git clone ${REDISLAB_GIT_REPO} ${REDIS_GIT_DIR}/
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "\nFailed to clone the RedisLabs REPO[${REDISLAB_GIT_REPO}]"
  echo -e "\nDue to proxy restrictions, this script might failed to clone the redis git automatically\n"
  read -p "Do you want to enter the path to the redislab doc(if you have downloaded already)? Y/N: " CONFIRM
  CONFIRM=${CONFIRM,,}
  if [ "${CONFIRM}" != "y" ]
  then
    echo -e "\nYou don't want to give the path, so exiting now"
    exit 0
  else
    echo -e ""
    read -p "Enter the complete path to downloaded redislab git repo: " REDIS_GIT_DIR
    REDIS_GIT_DIR=${REDIS_GIT_DIR}
  fi
else
  echo -e "Successfully cloned RedisLab Repo[${REDISLAB_GIT_REPO}]" 
fi
echo -e "\n********************************************************************************"
echo -e "                      Starting creating Redis Cluster"
echo -e "********************************************************************************\n"

## Apply the yaml files
echo -e "Creating required Security Context Constraints by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/openshift/scc.yaml]"
apply_yaml "${REDIS_GIT_DIR}/openshift/scc.yaml" "${PROJECT_NAME}"

echo -e "Adding scc to group by running[${OC_CMD} adm policy add-scc-to-group redis-enterprise-scc system:serviceaccounts:${PROJECT_NAME}]"
${OC_CMD} adm policy add-scc-to-group redis-enterprise-scc system:serviceaccounts:${PROJECT_NAME}
echo -e "********************************************************************************"

echo -e "Creating required roles by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/openshift/role.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/openshift/role.yaml" "${PROJECT_NAME}"

echo -e "Creating required service accounts by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/openshift/service_account.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/openshift/service_account.yaml" "${PROJECT_NAME}"

echo -e "Creating required rolebindings by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/openshift/role_binding.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/openshift/role_binding.yaml" "${PROJECT_NAME}"

echo -e "Creating Redis Enterprise Cluster CRD by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/crds/app_v1_redisenterprisecluster_crd.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/crds/app_v1_redisenterprisecluster_crd.yaml" "${PROJECT_NAME}"

echo -e "Creating Redis Enterprise Database by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/crds/app_v1alpha1_redisenterprisedatabase_crd.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/crds/app_v1alpha1_redisenterprisedatabase_crd.yaml" "${PROJECT_NAME}"

### operator_rhel.yaml can be applied by the app team if they have EDIT access in the PROJECT_NAME
echo -e "Creating Redis Enterprise Operator by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/openshift/operator_rhel.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/openshift/operator_rhel.yaml" "${PROJECT_NAME}"

## Create the ROLE to grant access to the application team to create the redis cluster
## TODO: Create Role

# UPDATE THE CONFIG PARAMETERS in the file redis-enterprise-cluster_rhel.yaml
echo -e "Generating redis-enterprise-cluster_rhel.yaml with required values"
generate_redis_enterprise_cluster_rhel_yaml
cp ${TMP_REDIS_ENTRPRS_CLUSTER_RHEL} ${REDIS_GIT_DIR}/openshift/redis-enterprise-cluster_rhel.yaml
echo -e "Below is the info going to be used to create the Redis Enterprise Cluster"
echo -e "********************************************************************************"
cat ${REDIS_GIT_DIR}/openshift/redis-enterprise-cluster_rhel.yaml
echo -e "********************************************************************************"

echo -e "Creating Redis Enterprise Cluster by running[${OC_CMD} apply -f ${REDIS_GIT_DIR}/openshift/redis-enterprise-cluster_rhel.yaml -n ${PROJECT_NAME}]"
apply_yaml "${REDIS_GIT_DIR}/openshift/redis-enterprise-cluster_rhel.yaml" "${PROJECT_NAME}"

# echo -e "\nGetting everything from namespace[${PROJECT_NAME}] by running[${OC_CMD} get all -n ${PROJECT_NAME}]"
# ${OC_CMD} get all -n ${PROJECT_NAME}
# echo -e "\n********************************************************************************\n"

## Check the PVC
echo -e "Checking the status of PVC\n"
check_pvc_status "${REDIS_PVC0}" "${PROJECT_NAME}"
check_pvc_status "${REDIS_PVC1}" "${PROJECT_NAME}"
check_pvc_status "${REDIS_PVC2}" "${PROJECT_NAME}"
echo -e "********************************************************************************"

## Retrieve the admin user password
echo -e "Retrieving admin password by running [${OC_CMD} get secret redis-enterprise --template={{.data.password}} -n ${PROJECT_NAME} | base64 -d]"
REDIS_ADMIN_PASSWORD=`${OC_CMD} get secret redis-enterprise --template={{.data.password}} -n ${PROJECT_NAME} | base64 -d`
echo -e "REDIS_ADMIN_PASSWORD: ${REDIS_ADMIN_PASSWORD}"
echo -e "********************************************************************************"

# echo -e "\nCheck the events by running[${OC_CMD} get events --sort-by='.metadata.creationTimestamp' -n ${PROJECT_NAME}]"
# ${OC_CMD} get events --sort-by='.metadata.creationTimestamp' -n ${PROJECT_NAME}
# echo -e "\n********************************************************************************\n"

echo -e "Creating the route by running[${OC_CMD} create route passthrough --service=redis-enterprise-ui --hostname=${REDIS_CLUSTER_UI_ROUTE_HOSTNAME} -n ${PROJECT_NAME}]"
${OC_CMD} create route passthrough --service=redis-enterprise-ui --hostname=${REDIS_CLUSTER_UI_ROUTE_HOSTNAME} -n ${PROJECT_NAME}
CMD_EXIT_CODE=$?
if [[ ${CMD_EXIT_CODE} -ne 0 ]]
then
  echo -e "\nERROR: Failed to create route[${REDIS_UI_ROUTE_NAME}]"
  echo -e "ERROR: Failed to create route[${REDIS_UI_ROUTE_NAME}]" >> ${CONSOLIDATED_ERRORS}
else
  echo -e "\nINFO: Created the route[${REDIS_UI_ROUTE_NAME}]"
  echo -e "********************************************************************************"
  echo -e "Checking the route that we created by running[${OC_CMD} get route ${REDIS_UI_ROUTE_NAME} -n ${PROJECT_NAME}]"
  ${OC_CMD} get route ${REDIS_UI_ROUTE_NAME} -n ${PROJECT_NAME}
  CMD_EXIT_CODE=$?
  if [[ ${CMD_EXIT_CODE} -eq 0 ]]
  then
    echo -e "Confirming that route[${REDIS_UI_ROUTE_NAME}] had been created and available"
  else
    echo -e "ERROR: Looks like route creation command was success but could not find the route yet, please check"
    echo -e "ERROR: Looks like route creation command was success but could not find the route yet, please check" >> ${CONSOLIDATED_ERRORS}
  fi
  echo -e "********************************************************************************"
  echo -e "Checking the DNS entry for the route hostname by running[nslookup ${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}]"
  nslookup ${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}
  CMD_EXIT_CODE=$?
  if [[ ${CMD_EXIT_CODE} -ne 0 ]]
  then
    DNS_EXISTS=false
    echo -e "\nWARNING: Seems you don't have the DNS entry for your route host name[${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}], please don't forget to create it"
    echo -e "\nWARNING: Seems you don't have the DNS entry for your route host name[${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}], please don't forget to create it" >> ${CONSOLIDATED_ERRORS}
  else
    DNS_EXISTS=true
    echo -e "\nGood news!! Now you can access your Redis Cluster UI using: [${REDIS_CLUSTER_UI_ROUTE_HOSTNAME}]"
  fi
fi
echo -e "********************************************************************************"

## Print the REDIS UI URL, admin username and password
final_summary

## End of script

