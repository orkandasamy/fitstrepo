# Enable access to registries

#### Using the below steps you can enable the access to the registries and communication between the OpenShift nodes, restrict access to below given registries
    - artrepo.firstrepublic.com:5101
    - artifactory.corp.firstrepublic.com
    - quay.io
    - registry.redhat.io
    - registry.access.redhat.com
    - registry.connect.redhat.com
    - cloud.redhat.com
    - image-registry.openshift-image-registry.svc:5000

**Refer:**

https://docs.openshift.com/container-platform/4.4/openshift_images/image-configuration.html#images-configuration-cas_image-configuration

https://access.redhat.com/solutions/5063741

https://access.redhat.com/support/cases/#/case/02825542 

## Pre-requisites:
* You MUST have OpenShift cluster admin access
* IP/NETWORK RANGE of the OpenShift nodes
* Registry names in FQDN format
* Trust Store(also called as CA) of the respective registry in **PEM format**. You can get the CA of all environments from \\\sfstore\IS-Installs\Certs

## Step-1: Update **noProxy** key in **spec** section with 
* OpenShift node's IP range(if not done already)
* **.corp.firstrepublic.com** and **.firstrepublic.com** 
* Any other registry FQDN which is not ending with above domain name
```
oc edit proxy/cluster
```
```
Example output:

spec:
  httpProxy: http://z_ocp_proxy:<PASSWORD>@vsproxynp3.corp.frbnp3.com:8080
  httpsProxy: http://z_ocp_proxy:<PASSWORD>@vsproxynp3.corp.frbnp3.com:8080
  noProxy: .cluster.local,.svc,10.0.0.0/16,10.128.0.0/14,127.0.0.1,172.30.0.0/16,api-int.ocp.corp.frbnp3.com,etcd-0.ocp.corp.frbnp3.com,etcd-1.ocp.corp.frbnp3.com,etcd-2.ocp.corp.frbnp3.com,localhost,10.7.198.0/23,.ocp.corp.frbnp3.com,.corp.frbnp3.com,.firstrepublic.com,.corp.firstrepublic.com

```
## Step-2: Configuring additional trust stores for image registry access and enforce kubelet to try pulling images from only the list of registries
* The trust store is the CA of the registry certificate
Create new configmap called registry-config in openshift-config namespace

**Note:** 
* Replace "\<CA-CERT-OF-REGISTRY\>" with the filename of the CA of the Registry Certificate
```
oc create configmap registry-config --from-file=artrepo.firstrepublic.com=<CA-CERT-OF-REGISTRY> -n openshift-config
```
Update the new configmap info to **spec** section in the cluster config using the below command
Edit the cluster config
```
oc edit image.config.openshift.io cluster
```
```
spec:
  additionalTrustedCA:
    name: registry-config
  registrySources:
    allowedRegistries:
    - artrepo.firstrepublic.com:5101
    - artifactory.corp.firstrepublic.com
    - quay.io
    - registry.redhat.io
    - registry.access.redhat.com
    - registry.connect.redhat.com
    - cloud.redhat.com
    - image-registry.openshift-image-registry.svc:5000
```
## Step-3: Create machine config using the attached files to let the pod pull images based on the image name without registry URL

**Important note:**  When thid was documented, we don't have INFRA nodes. If a new MCP gets created for infra, we would need to create a new MC(to update the unqualified-search-registries in registries.conf) for the infra role

Download the attached file and create the machine configs for master and worker nodes using the below commands
```
oc apply -f 99-worker-unqualified-search-registries.yaml
```
```
oc apply -f 99-infra-unqualified-search-registries.yaml
```
```
oc apply -f 99-master-unqualified-search-registries.yaml
```
## Step-4: Validate the setup
```
oc get cm registry-config -n openshift-config
```
```
oc get image.config.openshift.io cluster -o yaml -n openshift-config
```
```
oc describe cm registry-config -n openshift-config
```
## Step-5: Remove images manually from the nodes
* Verify the images currently available in ALL nodes by getting into each nodes
```
oc debug node/<NODE-NAME>
chroot /host
sudo su -
```
```
podman images list
```
* Remove the images which are pulled from unsupported registries
```
podman rmi [flags] IMAGE [IMAGE...]
```
## Sample output
```
$ oc get cm registry-config -n openshift-config
NAME              DATA   AGE
registry-config   1      135d
$
```
```
$ oc get image.config.openshift.io cluster -o yaml -n openshift-config
apiVersion: config.openshift.io/v1
kind: Image
metadata:
  annotations:
    release.openshift.io/create-only: "true"
  creationTimestamp: "2020-09-25T20:19:45Z"
  generation: 4
  name: cluster
  resourceVersion: "125614750"
  selfLink: /apis/config.openshift.io/v1/images/cluster
  uid: 7ca14aea-b03e-48db-8eec-ecc33170ee91
spec:
  additionalTrustedCA:
    name: registry-config
  registrySources:
    allowedRegistries:
    - artrepo.firstrepublic.com:5101
    - artifactory.corp.firstrepublic.com
    - quay.io
    - registry.redhat.io
    - registry.access.redhat.com
    - registry.connect.redhat.com
    - cloud.redhat.com
    - image-registry.openshift-image-registry.svc:5000
status:
  internalRegistryHostname: image-registry.openshift-image-registry.svc:5000
$
```
```
$ oc describe cm registry-config -n openshift-config
Name:         registry-config
Namespace:    openshift-config
Labels:       <none>
Annotations:  <none>

Data
====
artrepo.firstrepublic.com:
----
subject=CN=FRBSUBCA2-01, DC=corp, DC=firstrepublic, DC=com
issuer=CN=FRBROOTCA2
-----BEGIN CERTIFICATE-----
MIIFlzCCA3+gAwIBAgITQwAAAAQbbl+UmEzvGAABAAAABDANBgkqhkiG9w0BAQsF
ADAVMRMwEQYDVQQDEwpGUkJST09UQ0EyMB4XDTE1MDgzMTE4NDEzNloXDTI1MDgz
MTE4NTEzNlowYTETMBEGCgmSJomT8ixkARkWA2NvbTEdMBsGCgmSJomT8ixkARkW
DWZpcnN0cmVwdWJsaWMxFDASBgoJkiaJk/IsZAEZFgRjb3JwMRUwEwYDVQQDEwxG
UkJTVUJDQTItMDEwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCkjDIw
Egee9rCijvR/5l3yUZrJp9XzDcj8wYmqYvFPx+cY8hHRJjtxH5ngSJQYrO7sYPYH
v6wFqyz4YUbrJ4IqpZMKa3mMrxRiNiQcICgCV2t0HAybD2NaFDhWXxI2qhxLs6Zl
5jgi/sMjvJ1ve5Ho2+zZeu/yENkcI9OxxTWB62erkDftJla0qwtW+94BbOHnGojP
+Hod9Bpmfj5sGo6gPHojqeKCMNHa6WLeC/96mO5kiZfQjPEcTCCrDyD7Tya7nSAQ
Ceoit0fIOWClXOcDdH2eYgG0YRYbDbQNopj6wCsJ1/kfRYcU3Kr1cfQkHK6Xk9EC
0u/3kGPbdAv+pihVAgMBAAGjggGSMIIBjjAQBgkrBgEEAYI3FQEEAwIBATAjBgkr
BgEEAYI3FQIEFgQUdNjUKz1Kj+XZuPVB2W5sODZSJVwwHQYDVR0OBBYEFIHE2u7i
QjTcEvSQWczAWv7fcBjIMIGTBgNVHSAEgYswgYgwgYUGCCoDBIsvQ1kFMHkwOgYI
KwYBBQUHAgIwLh4sAEwAZQBnAGEAbAAgAFAAbwBsAGkAYwB5ACAAUwB0AGEAdABl
AG0AZQBuAHQwOwYIKwYBBQUHAgEWL2h0dHA6Ly9wa2kxLmNvcnAuZmlyc3RyZXB1
YmxpYy5jb20vcGtpL2Nwcy50eHQAMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBB
MAsGA1UdDwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFNxZg3n6
GVX2uMelNtl5Ajt/BjeXMEYGA1UdHwQ/MD0wO6A5oDeGNWh0dHA6Ly9wa2kxLmNv
cnAuZmlyc3RyZXB1YmxpYy5jb20vcGtpL0ZSQlJPT1RDQTIuY3JsMA0GCSqGSIb3
DQEBCwUAA4ICAQB6xxunzEJ4jMli2ImtdLJ6LaHM5EzpAzAeUb/lWccPFs1TlxMu
U7hMzqKJbNNWExJngPqSWV1OfeuQWRx928Izl4M/hl48YAkAsm1sP3nROfsjDkh8
SrXrjh81FsmFFzawHYVlBb6iC3RmSl61oMnUwbfBzn9Zz/YzqN5g/3UZpxnGSaSg
twkjpIK3XC/3qmIOd3j20U7NSLXSUygQchbxi8LjgkzOodvW5nePoN4VoXlSCS5/
1ixBAwCsZpcBKixxBGTWdyTpJ/KCgYE+TZ4NOlWC0HSmarWGQ1WBYmQ7erQMjyAT
JnwTJDjbPa47mteSmCRyceiMQlipGjKs70Um6dlj2Cdp+DagTWWSMdI0/dttOoQR
VbOj/AbX+Wzpr0xccMjB1hMqbDXBC45GIEBmLlsGc8tPydR+Pa676vbHQLYFGNM8
FLHaAZ1Go/VqzzZyyKc72yHZs7J184foX6/Hw4de1ztarGm4JhKl7dBo2S5deCYu
ka62w5p+/grgNV1X/bX2WVt8gYCCsvpF1uKRqfX8wA2t+6WkPCsDs7fxwqcKDmqF
ZKp8pr7jEpVfdjhZu6fiivgOuIHphGXsIntUm6Eg+RzWuDtQl0dR4wryz2/hl93l
uks6faBqG83WhEIr/EjVNDfmG5Al8/zETrOJWWergbq6ACaudG7YiOSHdA==
-----END CERTIFICATE-----

subject=CN=FRBROOTCA2
issuer=CN=FRBROOTCA2
-----BEGIN CERTIFICATE-----
MIIFxDCCA6ygAwIBAgIQee6xOfUvPYZFEmIQS5PNpzANBgkqhkiG9w0BAQsFADAV
MRMwEQYDVQQDEwpGUkJST09UQ0EyMB4XDTE0MTIxODE5MjczN1oXDTM1MDgzMTE3
NDc1M1owFTETMBEGA1UEAxMKRlJCUk9PVENBMjCCAiIwDQYJKoZIhvcNAQEBBQAD
ggIPADCCAgoCggIBAM+vMj9RT8jdN0lxP2FbKe/NABUKUWDt4nm7QM3IEz8Up/WK
STMnsEqg4KWE7Fyh3ravpi2gjJMA1tBn46zDcjaBEVRU3y+aIrKxGEBWCN4ntXQH
lCNcKzAzWg3kKb4HO7wSLwEZJ2snc0OBsU1nFWyuqe0WD9A6IBI44MK46uRBhEBk
KrsAcPAyXq1q4A51PXuZMYZRUmfBGcglR7Jw7qiDwJQPWWw7jfQL17MHkzrnwhoW
PDsAtQQVh4RtV6B7xitP58vJnZOwuAxbWSBDpRQcrFaInE1YC8qPHoPk1V9m+SCi
uCqO1OgGyVxDomy5cBzLV6oThji5wmx1onYpZrjcRwhHTGVwWj+VUpy9zW3x8Rz5
and4/Aet2/KRr+pPV8rNk4a4YbANnKoIfc26X46t6xf2reszlpEg4Yr5Kj4du1y7
TNfrMTUs8/dpk24f23AREN0INyHscEPKpvpbwveyvoXkbbXB8KdjfVD3hkJsxOtx
2WbHuPjUiAmUyCG9dxfDDfzgmkBbO+oCBp269HB+9aA1pkil1X03nBfykU8RJklA
KhW+cl/B2R2nuN02Jcp0BqthinaJX4ASb2IgtEQ7SNHXH+nTMt2ZzD+8nb+OU6wJ
jH7uLVfPvX2G0fF042MY8ObSuK4BBx/KHwHeFZBXJLAmTWYc75OzA37TUveHAgMB
AAGjggEOMIIBCjALBgNVHQ8EBAMCAYYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
FgQU3FmDefoZVfa4x6U22XkCO38GN5cwEAYJKwYBBAGCNxUBBAMCAQEwgZMGA1Ud
IASBizCBiDCBhQYIKgMEiy9DWQUweTA6BggrBgEFBQcCAjAuHiwATABlAGcAYQBs
ACAAUABvAGwAaQBjAHkAIABTAHQAYQB0AGUAbQBlAG4AdDA7BggrBgEFBQcCARYv
aHR0cDovL3BraTEuY29ycC5maXJzdHJlcHVibGljLmNvbS9wa2kvY3BzLnR4dAAw
IwYJKwYBBAGCNxUCBBYEFEDk4XZvC6KQI9AFdzYvsoEepuRyMA0GCSqGSIb3DQEB
CwUAA4ICAQDLAA9yPSSD7U1VO7EI9+p4OWTaV4iujeTKhaeDUfuFtnkrbajw0gzL
bRCtVg3uFa/IRpnl6Dswx/MuD9HrV+wByGkZ9c1dgjw0Utjs+O/V2XsiJj5ceSq7
YeIy1dLTWwPdyHhpLKF0FN8rmzfh3SIipNDMUZm/ETouJzJYpwFUJKGAOLFH+uGn
6Q2xN74jTUwhgqnP99yB+lKvpafy0inxXig8ugr5btygNySq7qhXGQRaT5eEgewk
k530ICLsiHYd61cKlMW7UTC+y8tz9G3fSacs0SQahrOG24nAVJoRlBC4SJ3A6DgF
oXKFIIIsJkS8Icf6660QAa2DHhQPdPDBnrYIb4PEUet9Fsho0zcrjxeDklAHJSLf
Ir9lx0mz6J5dxiDTrLjCd44fOMWYCrCies6O8/UQmbHKi+3u94hywCCLUCv5CfZS
oRxB3u6RRrnaDuLOnU3JoglPtyhcuDjVMn3iFp4JSSKDSK6VGQ/T2d/9mjvNOf/Z
Fh0nxc1P3ZaJe5NoFt9iiLDMY/3YvDp+Rxnl3C66mJ2aE5EOjiRZgDwhlWWrgSqh
IAPIMlC/o9VIJsda7R3XB6lgzVzg42GhDogebiPpiCWC32tQUJfmL+5Agk88WAec
ls15kpGEcwi8EgQ/CvjQtEys50slX0CoZ6HTuBInkQYccsGytdyVJQ==
-----END CERTIFICATE-----

Events:  <none>
$
```
```
$ oc debug node/np2ocpwkr1v.ocp.corp.frbnp2.com
Starting pod/np2ocpwkr1vocpcorpfrbnp2com-debug ...
To use host binaries, run `chroot /host`
If you don't see a command prompt, try pressing enter.
```
```
sh-4.2# chroot /host
sh-4.2# 
```
```
sh-4.4# sudo su -
Last login: Fri Mar  5 11:40:37 PST 2021 on pts/2
[root@np2ocpwkr1v ~]# 
```
```
[root@np2ocpwkr1v ~]# podman images list
REPOSITORY                                               TAG      IMAGE ID       CREATED         SIZE
artrepo.firstrepublic.com:5101/wealth-investor-doclist   <none>   327f1080221d   8 months ago    647 MB
artrepo.firstrepublic.com:5101/wealth-list-documents     <none>   849964777ede   8 months ago    658 MB
artrepo.firstrepublic.com:5101/wealth-vault-doclist      <none>   c7cd08bc5f5c   12 months ago   645 MB
[root@np2ocpwkr1v ~]#
```
