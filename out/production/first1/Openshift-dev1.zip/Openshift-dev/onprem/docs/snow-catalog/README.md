# Pre-requisites:
* You must have
  * **Cluster Admin access** in OpenShift Cluster  
# Preparing the YAML files 
* Clone or download the YAML files attached here
```
cd ; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git; cd ~/OpenShift/onprem/docs/snow-catalog/
```
**Login to OpenShift Cluster**
```
oc login <CLUSTER-API-URL>
```
**Create(if does not exists) "service-now" project**
```
oc new-project service-now
```
**Create the service account**
```
oc apply -f ~/OpenShift/onprem/docs/snow-catalog/service-account.yaml
```
**Verify and ensure that service account "z-snowopshift-user" got created**
```
oc get sa z-snowopshift-user -n service-now
```
```
oc describe sa z-snowopshift-user -n service-now
```
**Create cluster role**
```
oc apply -f ~/OpenShift/onprem/docs/snow-catalog/cluster-role.yaml
```
**Verify and ensure that clusterrole is created**
```
oc get clusterrole service-now-catalog-cluster-role 
```
```
oc describe clusterrole service-now-catalog-cluster-role
```
**Create cluster rolebinding**
```
oc apply -f ~/OpenShift/onprem/docs/snow-catalog/cluster-rolebinding.yaml
```
**Verify and ensure that cluster rolebinding is created**
```
oc get clusterrolebindings  service-now-catalog-sa-rolebinding
```
```
oc describe clusterrolebinding service-now-catalog-sa-rolebinding
```
**Retrieve the token for the service account "z-snowopshift-user" and share with Service-Now team**
```
oc serviceaccounts get-token z-snowopshift-user -n service-now
```
# Sample output is given below
```
$ pwd
/home/FRBNPGS/adm_sayyadurai/Openshift/onprem/docs/snow-catalog
$
```
```
$ ls -ltr 
total 16
-rw-r-----. 1 adm_sayyadurai domain users    4 Dec 28 17:27 README.md
-rw-r-----. 1 adm_sayyadurai domain users   98 Dec 28 17:28 service-account.yaml
-rw-r-----. 1 adm_sayyadurai domain users 1830 Dec 28 17:28 cluster-role.yaml
-rw-r-----. 1 adm_sayyadurai domain users  338 Dec 28 17:28 cluster-rolebinding.yaml
$
```
```
$ oc login https://api.ocp.corp.frbnp1.com              
Authentication required for https://api.ocp.corp.frbnp1.com:443 (openshift)
Username: adm_sayyadurai
Password: 
Login successful.

You have access to 117 projects, the list has been suppressed. You can list all projects with 'oc projects'

Using project "mware-infra".
$
```
```
$ oc new-project service-now
Now using project "service-now" on server "https://api.ocp.corp.frbnp1.com:443".

You can add applications to this project with the 'new-app' command. For example, try:

    oc new-app django-psql-example

to build a new example application in Python. Or use kubectl to deploy a simple Kubernetes application:

    kubectl create deployment hello-node --image=gcr.io/hello-minikube-zero-install/hello-node
```
```
$ oc apply -f ~/OpenShift/onprem/docs/snow-catalog/service-account.yaml
serviceaccount/z-snowopshift-user created
$
```
```
$ oc get sa z-snowopshift-user -n service-now
NAME                 SECRETS   AGE
z-snowopshift-user   2         11m
$
```
```
$ oc describe sa z-snowopshift-user -n service-now
Name:                z-snowopshift-user
Namespace:           service-now
Labels:              <none>
Annotations:         kubectl.kubernetes.io/last-applied-configuration:
                       {"apiVersion":"v1","kind":"ServiceAccount","metadata":{"annotations":{},"name":"z-snowopshift-user","namespace":"service-now"}}
Image pull secrets:  z-snowopshift-user-dockercfg-hd7pv
Mountable secrets:   z-snowopshift-user-token-7jk2p
                     z-snowopshift-user-dockercfg-hd7pv
Tokens:              z-snowopshift-user-token-45vzv
                     z-snowopshift-user-token-7jk2p
Events:              <none>
$
```
```
$ oc apply -f ~/OpenShift/onprem/docs/snow-catalog/cluster-role.yaml
clusterrole.rbac.authorization.k8s.io/service-now-catalog-cluster-role created
```
```
$ oc get clusterrole service-now-catalog-cluster-role 
NAME                               CREATED AT
service-now-catalog-cluster-role   2020-12-29T01:51:58Z
$
```
```
$ oc describe clusterrole service-now-catalog-cluster-role
Name:         service-now-catalog-cluster-role
Labels:       <none>
Annotations:  kubectl.kubernetes.io/last-applied-configuration:
                {"apiVersion":"rbac.authorization.k8s.io/v1","kind":"ClusterRole","metadata":{"annotations":{},"name":"service-now-catalog-cluster-role"},...
PolicyRule:
  Resources                                           Non-Resource URLs  Resource Names  Verbs
  ---------                                           -----------------  --------------  -----
  *.rbac.authorization.k8s.io                         []                 []              [*]
  resourcequotas                                      []                 []              [create update delete get list]
  limitranges                                         []                 []              [create update delete get watch list]
  namespaces                                          []                 []              [create update delete get watch list]
  projectrequests.project.openshift.io                []                 []              [create update delete get watch list]
  projects.project.openshift.io                       []                 []              [create update delete get watch list]
  quotas.project.openshift.io                         []                 []              [create update delete get watch list]
  *.route.openshift.io                                []                 []              [create update delete get watch list]
  configmaps                                          []                 []              [create update delete get]
  events                                              []                 []              [get list watch create update delete patch]
  nodes                                               []                 []              [get list]
  services                                            []                 []              [get list]
  pods                                                []                 []              [get watch list]
  rolebindingrestrictions                             []                 []              [get watch list]
  rolebindings                                        []                 []              [get watch list]
  roles                                               []                 []              [get watch list]
  rolebindingrestrictions.authorization.openshift.io  []                 []              [get watch list]
  rolebindings.authorization.openshift.io             []                 []              [get watch list]
  roles.authorization.openshift.io                    []                 []              [get watch list]
  groups                                              []                 []              [impersonate]
  serviceaccounts                                     []                 []              [impersonate]
  users                                               []                 []              [impersonate]
  persistentvolumeclaims                              []                 []              [list]
$
```
```
$ oc apply -f ~/OpenShift/onprem/docs/snow-catalog/cluster-rolebinding.yaml
clusterrolebinding.rbac.authorization.k8s.io/service-now-catalog-sa-rolebinding created
$
```
```
$ oc get clusterrolebindings  service-now-catalog-sa-rolebinding
NAME                                 ROLE                                           AGE
service-now-catalog-sa-rolebinding   ClusterRole/service-now-catalog-cluster-role   8s
$
```
```
$ oc describe clusterrolebinding service-now-catalog-sa-rolebinding
Name:         service-now-catalog-sa-rolebinding
Labels:       <none>
Annotations:  kubectl.kubernetes.io/last-applied-configuration:
                {"apiVersion":"rbac.authorization.k8s.io/v1","kind":"ClusterRoleBinding","metadata":{"annotations":{},"name":"service-now-catalog-sa-roleb...
Role:
  Kind:  ClusterRole
  Name:  service-now-catalog-cluster-role
Subjects:
  Kind            Name                Namespace
  ----            ----                ---------
  ServiceAccount  z-snowopshift-user  service-now
$ 
```
```
$ oc serviceaccounts get-token z-snowopshift-user -n service-now
eyJhbGcakif781hhfuvk001jhudVNEJFMVJ2UWJyVjU3cFlNZmV6UU9YSTFxWlZ1cDlYQi00M1B4SWVKR2MifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJzZXJ2aWNlLW5vdyIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJ6LXNub3dvcHNoaWZ0LXVzZXItdG9rZW4tN2prMnAiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoiei1zbm93b3BzaGlmdC11c2VyIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiMzgzYjRlOTctYWQ5Yi00NzQwLWI2MTQtYzU3MjRmYjljYjRiIiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50OnNlcnZpY2Utbm93Onotc25vd29wc2hpZnQtdXNlciJ9.UN62BNLxwoX9Tx0c1ANtSwuhJEB9voflYdDG6K2ZJoeYpreKMmI1EXsbGG87Psr85lMeO9u
$
```
