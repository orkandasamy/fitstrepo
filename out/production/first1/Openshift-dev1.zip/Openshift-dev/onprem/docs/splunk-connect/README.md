# Setup Splunk Connect

#### Using the below steps you setup splunk connect

## Getting started

The instructions given below with attached yaml / scripts files will help you to setup the Splunk connect.

Refer: 

Splunk Connect doc: https://github.com/splunk/splunk-connect-for-kubernetes


## Pre-requisites:
* Have Splunk HEC details to connect and forward logs
  * Contact Splunk Support team thru Service-Now request to get the HEC details
* You MUST have OpenShift cluster admin access
  * Refer Platform Admin Guide to know which AD group grants Cluster Admin Access
*

## Step-1: Get the OpenShift inventory file from GIT REPO
```
cd; rm -rf ~/Openshift; git clone https://github.firstrepublic.com/Middleware-Infra/Openshift.git
```
## Step-2: Modify the helm chart values for FRB
Update the "splunk:" section KEY/VALUE pair in the file **~/Openshift/onprem/docs/splunk-connect/values.<ENV>.yaml** with the values that was received from Splunk team. 
Copy "~/Openshift/onprem/docs/splunk-connect/install.sh" to ~/Openshift/onprem/docs/splunk-connect/install-<env>.sh and update "values.<env>.yaml"

**Replace everyting within the "\< \>" with actual values**
```
splunk:
    hec:
      # host is required and should be provided by user
      host:  <SPLUNK-SERVER-vIP-NAME>
      # port to HEC, optional, default 8088
      port:  8088
      # token is required and should be provided by user
      token:  <HEC-TOKEN-RECEIVED-FROM-SPLUNK-TEAM>
      
      ...
      kubernetes:
    # The cluster name used to tag logs. Default is cluster_name
    clusterName: "<OCP-DOMAIN-NAME>"
    
```
**Example value is given below for your understanding**
```
  splunk:
    hec:
      # host is required and should be provided by user
      host:  npgsrhsplksys1v.frbnpgs.com
      # port to HEC, optional, default 8088
      port:  8088
      # token is required and should be provided by user
      token:  17a40aa6-77b0-485b-8684-c6159dc77ff0
      
      ...
  kubernetes:
    # The cluster name used to tag logs. Default is cluster_name
    clusterName: "ocp.corp.frbnp1.com"

      
```

## Step-1: Go to the folder
cd ~/Openshift/onprem/docs/splunk-connect/

**If your OpenShift version is 4.4** then no changes required to these files 
## Step-2: Login to the OpenShift cluster where you want to setup the splunk connect
```
oc login
```
## Step-3: Run the install script for your environment
```
./install-<env>.sh
```
By Default, the image fluentd-hec:1.2.4 url point to docker.io which is blocked in our environment. This image is pushed into artrepo , available locally. 
update the image point to artrepo and save and add tolerance for infra node under tolerance section. Under tolerations section , append the following lines and save

        - effect: NoExecute
        key: infra
        operator: Equal
        value: reserved
      - effect: NoSchedule
        key: infra
        operator: Equal
        value: reserved
        

```
oc edit ds/splunk-connect-splunk-kubernetes-logging

image: artrepo.firstrepublic.com:5101/splunk/fluentd-hec:1.2.4



tolerations:
- effect: NoSchedule
  key: node-role.kubernetes.io/master
- effect: NoExecute
  key: infra
  operator: Equal
  value: reserved
- effect: NoSchedule
  key: infra
  operator: Equal
  value: reserved
```
## Step-4: Validate the setup

**Check for the dpeloyment**
```
oc get all -n splunk-connect
```


**Check the Events**
```
oc get events --sort-by='.metadata.creationTimestamp' -n splunk-connect
```

## Step-5: Sample output for splunk-connect Setup
```
$ ./install-dc2ext.sh 
Now using project "splunk-connect" on server "https://api.extdrocp.frbprod.com:443".

You can add applications to this project with the 'new-app' command. For example, try:

    oc new-app ruby~https://github.com/sclorg/ruby-ex.git

to build a new example application in Ruby. Or use kubectl to deploy a simple Kubernetes application:

    kubectl create deployment hello-node --image=gcr.io/hello-minikube-zero-install/hello-node

"splunk" has been added to your repositories
NAME    NAMESPACE       REVISION        UPDATED STATUS  CHART   APP VERSION
NAME: splunk-connect
LAST DEPLOYED: Tue Mar 23 13:48:46 2021
NAMESPACE: splunk-connect
STATUS: deployed
REVISION: 1
TEST SUITE: None


$ oc get all
NAME                                                 READY   STATUS    RESTARTS   AGE
pod/splunk-connect-splunk-kubernetes-logging-69ggs   1/1     Running   0          17h
pod/splunk-connect-splunk-kubernetes-logging-7ntfw   1/1     Running   0          17h
pod/splunk-connect-splunk-kubernetes-logging-7xlld   1/1     Running   0          17h
pod/splunk-connect-splunk-kubernetes-logging-cn2dm   1/1     Running   0          17h
pod/splunk-connect-splunk-kubernetes-logging-h976p   1/1     Running   0          17h
pod/splunk-connect-splunk-kubernetes-logging-lgtht   1/1     Running   0          17h
pod/splunk-connect-splunk-kubernetes-logging-r9mxd   1/1     Running   0          17h

NAME                                                      DESIRED   CURRENT   READY   UP-TO-DATE   AVAILABLE   NODE SELECTOR                 AGE
daemonset.apps/splunk-connect-splunk-kubernetes-logging   7         7         7       7            7           beta.kubernetes.io/os=linux   17h

```
## Step-6: verify openshift logs in splunk
use the following simple query to see the logs in splunk

index=docker host="*ocp*" namesapce="*mdm*"



