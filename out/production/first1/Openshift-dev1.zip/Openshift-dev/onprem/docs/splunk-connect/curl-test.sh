curl -k https://npgsrhsplksys1v.frbnpgs.com:8088/services/collector -H 'Authorization: Splunk 11ca34d7-6186-4991-bebd-79df461b6ce9' -d '{"sourcetype": "openshift", "event":"Hello, World! np2"}' 
