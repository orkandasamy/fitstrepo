oc new-project splunk-connect
./helm repo add splunk https://splunk.github.io/splunk-connect-for-kubernetes/
./helm list
./helm install splunk-connect -f values.dc2ext.yaml splunk/splunk-connect-for-kubernetes
for sa in $(oc  get sa --no-headers  | grep splunk | awk '{ print $1 }'); do
 oc adm policy add-scc-to-user privileged -z $sa
 done
