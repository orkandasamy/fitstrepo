oc new-project splunk-connect
./helm install splunk-connect -f values.qnt.yaml splunk/splunk-connect-for-kubernetes
for sa in $(oc  get sa --no-headers  | grep splunk | awk '{ print $1 }'); do
 oc adm policy add-scc-to-user privileged -z $sa
 done
