# Upgrading OpenShift Platform (NO ROLLBACK)
#### Use case
* You have an exisitng OpenShift cluster
* You want to upgrade patch or minor or major version of the platform

**Refer:** https://access.redhat.com/labs/ocpupgradegraph/update_channel

**Important Note:** 
* DO NOT take any VM snapshot
* NO ROLLBACK is available
* If you are stuck in the middle of upgrade, work with redhat to get the solution
* Before you start the upgrade, you must READ this README file at lease once or twice from TOP to BOTTOM and understand the steps

## Getting started
**Upgrade process involves multiple steps as given below**
* Verify and ensure that OpenShift CLUSTER is in GREEN state without any issues. If you see any issues with cluster, fix it before upgrade
* Create change request and ensure that its approved(we need for all env)
* Notify application teams with upgrade details and change window
* Start the upgrade(patch or minor or major)
* Validate the upgrade
* Notify the app team about the status of the upgrade
* Sign-off and close the change request as required

## Step-1: Login to OpenShift cluster and verify health of the cluster
* Use the attached **"get-info-from-cluster.sh" script** to collect the information and then validate the output 
* Ensure that there is no clock sync issue in any of the OpenShift nodes. How to verify this?
  * You can verify the events via OpenShift Console and find this clock issue if its happening
  * OR create debug POD to each node and run the command "chronyc tracking" to check the status
  * OR Reach LE team for help
* Open PROACTIVE TICKET with RedHat Support and update about the upgrade schedule
  * This is to inform redhat about our upgrade activity and may need Redhat's support if we stuck during upgrade
## Step-2: Create change request as required based on the environment and ensure that its approved
* Go to Service-now tool and raise the change requestand get it approved.
* For change request window we need to select, please refer OpenShift Platform Admin Guide
## Step-3: Notify application teams with upgrade details and change window
* Notify the app teams using openshift-notification@firstrepublic.com DL
## Step-4: Start the upgrade(patch or minor or major)
* Start the upgrade only during the change window
  * Ensure MachineConfigPools created and available for master, infra and worker roles (minimum). In NP1 we have smb-worker mcp additionaly
  ```
  oc get mcp -o wide
  ```
  * Create **machine config pool** if not exists using the below command. 
    * Attached the "infra-mcp.yaml" which would create mcp for infra role
    ```
    oc apply -f infra-mcp.yaml
    ```
  * Use the attached **"get-info-from-cluster.sh" script** to collect the information and then validate the output 
  * Ensure that there is no clock sync issue in any of the OpenShift nodes. How to verify this?
    * You can verify the events via OpenShift Console and find this clock issue if its happening
    * OR create debug POD to each node and run the command "chronyc tracking" to check the status
    * OR Reach LE team for help
  * Verify **closely/carefully** and ensure that below are in good state
    * **All NODES are in READY, schedulable state with same kubernete version**
    * **All CLUSTER OPERATORS are in AVAILABLE state and in same version.** Nothing should be in progressing and/or degraded state
    * **All MachineConfigPool in the cluster has READYMACHINECOUNT as same as MACHINECOUNT**
    * **All OpenShift related PODS and CONTAINERS are in RUNNING state**
    * **No clock sync issue in any OpenShift node(master/infra/worker)**
  * Login to the Console UI with CLUSTER ADMIN privilege and navigate to **Administration -> Cluster Settings** and then **click on "Details" tab in the right side panel** 
    * Ensure that you choose right channel
    * Validate that your current OpenShift Cluster version displayed correctly
    * Click on **"Update Now"** button and choose the target version you need and click **"Update"** button you see there
  * It may take approx 2 hours to complete the upgrade. During this upgrade
    * Cluster operators will be upgraded
    * Nodes will be rebooted(PODs on the restarting node will be evicted)
    * and many more action will be taken automatically by the upgrade process
    * TIP: **Below cluster operators are the one get upgraded in the last**
      * network
      * dns
      * machine-config
  * Be patient and monitor the upgrade process
    * Watch for any errors/failures and take action only if its stuck in the same state for long time
## Step-5: Validate the upgrade
* Once upgrade is done, validate the cluster and ensure that all GREEN
  * Use the attached **"get-info-from-cluster.sh" script** to collect the information and then validate the output 
  * **Important:** 
    * **All NODES are in READY, schedulable state with same kubernete version**
    * **All CLUSTER OPERATORS are in AVAILABLE state and in same version.** Nothing should be in progressing and/or degraded state
    * **All MachineConfigPool in the cluster has READYMACHINECOUNT as same as MACHINECOUNT**
    * **All OpenShift related PODS and CONTAINERS are in RUNNING state**
    * **No clock sync issue in any OpenShift node(master/infra/worker)**
## Step-6: Are you stuck in the upgrade?
* If you feel that upgrade is stuck/failed, then you have to contact RedHat Support, **THERE IS NO TOLL BACK OPTION**
  * Open a PRIORITY TICKET with RedHat Support, **call 888-GO-REDHAT** to escalate it immediately
  * Work with RedHat support and take it forward
## Step-7: Notify the app team about the status of the upgrade
* Notify the app teams using openshift-notification@firstrepublic.com DL about the upgrade and ask them to validate their apps
## Step-8: Sign-off and close the change request as required
* If you have opened the change, please close it with validation output(before and after upgrade)
* Update your JIRA story/sub-tasks with details and close the story
## Step-: Sample output

TBD
