#!/bin/bash
## Script to collect the information from the cluster
##
## Input argument is a filename where to send this output. If nothing is passed, will be sent to /tmp/ folder
##
DATE=`date "+%Y-%m-%d-%H-%M-%S"`
OUTPUT_DIR="${HOME}/cluster-health-${DATE}"
POSSIBLE_ISSUES="${OUTPUT_DIR}/possible-issues-in-the-cluster-${DATE}.txt"

if [ $# -gt 0 ]
then
  OUTPUT_FILE="$1"
else
  OUTPUT_FILE="${OUTPUT_DIR}/cluster-info-${DATE}.txt"
fi

if [ ! -d ${OUTPUT_DIR} ]
then
  mkdir -p ${OUTPUT_DIR}
fi

echo -e "====================================================================================\n" >> ${OUTPUT_FILE}
echo -e "Timestamp: ${DATE}" >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nCurrently loggedin OpenShift Cluster Name and Current Project:\n" >> ${OUTPUT_FILE}
oc project >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nCurrently loggedin user:\n" >> ${OUTPUT_FILE}
oc whoami >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nCluster Version:\n" >> ${OUTPUT_FILE} 
oc get clusterversion >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nCluster Operators:\n" >> ${OUTPUT_FILE}
oc get clusteroperators >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nNodes in the cluster:\n" >> ${OUTPUT_FILE}
oc get nodes -o wide >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nMachineConfigPool in the cluster:\n" >> ${OUTPUT_FILE}
oc get mcp -o wide >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nPods NOT in good state from all namespaces:\n" >> ${OUTPUT_FILE}
oc get pods -A -o wide | grep -v "Running\|Completed\|Terminated" >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nALL PODS status from all namespaces:\n" >> ${OUTPUT_FILE}
oc get pods -A -o wide >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

echo -e "\nALL ROUTES from all namespaces:\n" >> ${OUTPUT_FILE}
oc get routes -A -o wide >> ${OUTPUT_FILE}
echo -e "====================================================================================\n" >> ${OUTPUT_FILE}

#########################################################

### Get possible issues and save it in a file
echo -e "====================================================================================\n" >> ${POSSIBLE_ISSUES}
echo -e "Timestamp: ${DATE}" >> ${POSSIBLE_ISSUES}
echo -e "====================================================================================\n" >> ${POSSIBLE_ISSUES}
echo -e "\nCurrently loggedin OpenShift Cluster Name and Current Project:\n" >> ${POSSIBLE_ISSUES}
oc project >> ${POSSIBLE_ISSUES}
echo -e "====================================================================================\n" >> ${POSSIBLE_ISSUES}

echo -e "\nCurrently loggedin user: `oc whoami` \n" >> ${POSSIBLE_ISSUES}
# oc whoami >> ${POSSIBLE_ISSUES}
echo -e "====================================================================================\n" >> ${POSSIBLE_ISSUES}

echo -e "If you done see anything below then you are kind of good(hopefully :-) )\n\n" >> ${POSSIBLE_ISSUES}

CLUSTER_VERSION_AVAILABLE=`oc get clusterversion | egrep -v "NAME" | awk -F' ' '{print $3}'`
CLUSTER_VERSION_PROGRESSING=`oc get clusterversion | egrep -v "NAME" | awk -F' ' '{print $4}'`
if [[ "${CLUSTER_VERSION_AVAILABLE}" == "False" ]] || [[ "${CLUSTER_VERSION_PROGRESSING}" == "True" ]]
then
  # oc get clusterversion -o jsonpath='{.items[].status.conditions[]}{"\n"}'
  echo -e "\nDO NOT START UPGRADE ====> Cluster Version state is not good\n" >> ${POSSIBLE_ISSUES}
  # oc get clusterversion >> ${POSSIBLE_ISSUES}
fi

CO_BAD_STATE_COUNT=`oc get co | egrep -v "NAME|True        False         False" | wc -l`
if [ ${CO_BAD_STATE_COUNT} -gt 0 ]
then
  echo -e "\nDO NOT START UPGRADE ====> Cluster Operators not in good state\n" >> ${POSSIBLE_ISSUES}
  oc get co | egrep -v "NAME|True        False         False" >> ${POSSIBLE_ISSUES}
fi

NODES_COUNT_WITH_DIFF_K8S_VERSION=`oc get nodes | egrep -v "NAME" | awk -F' ' '{print $5}' | sort | uniq | wc -l`
if [ ${NODES_COUNT_WITH_DIFF_K8S_VERSION} -gt 1 ]
then
  echo -e "\nNode with different kubernete version\n" >> ${POSSIBLE_ISSUES}
  echo -e "DO NOT START UPGRADE ====> All nodes are not in same K8s version" >> ${POSSIBLE_ISSUES}
fi

MCP_LIST="/tmp/mcps-${DATE}.txt"
oc get mcp -o go-template='{{range .items}}{{index .metadata.name}}{{"\n"}}{{end}}' > ${MCP_LIST}
# cat ${MCP_LIST}
## check if we have at least master, infra and worker mcp
if [[ `cat ${MCP_LIST} | egrep "^master$"` ]] && [[ `cat ${MCP_LIST} | egrep "^infra$"` ]] && [[ `cat ${MCP_LIST} | egrep "^worker$"` ]]
then
  : #echo -e "Atleast 3 minimum mcp exists to validate"
else
  echo -e "DO NOT START UPGRADE ====> One or more of the minimum required MCP does not exists" >> ${POSSIBLE_ISSUES}
fi
if [ -s ${MCP_LIST} ]
then
  # echo -e "File is not empty"
  for MCP in `cat ${MCP_LIST}`
  do
   MACHINE_COUNT=`oc get mcp ${MCP} -o template --template '{{.status.machineCount}} {{"\n"}}'`
   READY_MACHINE_COUNT=`oc get mcp ${MCP} -o template --template '{{.status.readyMachineCount}} {{"\n"}}'`
   # echo -e "MCP Name: [${MCP}]\tMACHINE_COUNT: [${MACHINE_COUNT}]\tREADY_MACHINE_COUNT: [${READY_MACHINE_COUNT}]"
   if [[ ${MACHINE_COUNT} -ne ${READY_MACHINE_COUNT} ]] 
   then
     echo -e "DO NOT START UPGRADE ====> One or more nodes in the MCP[${MCP}] is NOT READY" >> ${POSSIBLE_ISSUES}
     oc get mcp ${MCP} >> ${POSSIBLE_ISSUES}
   fi
  done
fi
echo -e "====================================================================================\n" >> ${POSSIBLE_ISSUES}

#####

echo -e "\n\n===================================================\n"
echo -e "\nAll output saved in the file [${OUTPUT_FILE}]"
echo -e "\nISSUE LIST saved in the file [${POSSIBLE_ISSUES}]"
echo -e "\n===================================================\n"
