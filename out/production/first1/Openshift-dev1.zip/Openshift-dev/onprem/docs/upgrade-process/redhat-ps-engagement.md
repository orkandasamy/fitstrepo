
**Completed Tasks:**
1.	Redhat access issues are resolved
2.	De-prioritized AppDev resource and repurpose the hours for future engagement
3.	De-prioritized Block Storage discussions and focus on File Systems requirements to integrate with Trident or CSI/SMB in short term and NFS v4 when FRB starts supporting. Needs formal notification from FRB to amend the SOW.
4.	Completed successful upgrade to NP1, Quant Clusters to 4.7.13 (4.5.14 -> 4.5.36 -> 4.6.31 -> 4.7.13) and NP2/NP3  upgraded to 4.6.31 (4.5.14 -> 4.5.36-> 4.6.31). Learned a whole lot on this process and identified some enhancement requests .
5.	Reviewed existing Alert Manager setup and integration with ServiceNow using Webhooks, current challenges to enhance the Alerts and Notification process
 
**In Progress/Upcoming Tasks:**
1.	Np1/New nodes  (Node 5-6) data is not coming to NewRelic, continue to troubleshoot
2.	NP2 – Redis eviction PODs timed out due to maxUnavailble field on the configurations to 1. Engaged Redis and identified the Time Sync caused for nodes to be out of synch.
3.	Continue to focus on Alerts (what alerts, what actions to take)
4.	Now that NP1 is available, instrument FluxCD (it requires OCP 4.6 or above)and continue with Day 2 related discussions
5.	Possible on-premise Sandbox setup to continue our discussions on Storage options (Trident or CSI/SMB) and any POCs
 
**Issues/Blockers:**
1.	Engage Linux Administration team to identify the cause of drift on NTP clock sync in NP1/NP2 nodes
2.	During the Redhat support discussions, we have shared the MUST-GATHER info several times, but none of the discussions called out all the PODs, operators and nodes MUST to be in ready state before we trigger the upgrade process. We needs to understand why this was NOT called out…(Redhat Support ticket SR 02946021)
3.	No automated checks prior to initiating the Upgrade process, if its pausing a report will help to understand why this is paused and what actions we need to take to proceed – Enhancement request needed, following up with TAM to raise this request
4.	We understands, its always roll forward and there is NO rollback option from the failed/paused state.
 
**Lessons Learned:**
1.	All Nodes are in Ready, schedulable state with same Kubenetes version
2.	All Cluster Operators are in Available state and in same version. Nothing should in progressing and/or degraded state
3.	All Machine Config Pool in the cluster has readyMachineCount as same as MachineCount
4.	All Openshift related PODs and Containers are in Running State
5.	No NTP Clock synch issues in any of the openshift nodes (Infra, Master and Worker nodes) 
6.	No downtime during the Upgrade process (always rolling restarts)
7.	Ability to always roll forward – Kube API migrations are not reversible and vary from component to component
8.	Pause on any blocking errors – without impacting the clusters. All components monitor their health, most errors do not impact functionality
9.	During upgrade process, Machine Config Operator(MCO) applies the new configuration to cluster machines. MCO cordons the number of nodes as specified by the maxUnavailable field on the machine config pool and marks them as unavailable. By default, this sets to 1. 
