# Velero back-up and restore steps using S3 bucket
Below steps were verified and confirmed with velero version 1.5.3

## Getting started
Below steps are prepared using the below URLs(not limited to)

Docs:

https://medium.com/ibm-garage/how-to-install-velero-in-an-openshift-environment-f7484fabbbe4

https://github.com/vmware-tanzu/velero/releases/tag/v1.5.3

https://velero.io/docs/main/basic-install/

https://velero.io/docs/v1.5/restic/

https://www.youtube.com/watch?reload=9&v=N4vDsoZ9KNk

https://velero.io/docs/v1.5/troubleshooting/#debug-installation-setup-issues

Issues:

https://github.com/vmware-tanzu/velero/issues/2085

https://github.com/vmware-tanzu/velero/issues/2913

https://github.com/vmware-tanzu/velero/issues/2942

## Pre-requisites
* Velero must be installed
* S3 bucket must be ready
* Access from OpenShift cluster to S3 bucket must be opened
## Setting up velero
**Get the S3 bucket**
* Work with cloud engineering team and get the S3 bucket
  * Naming standard: frb-\<ENV\>-ocp4-\<OCP-CLUSTER-NAME\>-velero
  * Ex: frb-np1-ocp4-ocp-velero 

**Install velero software**
* SSH to admin host
```
ssh <OCP4-ADMIN-HOSTNAME>
```
* Download the velero product. For us, its available in the linux repo: https://artrepo/artifactory/Linux_Engineering_Installs/velero-v1.5.3-linux-amd64.tar.gz
```
curl -O https://artrepo/artifactory/Linux_Engineering_Installs/velero-v1.5.3-linux-amd64.tar.gz
```
* Extract the downloaded archive file
```
tar -xzvf velero-v1.5.3-linux-amd64.tar.gz
```
* Switch to extracted folder
```
cd velero-v1.5.3-linux-amd64
```
**Create the credential file**
```
echo "[default]" > credentials
echo "aws_access_key_id" = <AWS-S3-BUCKET-ACCESS-KEY> >> credentials
echo "aws_secret_access_key" = <AWS-S3-BUCKET-SECRET-KEY> >> credentials
```
**Install Velero**
```
./velero install --provider aws --plugins velero/velero-plugin-for-aws:v1.0.0 --bucket frb-np1-ocp4-ocp-velero --secret-file ./credentials --use-volume-snapshots=true --backup-location-config region=us-west-2 --snapshot-location-config region=us-west-2 --velero-pod-cpu-request 1000m --velero-pod-mem-request 512Mi --velero-pod-cpu-limit 2000m --velero-pod-mem-limit 1024Mi 
```
**Add proxy variables to  deployment.apps/velero** If you dont have direct firewall opened to your AWS S3 bucket, then you need this to reach AWS S3 bucket
* Edit the deployment and add the proxy variables to **spec** section belongs to **containers** so that it can access S3 bucket
```
oc edit deployment.apps/velero
```
* Add only **HTTP_PROXY**, **HTTPS_PROXY** and **NO_PROXY** to deployment.apps/velero.
```
spec:
  progressDeadlineSeconds: 600
  replicas: 1
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      deploy: velero
  strategy:
    rollingUpdate:
      maxSurge: 25%
      maxUnavailable: 25%
    type: RollingUpdate
  template:
    metadata:
      annotations:
        prometheus.io/path: /metrics
        prometheus.io/port: "8085"
        prometheus.io/scrape: "true"
      creationTimestamp: null
      labels:
        component: velero
        deploy: velero
    spec:
      containers:
      - args:
        - server
        - --features=
        command:
        - /velero
        env:
        - name: HTTP_PROXY
          value: <GET-IT-FROM-YOUR-OPENSHIFT-CLUSTER>
        - name: HTTPS_PROXY
          value: <GET-IT-FROM-YOUR-OPENSHIFT-CLUSTER>
        - name: NO_PROXY
          value: <GET-IT-FROM-YOUR-OPENSHIFT-CLUSTER>
```
Run the below command to fix the error related to backup location "default" not found
```
./velero install --crds-only --dry-run -o yaml | oc apply -f -
```
```
oc set image deployment/velero velero=velero/velero:v1.5.3 --namespace velero 
```
## Validation
```
oc get all
```
```
oc get backupstoragelocations 
```
```
oc get backupstoragelocations default -o yaml
```
```
oc logs <VELERO-POD>
```
## Run test backup
**Create new project**
```
oc new-project test-backup
```
**Create some configmap**
```
for i in {1..20}; do echo Creating ConfigMap $i; oc create configmap cm-$i --from-literal="key=$i" -n test-backup; done
```
**Ensure that configmaps are created**
```
oc get configmap -n test-backup
```
**Run the backup**
```
./velero backup create my-backup --include-namespaces test-backup
```
**Get the backups list**
```
./velero get backups
```
**Verify the backup you created**
```
./velero backup describe my-backup
```
**Verify the velero pod's log for any error**
```
oc logs <VELERO-POD>
```
**Verify backup logs**
* **Note:** You will get the logs for your backup name only if it was success. If your backup was failed, you won't get the log for it
```
 ./velero backup logs my-backup
```
## Test the backup by restoring it
**Delete project**
```
oc delete project test-backup
```
**Restore backup**

./velero restore create --from-backup my-backup 

## Clean up the test project and backup 
**Remove the test backup**
```
./velero delete backup my-backup
```
**Delete the test project**
```
oc delete project test-backup
```
## Sample output
Incomplete sample outputs(ie not captured for all steps)
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ oc whoami
adm_sayyadurai
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ ./velero install --provider aws --plugins velero/velero-plugin-for-aws:v1.0.0 --bucket frb-np1-ocp4-ocp-velero --secret-file ./credentials-velero --use-volume-snapshots=true --backup-location-config region=us-west-2 --snapshot-location-config region=us-west-2 --velero-pod-cpu-request 1000m --velero-pod-mem-request 512Mi --velero-pod-cpu-limit 2000m --velero-pod-mem-limit 1024Mi 
CustomResourceDefinition/backups.velero.io: attempting to create resource
CustomResourceDefinition/backups.velero.io: created
CustomResourceDefinition/backupstoragelocations.velero.io: attempting to create resource
CustomResourceDefinition/backupstoragelocations.velero.io: created
CustomResourceDefinition/deletebackuprequests.velero.io: attempting to create resource
CustomResourceDefinition/deletebackuprequests.velero.io: created
CustomResourceDefinition/downloadrequests.velero.io: attempting to create resource
CustomResourceDefinition/downloadrequests.velero.io: created
CustomResourceDefinition/podvolumebackups.velero.io: attempting to create resource
CustomResourceDefinition/podvolumebackups.velero.io: created
CustomResourceDefinition/podvolumerestores.velero.io: attempting to create resource
CustomResourceDefinition/podvolumerestores.velero.io: created
CustomResourceDefinition/resticrepositories.velero.io: attempting to create resource
CustomResourceDefinition/resticrepositories.velero.io: created
CustomResourceDefinition/restores.velero.io: attempting to create resource
CustomResourceDefinition/restores.velero.io: created
CustomResourceDefinition/schedules.velero.io: attempting to create resource
CustomResourceDefinition/schedules.velero.io: created
CustomResourceDefinition/serverstatusrequests.velero.io: attempting to create resource
CustomResourceDefinition/serverstatusrequests.velero.io: created
CustomResourceDefinition/volumesnapshotlocations.velero.io: attempting to create resource
CustomResourceDefinition/volumesnapshotlocations.velero.io: created
Waiting for resources to be ready in cluster...
Namespace/velero: attempting to create resource
Namespace/velero: created
ClusterRoleBinding/velero: attempting to create resource
ClusterRoleBinding/velero: created
ServiceAccount/velero: attempting to create resource
ServiceAccount/velero: created
Secret/cloud-credentials: attempting to create resource
Secret/cloud-credentials: created
BackupStorageLocation/default: attempting to create resource
BackupStorageLocation/default: created
VolumeSnapshotLocation/default: attempting to create resource
VolumeSnapshotLocation/default: created
Deployment/velero: attempting to create resource
Deployment/velero: created
Velero is installed! ⛵ Use 'kubectl logs deployment/velero -n velero' to view the status.
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ 
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ oc project
Using project "velero" on server "https://api.ocp.corp.frbnp1.com:443".
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ oc get all
NAME                         READY   STATUS    RESTARTS   AGE
pod/velero-8c76f48bc-wl7hj   1/1     Running   0          3d20h

NAME                     READY   UP-TO-DATE   AVAILABLE   AGE
deployment.apps/velero   1/1     1            1           4d1h

NAME                               DESIRED   CURRENT   READY   AGE
replicaset.apps/velero-8c76f48bc   1         1         1       3d20h
replicaset.apps/velero-f5566d7d5   0         0         0       4d1h
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ ./velero install --crds-only --dry-run -o yaml | oc apply -f -
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/backups.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/backupstoragelocations.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/deletebackuprequests.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/downloadrequests.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/podvolumebackups.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/podvolumerestores.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/resticrepositories.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/restores.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/schedules.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/serverstatusrequests.velero.io configured
Warning: oc apply should be used on resource created by either oc create --save-config or oc apply
customresourcedefinition.apiextensions.k8s.io/volumesnapshotlocations.velero.io configured
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ 
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ oc set image deployment/velero velero=velero/velero:v1.5.3 --namespace velero 
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ oc get backupstoragelocations 
NAME      PHASE   LAST VALIDATED   AGE
default                            91s
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ 
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ ./velero get backups
NAME               STATUS      ERRORS   WARNINGS   CREATED                         EXPIRES   STORAGE LOCATION   SELECTOR
backup-edited-dc   Completed   0        0          2021-05-06 15:49:02 -0700 PDT   26d       default            <none>
paul1              Completed   0        0          2021-04-19 12:55:03 -0700 PDT   9d        default            <none>
sankara-test1      Failed      0        0          2021-05-06 14:56:58 -0700 PDT   26d       default            <none>
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ ./velero get backup-locations
NAME      PROVIDER   BUCKET/PREFIX             PHASE         LAST VALIDATED                  ACCESS MODE
default   aws        frb-np1-ocp4-ocp-velero   Unavailable   2021-05-10 12:03:58 -0700 PDT   ReadWrite
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ ./velero delete backup sankara-test1 
Are you sure you want to continue (Y/N)? y
Request to delete backup "sankara-test1" submitted successfully.
The backup will be fully deleted after all associated data (disk snapshots, backup files, restores) are removed.
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ 
```
```
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$ ./velero get backups                 
NAME               STATUS      ERRORS   WARNINGS   CREATED                         EXPIRES   STORAGE LOCATION   SELECTOR
backup-edited-dc   Completed   0        0          2021-05-06 15:49:02 -0700 PDT   26d       default            <none>
paul1              Completed   0        0          2021-04-19 12:55:03 -0700 PDT   9d        default            <none>
[adm_sayyadurai@np1ocpadm1v velero-v1.5.3-linux-amd64]$
```

## Uninstall Velero 
```
oc delete namespace/velero clusterrolebinding/velero 
```
```
oc delete crds -l component=velero 
```
