#!/bin/bash

## This would grant the cluster admin access to the below users

oc adm policy add-cluster-role-to-user cluster-admin adm_sayyadurai
oc adm policy add-cluster-role-to-user cluster-admin adm_jfusco
oc adm policy add-cluster-role-to-user cluster-admin adm_sgudipati
oc adm policy add-cluster-role-to-user cluster-admin adm_skunduri
oc adm policy add-cluster-role-to-user cluster-admin adm_pmuppidi
oc adm policy add-cluster-role-to-user cluster-admin adm_sramalingam
oc adm policy add-cluster-role-to-user cluster-admin adm_pvanloon
oc adm policy add-cluster-role-to-user cluster-admin adm_mdewda
oc adm policy add-cluster-role-to-user cluster-admin adm_rjajoo
oc adm policy add-cluster-role-to-user cluster-admin adm_npasumarthi
oc adm policy add-cluster-role-to-user cluster-admin adm_bsirkeci
oc adm policy add-cluster-role-to-user cluster-admin adm_sukumar
oc adm policy add-cluster-role-to-user cluster-admin adm_smarikenchanagowd
oc adm policy add-cluster-role-to-user cluster-admin adm_anksrivastava
oc adm policy add-cluster-role-to-user cluster-admin adm_bkudre

